/**
 * 
 */
package com.lnt.emp_project.exception;

/**
 * @author Smita B Kumar
 *
 */
public class EmployeeException extends Exception{
	private static final long serialVersionUID = -7423511350458192098L;

	public EmployeeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
