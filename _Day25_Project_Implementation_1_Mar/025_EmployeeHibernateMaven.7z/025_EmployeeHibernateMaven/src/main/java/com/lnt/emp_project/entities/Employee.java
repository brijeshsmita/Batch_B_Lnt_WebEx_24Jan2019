/**
 * 
 */
package com.lnt.emp_project.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GeneratorType;

/**
 * @author Smita B Kumar
 *  create Entity 
	-package
	-public class implements Serializable
	-generate serial verion id
	-private/protected instance variable
	-No-arg contructor
	-getters and setters
	-toString()
	-equals and hashCode if Set Collection will used 
	-if needs to sorted them implement Comparable or Comparator
	Annotate the Entity with JPA annotation for persisting into database using hibernate
 */
@Entity
@Table(name="MVN_EMPLOYEE")
public class Employee implements Serializable,Comparable<Employee>{
	private static final long serialVersionUID = 2183200821155970082L;
	@Id
	@GeneratedValue(generator="EMP_GEN",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="EMP_GEN",sequenceName="MVN_EMP_SEQ",allocationSize=1)
	@Column(name="EMP_ID")
	private Integer empId;
	
	@Column(name="EMP_NAME")
	private String empName;
	
	@Column(name="EMP_SAL")
	private Double empSal;
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Employee(String empName, Double empSal) {
		super();
		this.empName = empName;
		this.empSal = empSal;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + "]";
	}
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(Double empSal) {
		this.empSal = empSal;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((empId == null) ? 0 : empId.hashCode());
		result = prime * result + ((empName == null) ? 0 : empName.hashCode());
		result = prime * result + ((empSal == null) ? 0 : empSal.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (empId == null) {
			if (other.empId != null)
				return false;
		} else if (!empId.equals(other.empId))
			return false;
		if (empName == null) {
			if (other.empName != null)
				return false;
		} else if (!empName.equals(other.empName))
			return false;
		if (empSal == null) {
			if (other.empSal != null)
				return false;
		} else if (!empSal.equals(other.empSal))
			return false;
		return true;
	}
	@Override
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		return this.empId-o.empId;//natural sorting by id
	}
}
