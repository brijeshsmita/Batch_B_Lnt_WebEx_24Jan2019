/**
 * 
 */
package com.lnt.emp_project.service;

import java.util.List;

import com.lnt.emp_project.dao.EmployeeDao;
import com.lnt.emp_project.dao.IEmployeeDao;

/**
 * @author Smita B Kumar
 *
 */
public class EmployeeService implements IEmployeeService {
	/**
	 * prepwork -> EmployeeDao Object - to call Dao layer method from service layer
	 */
	private IEmployeeDao employeeDao;
	public EmployeeService() {
		employeeDao= new EmployeeDao();
	}
	@Override
	public int addEmployee(com.lnt.emp_project.entities.Employee employee)
			throws com.lnt.emp_project.exception.EmployeeException {		
		return employeeDao.addEmployee(employee);
	}
	@Override
	public List<com.lnt.emp_project.entities.Employee> listAllEmployee()
			throws com.lnt.emp_project.exception.EmployeeException {
		return employeeDao.listAllEmployee();
	}
	@Override
	public com.lnt.emp_project.entities.Employee updateEmployee(com.lnt.emp_project.entities.Employee employee)
			throws com.lnt.emp_project.exception.EmployeeException {
		return employeeDao.updateEmployee(employee);
	}
	@Override
	public int deleteEmployee(int empId) throws com.lnt.emp_project.exception.EmployeeException {
		return employeeDao.deleteEmployee(empId);
	}
	@Override
	public com.lnt.emp_project.entities.Employee searchEmployeeById(int empId)
			throws com.lnt.emp_project.exception.EmployeeException {		
		return employeeDao.searchEmployeeById(empId);
	}
	@Override
	public com.lnt.emp_project.entities.Employee getEmployeeByName(String empName)
			throws com.lnt.emp_project.exception.EmployeeException {		
		return employeeDao.getEmployeeByName(empName);
	}	
}
