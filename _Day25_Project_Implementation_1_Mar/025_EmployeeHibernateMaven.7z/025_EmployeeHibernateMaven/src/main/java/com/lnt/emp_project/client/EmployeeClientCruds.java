/**
 * 
 */
package com.lnt.emp_project.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.lnt.emp_project.entities.Employee;
import com.lnt.emp_project.exception.EmployeeException;
import com.lnt.emp_project.service.EmployeeService;
import com.lnt.emp_project.service.IEmployeeService;

/**
 * @author Smita B Kumar
 *
 */
public class EmployeeClientCruds {
	/**
	 * prep work -> object of IEmployeeService
	 */
	private static IEmployeeService employeeService = new EmployeeService();
	public static void main(String[] args) {
	 try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in));) {
		 excuteApp(br);
		 }catch (EmployeeException e) {
			System.err.println(e);	
		} catch (IOException e1) {
			System.err.println(e1);
		}catch (InputMismatchException e) {
			System.err.println(e);
		}
	 	catch (Exception e1) {
			System.err.println(e1);
		}
	}//end of main
	private static void excuteApp(BufferedReader br) throws IOException,EmployeeException,InputMismatchException,NullPointerException{
int result=0;
 int choice =0;
	 Employee employee =new Employee();
	 while(true) {
		 System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
		 		+ "\nEnter Your choice from 1 - 7 ... 7 to exit ...only Numeric value"
		 		+ "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
		 		+ "\n 			1. Add Employeee"
		 		+ "\n 			2. List Employeee"
		 		+ "\n 			3. Update Employeee"
		 		+ "\n 			4. Delete Employeee"
		 		+ "\n 			5. Search Employeee By Id"
		 		+ "\n 			6. Search Employeee By Name"
		 		+ "\n 			7. Exit Employeee App"
		 		+ "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		 choice=Integer.parseInt(br.readLine());
		 switch (choice) {
			case 1:
				System.out.println("Adding Employee Record!!");
				/*System.out.println("Enter Employee Id ");
				 int eId=sc.nextInt();*/
				 System.out.println("Enter Employee Name ");
				 String empName=br.readLine();
				 System.out.println("Enter Employee Salary ");
				 double empSal=Double.parseDouble(br.readLine());
				//employee.setEmpId(eId);
				employee.setEmpName(empName);
				employee.setEmpSal(empSal);
				 int autoEmpId =employeeService.addEmployee(employee);
				if(autoEmpId>1)System.out.println("Employee Record Added... with the unique Id : "+autoEmpId);
				else System.err.println("Employee Record NOT Added");
					
				break;
			case 2:
				System.out.println("Listing Employee Record!!");
				List<Employee> empList =employeeService.listAllEmployee();
				if(empList!=null) {
					for(Employee e : empList) System.out.println(e);
				}
				else System.err.println("Record Not Found");
				break;
			case 3:
				System.out.println("Updating Employee Record!!");
				System.out.println("Enter Employee Id to be Updated....");
				int eid=Integer.parseInt(br.readLine());
				System.out.println("Enter name to be updataed");
				String newName=br.readLine();
				System.out.println("Enter salary to be updataed");
				double newSal=Double.parseDouble(br.readLine());
				employee.setEmpId(eid);
				employee.setEmpName(newName);
				employee.setEmpSal(newSal);
				Employee updatedEmployee =employeeService.updateEmployee(employee);
				if(updatedEmployee!=null)System.out.println("Employee Record Updated : "+updatedEmployee);
				else System.err.println("Employee Record NOT Updated");
				break;
			case 4:
				System.out.println("Deleting Employee Record!!");
				System.out.println("Enter Employee Id to be deleted....");
				eid=Integer.parseInt(br.readLine());
				result =employeeService.deleteEmployee(eid);
				if(result>0)System.out.println("\nEmployee Record Deteletd");
				else System.err.println("Employee Record NOT Deteletd");
				break;
			case 5:
				System.out.println("\nSearching Employee Record By Id !!");
				System.out.println("Enter Employee Id to be searched....");
				int id=Integer.parseInt(br.readLine());
				employee =employeeService.searchEmployeeById(id);
				if(employee!=null) System.out.println("\nEmployee Record Found : "+employee);
				else System.out.println("Record Not Found");
				break;
			case 6:
				System.out.println("\nSearching Employee Record By Name !!");
				System.out.println("Enter Employee Name to be searched....");
				String empName1=br.readLine();
				employee =employeeService.getEmployeeByName(empName1);
				if(employee!=null) System.out.println("\nEmployee Record Found : "+employee);
				else System.out.println("Record Not Found");
				break;
			case 7:
				System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
						+ "Thank you for using our Employee Application ......Exiting Employee App!!"
						+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				System.exit(0);//to terminate the program
				break;
			default:
				System.err.println("Sorry You have entered wrong choice...");
				break;
			}//end of switch
		}//end of while
	}
}
