/**
 * 
 */
package com.lnt.emp_project.service;

import java.util.List;

import com.lnt.emp_project.entities.Employee;
import com.lnt.emp_project.exception.EmployeeException;

/**
 * @author Smita B Kumar
 *
 */
public interface IEmployeeService {
	public int addEmployee(Employee employee)throws EmployeeException;//C
	public List<Employee> listAllEmployee()throws EmployeeException;//R
	public Employee updateEmployee(Employee employee)throws EmployeeException;//U
	public int deleteEmployee(int empId)throws EmployeeException;//D
	public Employee searchEmployeeById(int empId)throws EmployeeException;//S
	public Employee getEmployeeByName(String empName)throws EmployeeException;//S
}
