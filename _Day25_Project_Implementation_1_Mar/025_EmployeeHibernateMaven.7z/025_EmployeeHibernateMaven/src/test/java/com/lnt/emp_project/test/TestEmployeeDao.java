/**
 * 
 */
package com.lnt.emp_project.test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.lnt.emp_project.dao.EmployeeDao;
import com.lnt.emp_project.dao.IEmployeeDao;
import com.lnt.emp_project.entities.Employee;
import com.lnt.emp_project.exception.EmployeeException;
/** * @author Smita* */
public class TestEmployeeDao {
	private static IEmployeeDao employeeDao;
	Employee employee= new Employee("Sasi" ,9876.99);
	Integer empId;
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		//inorder to call the method of EmployeeDaoImpl class , we should first create the object of EmployeeDaoImpl
		employeeDao= new EmployeeDao();
	}	
	/**
	 * Test method for {@link com.lnt.employeeBook.dao.EmployeeDaoImpl#addNewEmployee(com.lnt.employeeBook.entities.Employee)}.
	 * @throws EmployeeException 
	 */
	@Test
	//@Ignore
	public void testAddNewEmployee() throws EmployeeException {
		empId=employeeDao.addEmployee(employee);
		employee.setEmpId(empId);
		assertTrue(empId>0);
		System.out.println("Employee Persisted with Id : "+empId);
	}
	/**
	 * Test method for {@link com.lnt.employeeBook.dao.EmployeeDaoImpl#updateEmployee(com.lnt.employeeBook.entities.Employee)}.
	 * @throws EmployeeException 
	 */
	@Test
	@Ignore
	public void testUpdateEmployee() throws EmployeeException {
		Employee updatedEmployee= new Employee("Yara", 9999.99);
		updatedEmployee.setEmpId(1);//existing employee
		employee=employeeDao.updateEmployee(updatedEmployee);
		System.out.println("Uodated Employee : "+employee);
	}
	/**
	 * Test method for {@link com.lnt.employeeBook.dao.EmployeeDaoImpl#getAllEmployees()}.
	 * @throws EmployeeException 
	 */
	@Test
	public void testGetAllEmployees() throws EmployeeException {
		List<Employee> employeeList=employeeDao.listAllEmployee();
		assertNotNull("No Employee Records Found!!", employeeList);
		for (Employee employee : employeeList) {
			System.out.println(employee);
		}
	}	
	/**
	 * Test method for {@link com.lnt.employeeBook.dao.EmployeeDaoImpl#removeEmployee(com.lnt.employeeBook.entities.Employee)}.
	 * @throws EmployeeException 
	 */
	@Test
	@Ignore
	public void testRemoveEmployee() throws EmployeeException {
		int res=employeeDao.deleteEmployee(1);
		assertEquals(1, res);
		System.out.println("Deleted Employee : 1");
	}
	/**
	 * Test method for {@link com.lnt.employeeBook.dao.EmployeeDaoImpl#searchEmployeeByName(java.lang.String)}.
	 * @throws EmployeeException 
	 */
	@Test
	@Ignore
	public void testSearchEmployeeByName() throws EmployeeException {
		String name ="Smita";
		Employee expected = employeeDao.getEmployeeByName(name);
		assertNotNull("No Employee Records Found!", expected);
		System.out.println("Search Employee by Name "+name+": "+expected);
	}
	/**
	 * Test method for {@link com.lnt.employeeBook.dao.EmployeeDaoImpl#searchEmployeeById(java.lang.Integer)}.
	 * @throws EmployeeException 
	 */
	@Test
	@Ignore
	public void testSearchEmployeeById() throws EmployeeException {
		Integer id =3;
		Employee expected = employeeDao.searchEmployeeById(id);
		assertNotNull("No Employee Records Found!", expected);
		System.out.println("Search Employee by Id "+id+": "+expected);
	}
}
