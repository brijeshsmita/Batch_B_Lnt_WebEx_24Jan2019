/**
 * 
 */
package com.lnt.day7.polymorphism;

import com.lnt.day7.emp.Employee;
import com.lnt.day7.emp.mgr.Manager;
import com.lnt.day7.emp.mgr.sales.SalesManager;

/**
 * @author brije
 *
 */
public class EmployeeClient {
	public static void main(String[] args) {
		Employee e1=new Employee("Zara", 9999.88);
		Employee m1=new Manager("Tara", 9999.88,888.88);
		Employee sm1=new SalesManager("Yara", 9999.88,888.88,700.00);
		
		//create an array of employee
		Employee [] empArr = {e1,m1,sm1};
		Printer.printAll(empArr);
	}

}
class Printer{
	
	static void printAll(Employee ... empArr) {
		for(Employee emp:empArr ) {
			//polymorphism
			//different object(e1,m1,sm1) responding to the same method(print) differently
			emp.print();//e1,m1,sm1
			//if there is no print method in the employee class then if will give compilation error
			//if there is no print method in the sub-class then the super class print method will be invoke
			//if there is print method in the sub-class then 
			//the compiler will first check the print method in super class but will invoke the method of sub-cass
		}
	}
}