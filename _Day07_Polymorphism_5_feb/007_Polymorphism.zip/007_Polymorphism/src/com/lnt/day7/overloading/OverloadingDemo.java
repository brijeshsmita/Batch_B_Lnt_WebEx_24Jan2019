/**
 * 
 */
package com.lnt.day7.overloading;

/**
 * @author brije
 *
 */
/*
 * -same method name with different parameter list and implementation, return type may or maynot be same.
-different parameter list
	-number of arguments
	-datatype of arguments
	-sequence of arguments


 */
public class OverloadingDemo {
	double calculateBillAmt(double n1, int n2) {
		return n1+n2;
	}
	double calculateBillAmt(double n1, int n2,int n3) {
		return n1+n2+n3;//number if parameters
	}
	double calculateBillAmt( int n2,double n1,int n3) {
		return n1+n2+n3;//sequence if parameters
	}
	double calculateBillAmt( float n2,float n1,float n3) {
		return n1+n2+n3;//datatype if parameters
	}
	
	public static void main(String[] args) {
		//compiler will decide at the runtime which method to invoked according to the arguments list
		OverloadingDemo o1 = new OverloadingDemo();
		System.out.println("Then Bill Amount of calculateBillAmt(double n1, int n2) is :"
		+o1.calculateBillAmt(100.50,200));
		System.out.println("Then Bill Amount of calculateBillAmt(double n1, int n2,int n3) is :"
				+o1.calculateBillAmt(100.50,200,300));
		System.out.println("Then Bill Amount of calculateBillAmt(int n3,double n1, int n2) is :"
				+o1.calculateBillAmt(10,200.50,300));
		System.out.println("Then Bill Amount of calculateBillAmt(int n3,double n1, int n2) is :"
				+o1.calculateBillAmt(1000.0f,200.50f,300.50f));//float literal must be suffixed by 'f' or 'F'
	}

}
