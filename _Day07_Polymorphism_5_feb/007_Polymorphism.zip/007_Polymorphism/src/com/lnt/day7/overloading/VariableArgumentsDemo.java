/**
 * 
 */
package com.lnt.day7.overloading;

/**
 * @author brije
 *
 */
public class VariableArgumentsDemo {
	double calculateBillAmt(double n1, int n2) {
		return n1+n2;
	}
	double calculateBillAmt(double n1, int n2,int n3) {
		return n1+n2+n3;//number if parameters
	}
	double calculateBillAmt( int n2,double n1,int n3) {
		return n1+n2+n3;//sequence if parameters
	}
	double calculateBillAmt( float n2,float n1,float n3) {
		return n1+n2+n3;//datatype if parameters
	}
	//java 7 onwards we have a concept if varArg - variable arguments
	//at time time according to the number of argument passed will be stored in an dynamic array
	double calculateBillAmt(double ... amtArr) {
		double sum=0.0;
		//enhanced for loop-java 5 onwards
		for(double d: amtArr) {
			sum+=d;
		}
		return sum;		
	}
	double calculateBillAmt(int ... amtArr) {
		int sum=0;
		//enhanced for loop-java 5 onwards
		for(int d: amtArr) {
			sum+=d;
		}
		return sum;		
	}
	//in a method there can be only one var argument 
	//and that also the last argument 
	int calculateBillAmt(String customerName,int ... amtArr) {
		int sum=0;
		System.out.println("Bill Amount for "+customerName);
		//enhanced for loop-java 5 onwards
		for(double d: amtArr) {
			sum+=d;
		}
		return sum;		
	}
	
	public static void main(String[] args) {
		VariableArgumentsDemo o1 = new VariableArgumentsDemo();
		System.out.println("Then Bill Amount of o1.calculateBillAmt(12,13,14,50,60) :"
				+o1.calculateBillAmt(12,13,14,50,60));
		System.out.println("Then Bill Amount of o1.calculateBillAmt(12,13) :"
				+o1.calculateBillAmt(12,13));
		System.out.println(o1.calculateBillAmt("Zara",30,13,50));
		//compiler will decide at the runtime which method to invoked according to the arguments list
		/*
		System.out.println("Then Bill Amount of calculateBillAmt(double n1, int n2) is :"
		+o1.calculateBillAmt(100.50,200));
		System.out.println("Then Bill Amount of calculateBillAmt(double n1, int n2,int n3) is :"
				+o1.calculateBillAmt(100.50,200,300));
		System.out.println("Then Bill Amount of calculateBillAmt(int n3,double n1, int n2) is :"
				+o1.calculateBillAmt(10,200.50,300));
		System.out.println("Then Bill Amount of calculateBillAmt(int n3,double n1, int n2) is :"
				+o1.calculateBillAmt(1000.0f,200.50f,300.50f));*///float literal must be suffixed by 'f' or 'F'
	}

}
