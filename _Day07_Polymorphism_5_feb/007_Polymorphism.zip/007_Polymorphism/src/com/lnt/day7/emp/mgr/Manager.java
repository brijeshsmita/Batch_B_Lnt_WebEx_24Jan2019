/**
 * 
 */
package com.lnt.day7.emp.mgr;

import com.lnt.day7.emp.Employee;

/**
 * @author brije
 *
 */
public class Manager extends Employee{
	//achieving inheritance using extends keyword, 
	//to inherit all the properties and methods of the extends class except constructor
//protected members are avialable to the sub-class inside and outside the package
	protected double bonus;
	/*static int numId;
	static {
		//static init block to initialize only static variable
		numId= (int) (1000+ Math.random()*1234.1234);
	}
//init block to initialize those variable which need to be created before invocation of a constructor
	{
		empId=numId++;
	}*/
	public Manager() {
		super();
		//by default call to super class constructor is there
		//super keyword has two usage
		//1> super is used to invoke super class constructor
			//- call to super in constructor must be the first line of code.
		//2> used to invoke super class method... can be invoked anywhere inside the method
		System.out.println("No-Arg constructor of Manager class");
		
	}
	public Manager(String empName, double empSal, double bonus) {
		super(empName, empSal);//super will invoke overloaded constructor of the super class
		//we can pass arguments to super keyword , so that we ca make call to specific constructor
		this.bonus = bonus;
		System.out.println("Overloaded constructor of Manager class");
	}
	/*
	 * -re-writing the method of super class in sub class
	-same methods name with different implementation
	-can be done in subclass
	-argument list and the exception list must be same
	- return type also must be same
	*/
	@Override
	public void print() {
		// TODO Auto-generated method stub
			System.out.println(
					"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
							+"\n                    Manager Details                             \n"
							+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
							+"\n          Manager Id       : "+empId
							+"\n          Manager Name     : "+empName
							+"\n          Salary           : "+empSal
							+"\n          Manager Bonus    : "+bonus
							+"\n          Company Name     : "+CO_NAME +" "+COURNTRY_NAME
			+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
	}
	/*	-return type can only be covariant return type(subclass)
*/	@Override
	public Manager getEmployee(int empId) {
		// TODO Auto-generated method stub
		return this;//this is a keyword to refer current object in java
	}
	@Override
	public String toString() {
		return "Manager [bonus=" + bonus + ", toString()=" + super.toString() + "]";
	}
	//final method cannot be overridden-compilation error
	/*@Override
	public final void testEmp() {
		System.out.println("this is  final method i employee class"
				+ "...which cannot be overridden");
	}*/
	
}
