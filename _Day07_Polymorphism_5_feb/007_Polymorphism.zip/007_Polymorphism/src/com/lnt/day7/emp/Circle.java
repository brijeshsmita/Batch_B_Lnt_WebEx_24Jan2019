package com.lnt.day7.emp;
/*
 * -is used for providing futhere extensibility of the class, so that the class extending from abstract class can provide its own implemenation
 */
public class Circle {
	//Circle
/*
	draw(){
		sysout("drawing Square");
	}
	area(){
		sysyout("area of a square is "+side*side);
	}*/
}
