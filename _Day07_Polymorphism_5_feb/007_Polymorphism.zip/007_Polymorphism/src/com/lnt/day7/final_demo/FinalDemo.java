/**
 * 
 */
package com.lnt.day7.final_demo;

/**
 * @author Smita
 *
 */
public class FinalDemo {
	final float PI_VALUE=3.14F;
	//final variable must be named in all caps seperated by underscore
	/*final is a keyword in java
	 * can be used with class,variables and method
	 * 1> final class cannot be sub-classed /inherited/extended
	 * 2> final methods cannot be overridden
	 * 3> final variable must be initialize and cannot be re-initialized
	 * 		- final variable which is declared but initialized inside a constructor or a block is known as blank final
	 * 		-final variable cannot have setter methods(cannot be re-initialized)
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
final class Demo1{
	//final class cannot be sub-classed /inherited/extended
	//method inside final class are by default final--cannot be overridden
	//example String class in java are final
	//All Wrapper class in java are final
	//these classes cannot be inherited
}
//final class cannot be sub-classed /inherited/extended
/*class Demo2 extends Demo1{
	
}*/