select * from Question_otm;
select * from Answer_otm;

select * from q501;
select * from ans501;