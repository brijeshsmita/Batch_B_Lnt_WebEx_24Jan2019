select * From COURSE_MTM;
select * From TRAINEE_MTM;

select * From TRAINEE_COURSE;