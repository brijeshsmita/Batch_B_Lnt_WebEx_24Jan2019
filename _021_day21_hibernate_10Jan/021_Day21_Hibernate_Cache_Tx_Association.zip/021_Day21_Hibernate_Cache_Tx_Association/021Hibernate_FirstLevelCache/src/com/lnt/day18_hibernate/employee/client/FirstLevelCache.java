/**
 * 
 */
package com.lnt.day18_hibernate.employee.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.lnt.day18_hibernate.employee.model.Employee;

/**
 * @author brije
 *
 */
public class FirstLevelCache {
	public static void main(String[] args) {// step 1 : create session Factory
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = null;
		Long empId=(long) 1000;
		Transaction transaction = null;
		try {
			// //step 2 : open session
			session = factory.openSession();			
			System.out.println("Employee feched from db ************"
			+session.get(Employee.class, empId));		
			
			System.out.println("Fetching the record fro cache , "
					+ "hibernate will now not hit the select query");
			System.out.println("Employee feched from cache ************"
					+session.get(Employee.class, empId));	
			session.close();
		} catch (Exception ex) {
			ex.printStackTrace();
			if (transaction != null)
				transaction.rollback();
		} finally {
			if (factory != null)
				factory.close();
		}
	}
}
