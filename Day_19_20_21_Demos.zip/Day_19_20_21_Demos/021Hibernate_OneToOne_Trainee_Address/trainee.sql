
select * from TRAINEE_OTO;
select * from ADDRESS_OTO;
