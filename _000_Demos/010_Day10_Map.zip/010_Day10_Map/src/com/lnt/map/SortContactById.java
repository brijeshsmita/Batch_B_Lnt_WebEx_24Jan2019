/**
 * 
 */
package com.lnt.map;

import java.util.Comparator;

/**
 * @author brije
 *
 */
public class SortContactById implements Comparator<Contact> {

	@Override
	public int compare(Contact o1, Contact o2) {
		// TODO Auto-generated method stub
		return o1.getContactId()-o2.getContactId();
	}

}
