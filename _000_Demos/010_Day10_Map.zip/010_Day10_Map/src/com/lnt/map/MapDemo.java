/**
 * 
 */
package com.lnt.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 * @author brije
 *
 */
public class MapDemo {
	public static void main(String[] args) {
		Map<Integer, String> map = new HashMap<>();
		map.put(101, "Smita");
		map.put(102, "Rita");
		map.put(103, "Tina");
		map.put(104, "Pihu");
		
		//how to iterate through map 
		//to iterate through map we need to enter the map into set
		//because map does not have any iterator
		Set set = map.entrySet();//step 1> 
		Iterator iter = set.iterator();//obtain the iterator for set
		while(iter.hasNext()) {//step 2> 
			/*step 3> */		Map.Entry<Integer, String> entry= (Entry<Integer, String>) iter.next();
			System.out.println(entry.getKey()+"\t"+entry.getValue());/*step 4> */
		}
		
		Map<String, String> map1 = new LinkedHashMap<>();
		
		Contact c1 = new Contact(444, "ciaz", "rez", "ciaz@gmail.com", "9879878888");
		Contact c2 = new Contact(555, "aish", "raj", "aish@gmail.com", "9879879999");
		Contact c3 = new Contact(111, "Bina", "mote", "bina@gmail.com", "9879877777");
		Contact c4 = new Contact(222, "Era", "rez", "era@gmail.com", "9879875555");
		Contact c5 = new Contact(333, "Dale", "fez", "dale@gmail.com", "9879876666");
		
		Map<Integer, Contact> contactMap = new LinkedHashMap<>();
		contactMap.put(null, c1);
		contactMap.put(null, c2);//linkedHashMap allows null - second null will be overlapped
		contactMap.put(c3.getContactId(), c3);
		contactMap.put(c3.getContactId(), c4);//in linkedHashMap duplicate keys are overlapped
		contactMap.put(c5.getContactId(), c5);
		
		set = contactMap.entrySet();//step 1 > enter the map into set
		iter= set.iterator();//step 2> obtain the iterator for set
		System.out.println("LinkedHashMap- -Insertion Order Map\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
				+ "Contact Key     | Contact Value"
				+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		while(iter.hasNext()) {//step 3> iterate through set
			//step 4> enter the map through map.entry
			Map.Entry<Integer, Contact> contactEntry= (Entry<Integer, Contact>) iter.next();
			System.out.println(contactEntry.getKey()+"\t\t| "+contactEntry.getValue());
			//if you try to print an object, call back is given to toString() method 
		}
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		
		
		//hashMap
		Map<Integer, Contact> contactMap1 = new HashMap<>();
		contactMap1.put(null, c1);//
		contactMap1.put(null, c2);//HashMap allows null - second null will be overlapped
		contactMap1.put(c3.getContactId(), c3);
		contactMap1.put(c3.getContactId(), c4);//in HashMap duplicate keys are overlapped
		contactMap1.put(c5.getContactId(), c5);
		
		set = contactMap1.entrySet();//step 1 > enter the map into set
		iter= set.iterator();//step 2> obtain the iterator for set
		System.out.println("HashMap-no order\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
				+ "Contact Key     | Contact Value"
				+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		while(iter.hasNext()) {//step 3> iterate through set
			//step 4> enter the map through map.entry
			Map.Entry<Integer, Contact> contactEntry= (Entry<Integer, Contact>) iter.next();
			System.out.println(contactEntry.getKey()+"\t\t| "+contactEntry.getValue());
			//if you try to print an object, call back is given to toString() method 
		}
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	}

}









