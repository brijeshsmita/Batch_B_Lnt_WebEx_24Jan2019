/**
 * 
 */
package com.lnt.map.treeMap;

import java.util.Comparator;

/**
 * @author brije
 *
 */
public class SortEmpBySal implements Comparator<Emp>{

	@Override
	public int compare(Emp o1, Emp o2) {
		// TODO Auto-generated method stub
		return (int) (o1.getSalary()-o2.getSalary());
	}

}
