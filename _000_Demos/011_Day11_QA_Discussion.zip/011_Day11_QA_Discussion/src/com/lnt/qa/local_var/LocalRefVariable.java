/**
 * 
 */
package com.lnt.qa.local_var;

import com.lnt.qa.collection.Contact;

/**
 * @author brije
 *
 */
public class LocalRefVariable {

	public static void display(Object obj) {
		System.out.println(obj.getClass()+"->"+obj);
		//if you try to print the current object .. callback is made to ... Contact class toString()
	}
	public static void main(String[] args) {
		//local Reference variable
		Contact cObj = new Contact(1, "Ben", "d_ben@gmail.com", "9879879111");
		//static method are invoked using class name
		LocalRefVariable.display(cObj);
		LocalRefVariable.display("Smita");//passing String Object
		LocalRefVariable.display(true);//passing String Object

	}

}
