/**
 * 
 */
package com.lnt.qa.collection;

import java.util.Comparator;

/**
 * @author brije
 *
 */
public class SortByEmail implements Comparator<Contact>{

	@Override
	public int compare(Contact o1, Contact o2) {
		// TODO Auto-generated method stub
		return o1.getEmail().compareTo(o2.getEmail());
	}

}
