/**
 * 
 */
package com.lnt.qa.collection;

import java.util.Comparator;

/**
 * @author brije
 *
 */
public class SortByPhone implements Comparator<Contact> {

	@Override
	public int compare(Contact o1, Contact o2) {
		// TODO Auto-generated method stub
		return o1.getPhoneNo().compareTo(o2.getPhoneNo());
	}

}
