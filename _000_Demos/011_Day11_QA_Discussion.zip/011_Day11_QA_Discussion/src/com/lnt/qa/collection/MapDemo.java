/**
 * 
 */
package com.lnt.qa.collection;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * @author brije
 *
 */
public class MapDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Map<Integer, String> bookContentMap = new HashMap<>();
		bookContentMap.put(1, "Introduction to Collection");
		bookContentMap.put(2, "Introduction to List");
		bookContentMap.put(3, "Introduction to Set");
		bookContentMap.put(4, "Introduction to Map");
		//visit each key and value of the map
		//step 1: put the map or key or value into set to iterate
		Set mapSet = bookContentMap.entrySet();//enter the whole map (k,v) into the set
		Set keySet = bookContentMap.keySet();//enter the key into the set
		Collection<String> valueSet = bookContentMap.values();//enter the value into the set
		for(Object key :keySet) {
			//System.out.println("Key : "+key+" Value : "+bookContentMap.get(key));
		}
		Contact c1 = new Contact(4, "Ciaz", "a_ciaz@gmail.com", "9879879222");
		Contact c2 = new Contact(5, "Aish", "c_aish@gmail.com", "9879879333");
		Contact c3 = new Contact(2, "Diya", "e_diya@gmail.com", "9879879444");
		Contact c4 = new Contact(3, "Era", "b_era@gmail.com", "9879879555");
		Contact c5 = new Contact(1, "Ben", "d_ben@gmail.com", "9879879111");
		
		
		Map<Contact, String> cHashMap = new HashMap<>();//No Order Map
		cHashMap.put(c1, c1.getName());cHashMap.put(c2, c2.getName());cHashMap.put(c3, c3.getName());cHashMap.put(c4, c4.getName());cHashMap.put(c5, c5.getName());
		System.out.println("\n****************HashMap Contact List*************");
		keySet = cHashMap.keySet();//enter the key into the set
		for(Object key :keySet) {
			System.out.println("Key : "+key+" Value : "+cHashMap.get(key));
		}
		
		
		Map<Contact, String> cLinkedMap = new LinkedHashMap<>();//insertion Order Map
		cLinkedMap.put(c1, c1.getName());cLinkedMap.put(c2, c2.getName());cLinkedMap.put(c3, c3.getName());cLinkedMap.put(c4, c4.getName());cLinkedMap.put(c5, c5.getName());
		System.out.println("\n****************LinkedHashMap Contact List*************");
		keySet = cLinkedMap.keySet();//enter the key into the set
		for(Object key :keySet) {
			System.out.println("Key : "+key+" Value : "+cLinkedMap.get(key));
		}
		
		
		Map<Contact, String> cTreeMap = new TreeMap<>();//Sorted Map - throws java.lang.ClassCastException:
		//here TreeMap will check Contact has implemented Comparable or Comparator
		//Because Sort has a contract with Comparable or Comparator
		cTreeMap.put(c1, c1.getName());cTreeMap.put(c2, c2.getName());cTreeMap.put(c3, c3.getName());cTreeMap.put(c4, c4.getName());cTreeMap.put(c5, c5.getName());
		System.out.println("\n****************TreeMap Contact List Sorted by natural sorting ContactId*************");
		keySet = cTreeMap.keySet();//enter the key into the set
		for(Object key :keySet) {
			System.out.println("Key : "+key+" Value : "+cTreeMap.get(key));
		}
		//comparator by email
		Map<Contact, String> cTreeMapEmail = new TreeMap<>(new SortByEmail());//Sorted Map - throws java.lang.ClassCastException:
		//here TreeMap will check Contact has implemented Comparable or Comparator
		//Because Sort has a contract with Comparable or Comparator
		cTreeMapEmail.put(c1, c1.getName());cTreeMapEmail.put(c2, c2.getName());cTreeMapEmail.put(c3, c3.getName());cTreeMapEmail.put(c4, c4.getName());cTreeMapEmail.put(c5, c5.getName());
		System.out.println("\n****************TreeMap Contact List Sorted by Email*************");
		keySet = cTreeMapEmail.keySet();//enter the key into the set
		for(Object key :keySet) {
			System.out.println("Key : "+key+" Value : "+cTreeMapEmail.get(key));
		}
		
		//comparator by phoneNo
		Map<Contact, String> cTreeMapPhone = new TreeMap<>(new SortByPhone());//Sorted Map - throws java.lang.ClassCastException:
		//here TreeMap will check Contact has implemented Comparable or Comparator
		//Because Sort has a contract with Comparable or Comparator
		cTreeMapPhone.put(c1, c1.getName());cTreeMapPhone.put(c2, c2.getName());cTreeMapPhone.put(c3, c3.getName());cTreeMapPhone.put(c4, c4.getName());cTreeMapPhone.put(c5, c5.getName());
		System.out.println("\n****************TreeMap Contact List Sorted by Phone Number*************");
		keySet = cTreeMapPhone.keySet();//enter the key into the set
		for(Object key :keySet) {
			System.out.println("Key : "+key+" Value : "+cTreeMapPhone.get(key));
		}
	}

}
