/**
 * 
 */
package com.lnt.qa.stringBuffer_builder;
/** @author Smita**/
public class StringBuilderBuffer {
	public static void main(String[] args) {
		//immutable - cannot change ... if changes made then new object will be created internally
		//1 > String are immutable, unsynchronized (not thread safe), can be used as primitive(without new keyword)
		String str1= "Brijes";
		System.out.println("str1 "+str1+ " hashCode : "+str1.hashCode());
		//string doesnot support append method
		str1+=" Kumar";
		System.out.println("str1+= "+str1+ " hashCode : "+str1.hashCode());
		
		//2 > StringBuffer are mutable, unsynchronized (not thread safe), cannot be used as primitive(with new keyword)
		//StringBuffer sb1= "Smita";//error as cannot be treated as primitive
		StringBuffer sb1= new StringBuffer("Smita");//must use new to create StringBuffer object
		System.out.println("sb1:  "+str1+ " hashCode : "+sb1.hashCode());
		sb1.append(" Kumar");
		System.out.println("sb1.append : "+sb1+ " hashCode : "+sb1.hashCode());//same hashCode -> as StringBuffers are mutable
		
		//3 > StringBuilder are mutable, synchronized (thread safe), 
		//cannot be used as primitive(with new keyword)
		//use StringBuilder when you want mutable String and to be Thread Safe in multi-threaded program
	}
}
