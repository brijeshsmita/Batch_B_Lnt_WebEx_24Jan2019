/**
 * 
 */
package com.lnt.qa.interface_demo;

/**
 * @author Smita
 *
 */
//by default all interfaces are abstract
//interface cannot extends a class
//interface cannot implement but can only extends 
//interface can extends multiple interface
public interface Shape extends Pritable,Faxable {//error - interface cannot extend a class//extends ThreeDShape{
	//naming convention for fina is ALL_CAPS 
	float POINT=0.0f;//by default var are public static and final
	//final var -> it is a constant in java which must be initialized 
	//and cannot be.....re-initialized
	//interface we can have only abstract method
	//java 8 onwards .. method can be default or static
	static void startPoint() {
		
	}
	//by default all method of an interface are abstract
	void draw();
	//interface cannot have constructor
}
class ThreeDShape{
	
}
interface Faxable {
	void fax();
}
interface Pritable {
	void print();
}