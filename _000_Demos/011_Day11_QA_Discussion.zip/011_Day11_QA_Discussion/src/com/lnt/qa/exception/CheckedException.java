/**
 * 
 */
package com.lnt.qa.exception;

/**
 * @author brije
 *
 */
//forced to catched by the programmer
public class CheckedException {
	public static void main(String[] args) throws ClassNotFoundException {
		try {//forName method to load the class dynamically (runtime)
			Class.forName("com.lnt.qa.exception.Demo");//as it is a checked Exception
			//java compiler will force you to catch it or to be caught.
			
			System.out.println("Hello , "+args[0]);//this may cause RuntimeException
		}catch(ArrayIndexOutOfBoundsException  |ClassNotFoundException e) {
			System.out.println("Sorry Boss Somethign went Wrong!! "+e.getMessage());
		}
		//but here the compiler is nor forcing the exception to caught.
		//explicitly handle the runtimeException by providing try catch or throws
	}
}
