package com.lnt.qa.exception;

public class Demo {

}
