/**
 * 
 */
package com.lnt.qa.abstract_demo;

/**
 * @author Smita
 *
 */
//if a class contain abstract method then is forced to be an abstract class
//multiple interfaces implemented by a class 
//but only one abstract class can be extended
public abstract class Shape implements ThreeDShape,VirtualShape{
	float point;//in abstract class we have any type of variable
	public Shape() {
		// interface cannot have constructor
		//but abstract class can have constructor
	}
void print() {
		
	}
	//by default all method of an abstract are NOT abstract
//we need to mark the method explicitly as abstract
	abstract void  draw();
}
interface ThreeDShape{
	
}
interface VirtualShape{
	
}
//golden-rule -> a class extending abstract class must override all the abstract method
//or declare the class itself as an abstract
////but only one abstract class can be extended
class Circle extends Shape {

	@Override
	void draw() {
		// TODO Auto-generated method stub
		
	}
	
}
