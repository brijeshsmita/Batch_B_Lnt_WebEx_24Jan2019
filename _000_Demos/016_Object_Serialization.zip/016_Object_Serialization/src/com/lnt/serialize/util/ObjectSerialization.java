package com.lnt.serialize.util;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
/** * @author brije * */
public class ObjectSerialization {
//Object Serialization -process of storing the state of an Object into the persistent unit
	public static void serializeObject(Object obj,String pathname) {
		//created file object , where we will persist the object
		File file = new File(pathname);
		//FileOutputStream and ObjectOutputStream
		try(    FileOutputStream fos= new FileOutputStream(file);
				ObjectOutputStream oos = new ObjectOutputStream(fos);	
			){
			oos.writeObject(obj);//writing the object
			oos.flush();//flushing the cache
			System.out.println("Object Persisted in a file : "+file.getAbsolutePath());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
//Object DeSerialization -process of fetching the state of an Object from the persistent unit
	public static Object deSerializeObject(String pathname) {
		//created file object , where we will persist the object
		File file = new File(pathname);
		Object obj=null;
		//read from file ->FileInputStream and read object ->ObjectInputStream
		try(    FileInputStream fos= new FileInputStream(file);
				ObjectInputStream oos = new ObjectInputStream(fos);	
			){
			System.out.println("Object getting de-serialized from a file : "+file.getAbsolutePath());
			obj= oos.readObject();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return obj;		
	}
}
