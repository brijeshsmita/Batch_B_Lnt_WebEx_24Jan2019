package com.lnt.serialize.client;
import com.lnt.serialize.model.Employee;
import com.lnt.serialize.util.ObjectSerialization;
/** * @author Smita * */
public class EmployeeClient {
		// lets create an Object of employee
	public static void main(String[] args) {		
		Employee e1 = new Employee("Zara", "khan", "zara@gmail.com", "9879879876", "UAE");
		System.out.println("e1 : "+e1);//callback is happening
		String pathname="src/emp.dat";
		//as the program terminates ..the object e1 state get lost
		//so in order to maintain the state of an object we will persist(save/store) in the persistent unit(disk/file/db)
		ObjectSerialization.serializeObject(e1,pathname);
		/*
		 * In order to serialize any object , java compiler must  know that the particular class object is meant to be persisted
		 * else it will throw java.io.NotSerializableException
		 * The class must implement Serializable interface
		 * it is a tagging/marker interface in java which does not have any method
		 * but it mark/tag the class with that interface to inform the compiler
		 * that the specific class has the particular implementation.
		 */		
		//de-serializing 
		Employee emp =(Employee) ObjectSerialization.deSerializeObject(pathname);
		emp.print();
	}
}
