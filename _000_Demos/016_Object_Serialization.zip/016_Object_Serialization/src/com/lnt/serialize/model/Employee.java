/**
 * 
 */
package com.lnt.serialize.model;
import java.io.Serializable;
//step 1: package declaration - one or none
//step 2: import statement - many or none
/** * @author Smita *
 */
//step 3: public class
/*
 * In order to serialize any object , java compiler must  know that the particular class object is meant to be persisted
 * else it will throw java.io.NotSerializableException
 * The class must implement Serializable interface
 * it is a tagging/marker interface in java which does not have any method
 * but it mark/tag the class with that interface to inform the compiler
 * that the specific class has the particular implementation.
 */
public class Employee implements Serializable{
//step 4: list of properties /instance  variables
	// instance variable - all the object/instance will have it own copy of variable
		private int employeeId; // instance variable of type int

		// (int byte short long float double boolean char)
		private String firstName;// reference instance variable of type String class
		private String lastName;
		private String email;
		private String phoneNo;
		private String address;
		private static int numId;
//step 5: static variables(class variables) - shared variable (single copy per class
		private static String companyName;
//step 6: initializer block (static and non-static)- (variables to be initialize before creation of an object)		
		static {
			companyName="LnT Infotech";
			numId=(int) (1000+ Math.random()*123.123);
		}
		//init block
		{
			employeeId=numId++;
		}
//step 7: constructor -( to initialize the properties of newly created object)
		public Employee() {
			// TODO Auto-generated constructor stub
		}
		
public Employee(String firstName, String lastName, String email, String phoneNo, String address) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.email = email;
	this.phoneNo = phoneNo;
	this.address = address;
}

//step 8: getter/setters (to provide access to the private variables outside the class
		
public int getEmployeeId() {
	return employeeId;
}

public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getPhoneNo() {
	return phoneNo;
}

public void setPhoneNo(String phoneNo) {
	this.phoneNo = phoneNo;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public static String getCompanyName() {
	return companyName;
}

public static void setCompanyName(String companyName) {
	Employee.companyName = companyName;
}

		//step 9: override toString() method (to display the value of the objects in String representation)
		@Override
		public String toString() {
			return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
					+ ", email=" + email + ", phoneNo=" + phoneNo + ", address=" + address + "]";
		}
		//step 10: business/additional method (eg: print())- static or non-static
		public void print() {
			// this is a keyword in java- which refers to current Object
			// no need of explicitly writing this ... it s already available
			System.out.println(
					"\n============================================================================================================================================\n"
							+ "\n                             Employee Details"
							+ "\n============================================================================================================================================\n"
							+ "\n            			Employee Id  : " + this.employeeId
							+ "\n            			First Name   : " + this.firstName
							+ "\n            			Last Name    : " + this.lastName
							+ "\n            			Email        : " + this.email
							+ "\n            			Phone Number : " + this.phoneNo
							+ "\n            			Adress       : " + this.address

							+ "\n============================================================================================================================================\n");
		}
}
