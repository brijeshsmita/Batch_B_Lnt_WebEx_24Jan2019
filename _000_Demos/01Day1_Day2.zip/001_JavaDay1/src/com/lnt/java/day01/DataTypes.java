/**
 * 
 */
package com.lnt.java.day01;

/**
 * @author Smita
 *
 */
public class DataTypes {
	
	public static void main(String[] args) {
		/*if you declare a variable inside a method or argument list ,
		 * then it is known as local variable
		 * local variable must be initialize before getting used
		 * does not have any default value
		 * it has a scope only within a method not outside the method boundry*/
		//variable names must be in camelCase
		//rateOfInterest , noODaysInMonth
		//always start with lowerCase and rest all word first letter will be in caps
		byte option =1;
		short age = 22;
		int noOfDays= 365;
		long phone=9879879990L;//in case of long variable postfix is l or L
		
		float weight=56.8f;//float variables must be postfix with f or F,
		//coz by default all decimal are double(8 bytes) in java and float is (4 bytes)
		double salaryPerAnnum=687689.78;
		
		char grade='A';//char must be in single Quotes
		boolean status=true; //never be in quotes
		
		String name ="Smita";//String is a class in java which can be treated as primitive
		//used to store collection of any letters or characters or special characters 
		String address;
		System.out.println(" Hello , "+name);
		System.out.println(" Grade is : "+grade + " and status is : "+status);
	//	System.out.println("Address is :"+address);//compilation error
		/*
		 * local variable must be initialize before getting used
		 * does not have any default value
		 */
		
		//_ is allowed in Numeric literals/value just for readilibity purpose
		double checkAmount=3_00_000_000.00;
	}

}
