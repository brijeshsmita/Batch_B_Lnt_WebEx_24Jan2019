/**
 * 
 */
package com.lnt.java.day01;

/**
 * @author Smita
 *
 */
public class Person {
// properties of a person (relevant info sharing is abstraction)
	private int personId;
	private String fname;
	private String lname;
	private String email;
	private String phone;
	private String address;
}
