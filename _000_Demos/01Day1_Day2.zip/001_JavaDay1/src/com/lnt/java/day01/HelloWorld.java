/**
 * 
 */
package com.lnt.java.day01;
//package is a keyword in java to defin package 
/*
 * package declartion should be first line of code in '.java' file
 */
/**
 * @author Smita
 *
 */
public class HelloWorld {

// ctlr+space to use auto-intellisence feature of eclipse
	public static void main(String [] smita) {
		System.out.println("Hello World");
	}
	private void print() {
		
	}
}
