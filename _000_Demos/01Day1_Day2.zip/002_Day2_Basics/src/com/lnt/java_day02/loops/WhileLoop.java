/**
 * 
 */
package com.lnt.java_day02.loops;

import java.util.Scanner;

/**
 * @author Smita
 *
 */
public class WhileLoop {

	public static void main(String[] args) {
		// when the number of iteration in not known
		Scanner scan = new Scanner(System.in);//input device
		System.out.println("Enter a Number to generte its table");
		int num=scan.nextInt();
		int i=1;//step 1: initialization
		while (i<=10) {//step 2: condition
			System.out.println(num +" * "+ i + " = "+ (i*num));
			//very important , increment/decrement must alway be provided
			i++;//step 3: increment/decrement
		}

	}

}
