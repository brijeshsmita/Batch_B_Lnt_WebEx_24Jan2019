/**
 * 
 */
package com.lnt.java_day02.loops;

import java.util.Scanner;

/**
 * @author Smita
 *
 */
public class ForLoop {

	public static void main(String[] args) {
		// ideally when should we use for instead of while
		//when the number of iteration in known
		//type for (ctlr+space)
		//accept the number from user
		//print it table
		//type Sccaner (ctrl+space)it will generate the import
		Scanner scan = new Scanner(System.in);//input device
		System.out.println("Enter a Number to generte its table");
		int num=scan.nextInt();
		for (int i = 1; i <=10; i++) {
			System.out.println(num +" * "+ i + " = "+ (i*num));
		}

	}

}
