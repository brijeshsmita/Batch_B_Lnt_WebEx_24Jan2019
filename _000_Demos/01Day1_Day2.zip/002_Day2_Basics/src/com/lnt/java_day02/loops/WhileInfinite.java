/**
 * 
 */
package com.lnt.java_day02.loops;

import java.util.Scanner;

/**
 * @author brije
 *
 */
public class WhileInfinite {

	public static void main(String[] args) {
		//to accept input from user we will use java.util.Scanner class
		Scanner scan = new Scanner(System.in);
		int choice=0;
		//infinite while ....exit will happen as per user
		while(true) {
		//here we are associating scanner to standard input device 
			System.out.println(
					"\n====================================================================================\n"
					+"\n           Enter Your Choice between 1-6\n"
					+"\n====================================================================================\n"
					+ "   1: Add Employeee \n"
					+ "   2: Upadate Employeee \n"
					+ "   3: Search Employeee \n"
					+ "   4: Delete Employeee \n"
					+ "   5: Exit Employeee App\n"
					+ "\n====================================================================================\n");
		
			choice = scan.nextInt();// accepting int value
			// type switch +cltr+space
			switch (choice) {
			case 1:
				System.out.println("1> Adding the Empolyee record");
				break;// terminate the current construct/loop
			case 2:
				System.out.println("2> Modifying the Empolyee record");
				break;
			case 3:
				System.out.println("3> Searching the Empolyee record");
				break;
			case 4:
				System.out.println("4> Deleting the Empolyee record");
				break;
			case 5:
				System.out.println("*********Exiting the Empolyee Application*******"
						+ "\n 			Thankyou for Using our Application...."
						+ "\n 					Do Visit Again....");
				System.exit(0);//exit method of System class terminates the program
				break;
			default:
				System.err.println("Sorry You entered the wrong choice....");
				break;
			}
		} 

	}

}
