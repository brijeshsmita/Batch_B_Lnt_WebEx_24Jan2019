/**
 * 
 */
package com.lnt.java_day02.constructs;

/**
 * @author Smita
 *
 */
public class IfConstructs {
	public static void main(String[] args) {
		//if -else
		int age = 12;
		if(age<18) {
			System.err.println("you are minor...NOT eligible to vote");
		}else {
			System.out.println("you are eligible to vote...");
		}
		
		//if -else -if
		float marks =88.90F;//by default all decimal literals are double in java
		//below 35 - 3rd failed
		//between 35 and 45 3rd division
		//between 50 and 59 2nd division
		//between 60 and 73 1st  division
		//above 73 distinction
		if(marks<35) {
			System.err.println("you are FAILED...NOT eligible to be promoted");
		}
		else if(marks >=35 && marks <=45) {
			System.out.println("3rd Division");
		}
		else if(marks >=50 && marks <=59) {
			System.out.println("2nd Division");		
		}
		else if(marks >=60 && marks <=73) {
			System.out.println("1st  division");
		}
		else {
			System.out.println("distinction");
		}
		
	}
}
