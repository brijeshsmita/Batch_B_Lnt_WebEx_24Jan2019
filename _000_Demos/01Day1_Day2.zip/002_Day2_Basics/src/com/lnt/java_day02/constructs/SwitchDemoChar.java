/**
 * 
 */
package com.lnt.java_day02.constructs;
import java.util.Scanner;
/**
 * @author Smita
 *
 */
public class SwitchDemoChar {
	public static void main(String[] args) {
		char ch='b';//character literals are always wrapped in single quotes
		System.out.println("Enter Your choice...."
				+ " \n    1: Add"
				+ " \n    2: display"
				+ " \n    0: exit");
		
		switch(ch) {
		case '1':
				System.out.println("You have opted choice 1... to Add ");
			//break;
		case '2':
			System.out.println("You have opted choice 2 .... to display");
			//break;
		case '0':
				System.out.println("You have opted choice 0 .... to exit");
				System.exit(0);
			//break;
		default:
			System.out.println("\\n you have entered a worng choice"
					+ "\nKindly enter choice between (a-c) only ");
			break;
		}
	}
}
