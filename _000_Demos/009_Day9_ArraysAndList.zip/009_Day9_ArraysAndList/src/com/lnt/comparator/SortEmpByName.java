/**
 * 
 */
package com.lnt.comparator;

import java.util.Comparator;

import com.lnt.inheritance.model.emp.Employee;

/**
 * @author brije
 *
 */
//Comparator is from util package and provide machanism to sort by different ways
//it has a compare method which takes 2 args
public class SortEmpByName implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		//it returns int value
		//if both object are equals then 0
		//if first object is greater then 1
		//if first object is smaller then -1
		// sorting by name
		return o1.getEmpName().compareTo(o2.getEmpName());
	}

}
