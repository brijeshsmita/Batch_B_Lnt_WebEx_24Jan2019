package com.lnt.inheritance.model.emp;

import java.util.Comparator;

/**
 * @author Smita
 *
 */
//golden rule for an interface
//a class implementing an interface must override all the abstract method
public class Employee implements Comparable<Employee>{
	//instance variables
	private Integer empId;
	private String empName;
	private Double empSal;
	@Override
	public int compareTo(Employee o) {
		//it returns int value
		//if both object are equals then 0
		//if first object is greater then 1
		//if first object is smaller then -1
		// we will do sorting in natural order i.e with empId
		return this.getEmpId()-o.getEmpId();//sort by id
		//return this.getEmpName().compareTo(o.getEmpName());//sort by name
	}
	public Employee() {
		this.empName="unknown";
		this.empSal=00.00;
	}
	//overloaded constructor 
	public Employee(String empName,Double empSal) {
		//when the instance variable name and the local variable name is same
		//then to use the instance variable ... we refer instance variable with the help this keyword
		this.empName=empName;//explicit this is used to refer to the instance variable
		this.empSal=empSal;
	}
	/*
	 * Overloading is a process of re-writing the method with same name
	 * and different argument list return type may or many not be same
	 */
	public Employee(Integer empId,String empName,Double empSal) {
		this.empId=empId;
		//when the instance variable name and the local variable name is same
		//then to use the instance variable ... we refer instance variable with the help this keyword
		this.empName=empName;//explicit this is used to refer to the instance variable
		this.empSal=empSal;
	}
	//override ToString() method 
	//to print the STring representation of an object
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + "]";
	}
	
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return empId;//if empId is same then the object will be same
		//therefore we are returning empId as a unique hashCode
	}
	@Override
	public boolean equals(Object obj) {
		return this.hashCode()==obj.hashCode();//both the object hashCode(empId) is same then both the objects are equals
	}
	//business method
	public void print() {
		// this is a keyword in java- which refers to current Object
		// no need of explicitly writing this ... it s already available
		System.out.println(
				"\n============================================================================================================================================\n"
						+ "\n                             Employee Details"
						+ "\n============================================================================================================================================\n"
						+ "\n            			Employee Id     : " + this.empId
						+ "\n            			Employee Name   : " + this.empName
						+ "\n            			Salary          : " + this.empSal

						+ "\n============================================================================================================================================\n");
	}
	//generate getters and setters
	//to provide access to private variables outside the class
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(Double empSal) {
		this.empSal = empSal;
	}
	public Employee getEmployee() {
		return this;
	//this refers to current object so it will return current employee object which has call getEmployee method
	}
	
}














