/**
 * 
 */
package com.lnt.list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * @author Smita
 *
 */
public class ListDemo {
	public static void main(String[] args) {
		//Collection stores only object
		//auto_boxing and auto-unboxing
		//collection can store heterogeneous Object
		//collection can increase and decrease in size dynamically
		
		//List are ordered collection (insertion order)
		//ArrayList implements List interface - we cannot instantiate interface
		List list = new ArrayList<>();
		//add heterogeneous object to the list 
		list.add(new String("Zara"));
		list.add(new Integer(11));
		list.add(new Double(11.11));
		System.out.println(list);
		//iterate through the list using 3 ways
		//1> enhanced for loop(java 5 onwards) 2> iterator  3> forEach() loop (java 8 onwards
		Iterator iter = list.iterator();//iterator is used to visit each element of the list
		System.out.println("*****Printing List**********");
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
		//but what if we want to add only string object- inorder to achieve type safety in java we have Generics
		List<String> nameList = new ArrayList<>();
		nameList.add("Ciaz");nameList.add("Biz");nameList.add("Diya");nameList.add("Aish");
		//error//nameList.add(11);//allowing me to add number too but i want to add only string
		//we can take the help of generic to achieve type safety List<String>
		System.out.println("\n*****Printing Name List**********");
		nameList.forEach(name->System.out.println(name));
		
		//a class Collections which provides sort method for sorting list
		Collections.sort(nameList);
		System.out.println("\n*****Printing Sorted Name List**********");
		nameList.forEach(name->System.out.println(name));
		
	}

}

