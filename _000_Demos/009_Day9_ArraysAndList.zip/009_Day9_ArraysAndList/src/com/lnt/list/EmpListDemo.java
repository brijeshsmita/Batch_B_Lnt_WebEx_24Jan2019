/**
 * 
 */
package com.lnt.list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.lnt.comparator.SortEmpByName;
import com.lnt.inheritance.model.emp.Employee;

/**
 * @author Smita
 *
 */
public class EmpListDemo {
	public static void main(String[] args) {
		Employee e1 = new Employee(444,"Ciaz", 222.22);
		Employee e2 = new Employee(222,"Diya", 111.11);
		Employee e3 = new Employee(333,"Benz", 444.44);
		Employee e4 = new Employee(111,"Aish", 333.33);
		
		//lets create List of Employee
		List<Employee> empList = new ArrayList<>();
		//add the obj to the list
		empList.add(e1);
		empList.add(e2);
		empList.add(e4);
		empList.add(1,e3);//adding e2 obj at index 1
		System.out.println("\n*************Printing EMployee List in insertion order**************");
		Iterator iter = empList.iterator();
		while(iter.hasNext())
			System.out.println(iter.next());
		//let sort the employee 
		System.out.println("\n*************Sorted EMployee List by Employee ID **************");
		Collections.sort(empList);//sort method has a contract with Comparable /Comparator interface
		//sort method says that if you want to sort any list of object, 
		//make sure that object must implement either Comparable /Comparator interface
		iter = empList.iterator();
		while(iter.hasNext())
			System.out.println(iter.next());
		
		System.out.println("\n*************Sorted EMployee List by Employee Name **************");
		//sort also has overloaded method with has  list and Comparator type object
		Collections.sort(empList,new SortEmpByName());//sort method has a contract with Comparable /Comparator interface
		//sort method says that if you want to sort any list of object, 
		//make sure that object must implement either Comparable /Comparator interface
		iter = empList.iterator();
		while(iter.hasNext())
			System.out.println(iter.next());
		
		System.out.println("\n*************Sorted EMployee List by Employee Salary **************");
		//sort also has overloaded method with has  list and Comparator type object
		Collections.sort(empList,new SortEmpBySalary());//sort method has a contract with Comparable /Comparator interface
		//sort method says that if you want to sort any list of object, 
		//make sure that object must implement either Comparable /Comparator interface
		iter = empList.iterator();
		while(iter.hasNext())
			System.out.println(iter.next());
	}
}
