/**
 * 
 */
package com.lnt.list;

import java.util.Comparator;

import com.lnt.inheritance.model.emp.Employee;

/**
 * @author Smita
 *
 */
public class SortEmpBySalary implements Comparator<Employee> {

	/* (non-Javadoc)
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 */
	@Override
	public int compare(Employee o1, Employee o2) {
		// sorting by salary
		return (int) (o1.getEmpSal()-o2.getEmpSal());
	}

}
