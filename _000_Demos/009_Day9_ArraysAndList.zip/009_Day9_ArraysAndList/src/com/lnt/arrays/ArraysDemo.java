/**
 * 
 */
package com.lnt.arrays;

/**
 * @author brije
 *
 */
public class ArraysDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// creating arrays of integer
		int [] intArr = {10,20,30};//created  and initialize array of int datatype
		char[] charArr = new char[2];//created array of char datatype
		charArr[0]='A';//array index start at 0
		charArr[1]='B';
		//error//charArr[2]='C';//arrayIndexOuOfBoundsException
		
		//iterate array through for loop
		System.out.println("charArr is:");
		for (int i = 0; i < charArr.length; i++) {
			System.out.println(charArr[i]);
		}
		//iterate array through enhanced for loop java 5 onward - use to iterate only over arrays and collections
		System.out.println("intArr is:");
		for(int i : intArr) {//always start with the 0th index 
			//, var - i holds the value , increment by 1, will iterate till the end of the array
			// the datatype of the variable must be same of the datatype of the array
			System.out.println(i);
		}
		String strArr [] = {"mon","tue","sun"};
		System.out.println("strArr is:");
		for(String i : strArr) {
			System.out.println(i);
		}
		//in java 8 we have forEach to iterate only over Collection
	}

}
