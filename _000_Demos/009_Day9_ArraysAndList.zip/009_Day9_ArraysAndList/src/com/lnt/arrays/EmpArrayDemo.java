/**
 * 
 */
package com.lnt.arrays;

import com.lnt.inheritance.model.emp.Employee;

/**
 * @author Smita
 *
 */
public class EmpArrayDemo {
	public static void main(String[] args) {
		Employee e1 = new Employee("Ciaz", 222.22);
		Employee e2 = new Employee("Diya", 111.11);
		Employee e3 = new Employee("Benz", 444.44);
		Employee e4 = new Employee("Aish", 333.33);
		
		//lets create arrays of object
		Employee [] empArr= new Employee[4];//arrays of 4 employees
		empArr[0]=e1;empArr[1]=e2;empArr[2]=e3;empArr[3]=e4;
		for(Employee e: empArr) {
			System.out.println(e);
		}
	}
}
