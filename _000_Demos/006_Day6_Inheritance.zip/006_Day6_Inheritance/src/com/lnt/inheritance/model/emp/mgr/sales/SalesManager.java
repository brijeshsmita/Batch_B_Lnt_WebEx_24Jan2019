/**
 * 
 */
package com.lnt.inheritance.model.emp.mgr.sales;

import com.lnt.inheritance.model.emp.mgr.Manager;

/**
 * @author Smita
 *
 */
public class SalesManager extends Manager {
	//instance variable
	private Double comm;
	
	//no_arg Constructor
	public SalesManager() {
		System.out.println("**********SalesManager no_arg Constructor*************");
		this.comm=0.0;
	}
	//overloaded constructor
	public SalesManager(String empName, Double empSal, Double bonus, Double comm) {
		super(empName, empSal, bonus);
		System.out.println("**********SalesManager overloaded Constructor*************");
		this.comm = comm;
	}
	//override toSTring Method
	@Override
	public String toString() {
		return "SalesManager [comm=" + comm + ", toString()=" + super.toString() + "]";
	}
	//override print method 
	@Override
	public void print() {
		System.out.println("==========================================================================\n"
				+ "\n 						SalesManager comm=" + comm );		
		super.print();
	}
	//generate getters and setters
	public Double getComm() {
		return comm;
	}
	public void setComm(Double comm) {
		this.comm = comm;
	}
	//co-variant return type
	//return type can be of subclass-type
	//it can be of type Employee/Manager or child classtype i.e. SalesManager
	@Override
	public SalesManager getEmployee() {
		return this;
	//this refers to current object so it will return current SalesManager object which has call getEmployee method
	}
}
