package com.lnt.inheritance.model.emp;

/**
 * @author Smita
 *
 */
public class Employee {
	//instance variables
	private Integer empId;
	private String empName;
	private Double empSal;
	private static int numId;//to auto-generate empId
	static {
		System.out.println("*****Employee class static block *******");
		numId= (int) (1000+ Math.random()*123*123);
		//empId=numId++;//error
		// non-static var cannot be accessed through static method/block directly (it need object reference)
	}
	//init block
	{
		System.out.println("*****Employee class init block *******");
		empId= numId++;//static var can be accessed through non-static block
		//but non-static var cannot be accessed through static method/block directly (it need object reference)
	}
	
	//no-arg constructor
	/*what is a constructor
	 * special kind of method 
	 * same name of the class name
	 * no return type
	 * used to initialize newly created object
	 * can be overloaded
	 * cannot be inherited 
	 * constructors are invoked from parent-child or super-sub class hierarchy
	 */
	public Employee() {
		System.out.println("*****Employee class no-arg constructor*******");
		this.empName="unknown";
		this.empSal=00.00;
	}
	//overloaded constructor 
	/*
	 * Overloading is a process of re-writing the method with same name
	 * and different argument list return type may or many not be same
	 */
	public Employee(String empName,Double empSal) {
		System.out.println("**********Employee class Overloaded/parameterized constructor*******");
		//when the instance variable name and the local variable name is same
		//then to use the instance variable ... we refer instance variable with the help this keyword
		this.empName=empName;//explicit this is used to refer to the instance variable
		this.empSal=empSal;
	}
	//override ToString() method 
	//to print the STring representation of an object
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + "]";
	}
	
	//business method
	public void print() {
		// this is a keyword in java- which refers to current Object
		// no need of explicitly writing this ... it s already available
		System.out.println(
				"\n============================================================================================================================================\n"
						+ "\n                             Employee Details"
						+ "\n============================================================================================================================================\n"
						+ "\n            			Employee Id     : " + this.empId
						+ "\n            			Employee Name   : " + this.empName
						+ "\n            			Salary          : " + this.empSal

						+ "\n============================================================================================================================================\n");
	}
	//generate getters and setters
	//to provide access to private variables outside the class
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(Double empSal) {
		this.empSal = empSal;
	}
	public Employee getEmployee() {
		return this;
	//this refers to current object so it will return current employee object which has call getEmployee method
	}
}














