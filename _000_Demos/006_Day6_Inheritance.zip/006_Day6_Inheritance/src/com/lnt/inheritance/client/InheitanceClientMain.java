/**
 * 
 */
package com.lnt.inheritance.client;

import com.lnt.inheritance.model.emp.mgr.Manager;
import com.lnt.inheritance.model.emp.mgr.sales.SalesManager;

/**
 * @author brije
 *
 */
public class InheitanceClientMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// create an object of Employee....
		//Employee e1 = new Employee();//by invoking no-arg constructor
		//e1.print();
		/*Manager m1 = new Manager();
		System.out.println(m1);
		Manager m2 = new Manager("Mona",888.88,80.90);//when we create manager , it will be create by invoking emp class constr
		
		System.out.println(m2);*/
		SalesManager sm1 = new SalesManager();
		System.out.println(sm1);
		SalesManager sm2 = new SalesManager("Sia", 777.777, 70.99, 17.88);
		System.out.println(sm2);
	}

}
