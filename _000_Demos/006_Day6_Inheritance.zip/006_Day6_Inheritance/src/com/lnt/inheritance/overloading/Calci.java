/**
 * 
 */
package com.lnt.inheritance.overloading;

/**
 * @author brije
 *
 */
public class Calci {
	public double add(int n1 , int n2) {
		System.out.println("add(int n1 , int n2) returning n1+n2");
		return n1+n2;
	}
	//method Overloading 
	/*
	 * same method name with different parameter list
	 * 	number of parameter may be different
	 *  
	 */
	public double add(int n1 , int n2,int n3) {
		System.out.println("add(int n1 , int n2,int n3) returning n1+n2+n3");
		return n1+n2+n2;
	}
	//* 	datatype of parameter may be different
	public double add(int n1 , int n2,double n3) {
		System.out.println("add(int n1 , int n2,double n3) returning n1+n2+n3");
		return n1+n2+n2;
	}
	//* 	sequence of parameter may be different
	public double add(double n1 , int n2,int n3) {
		System.out.println("add(double n1 , int n2,int n3) returning n1+n2+n3");
		return n1+n2+n2;
	}
	//variable argument - dynamic array (java 5 onwards
	
	

}





