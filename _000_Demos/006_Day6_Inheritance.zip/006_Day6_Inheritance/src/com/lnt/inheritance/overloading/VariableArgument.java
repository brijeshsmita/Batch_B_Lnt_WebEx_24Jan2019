/**
 * 
 */
package com.lnt.inheritance.overloading;

/**
 * @author brije
 *
 */
//dynamic arr or variable arguments java 5 onwards
/*
 * a method can have only ` var arg in the parameter list
 * if mutiple arguments then var arg must be the last parameter in the arg-list
 */
public class VariableArgument {
	public double add(double ...dArr) {//var-arg 
		double sum=0.0;
		for (int i = 0; i < dArr.length; i++) {
			sum+=dArr[i];
		}
		return  sum;
	}
	//if mutiple arguments then var arg must be the last parameter in the arg-list
	public double generateBillAmout(String name,double ...dArr) {//var-arg 
		double sum=0.0;
		for (int i = 0; i < dArr.length; i++) {
			sum+=dArr[i];
		}
		System.out.println("hello ,"+name + " ...Your Bill AMount is :"+sum);
		return  sum;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		VariableArgument v1 = new VariableArgument();
		System.out.println("Addition of 10,20,30 ="+v1.add(10,20,30));
		System.out.println("Addition of 100,20,30,500,700,10 ="+v1.add(100,20,30,500,700,10));
		System.out.println("Addition of 100.99,10.20,13.30,500,700,10 ="+v1.add(100.99,10.20,13.30,500,700,10));
		System.out.println("Bill Generation of 100.99,10.20,13.30,500,700,10 ="+v1.generateBillAmout("Zara",100.99,10.20,13.30,500,700,10));
	}

}
