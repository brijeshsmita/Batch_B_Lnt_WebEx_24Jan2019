/**
 * 
 */
package com.lnt.inheritance.overloading;

/**
 * @author Smita
 *
 */
public class CalciMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//how the java compiler will decide which method to be invoked
		//by the parameter passed to method
		Calci c1 = new Calci();
		
		System.out.println("adding 11,12 = "+c1.add(11, 12));//invoke the method with two int parameter
		System.out.println("adding 10,20,30 = "+c1.add(10, 20,30));//invoke the method with three int parameter
		System.out.println("adding 10,20,55.55 = "+c1.add(10, 20,55.55));//invoke the method with two int and 1 double parameter
		System.out.println("adding 10.99,20,55.55 = "+c1.add(10.99, 20,55));//invoke the method with 1 double and two int parameter
		//compilation error as such type of method with double,int,double does not exists
		//System.out.println("adding 10.99,20,55.55 = "+c1.add(10.99, 20,55.55));
	}

}
