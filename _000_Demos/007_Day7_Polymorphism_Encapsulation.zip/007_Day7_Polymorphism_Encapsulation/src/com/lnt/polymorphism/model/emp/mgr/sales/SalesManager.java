/**
 * 
 */
package com.lnt.polymorphism.model.emp.mgr.sales;
import com.lnt.polymorphism.model.emp.mgr.Manager;

/**
 * @author brije
 *
 */
public class SalesManager extends Manager {// inheritance
	// instance variable
	private Double comm;

	// no_arg Constructor
	public SalesManager() {
		System.out.println("**********SalesManager no_arg Constructor*************");
		this.comm = 0.0;
	}

	// overloaded constructor
	public SalesManager(String empName, Double empSal, Double bonus, Double comm) {
		super(empName, empSal, bonus);
		System.out.println("**********SalesManager overloaded Constructor*************");
		this.comm = comm;
	}
//business method
	@Override
	public Double calculateSalary() {
		Double totalSal=empSal+bonus+comm;////protected is available to all the classes within the same package
		//and to the subclass outside the package
		System.out.println("*****SalesManager's calculateSalary invoked....");
		return totalSal;//best practice
	}

	// override toSTring Method
	@Override
	public String toString() {
		return "SalesManager [comm=" + comm + ", toString()=" + super.toString() + "]";
	}
	
	// co-variant return type
	// return type can be of subclass-type
	// it can be of type Employee/Manager or child classtype i.e. SalesManager
	@Override
	public SalesManager getEmployee() {
		return this;
		// this refers to current object so it will return current SalesManager object
		// which has call getEmployee method
	}

	// override print method
	@Override
	public SalesManager print() {
		System.out.println("==========================================================================\n"
				+ "\n 						SalesManager comm=" + comm);
		super.print();
		return this;//returning salesmanager object
	}

	// generate getters and setters
	public Double getComm() {
		return comm;
	}

	public void setComm(Double comm) {
		this.comm = comm;
	}

	
}
