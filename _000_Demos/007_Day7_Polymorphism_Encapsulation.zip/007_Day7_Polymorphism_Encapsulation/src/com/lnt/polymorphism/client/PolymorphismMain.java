/**
 * 
 */
package com.lnt.polymorphism.client;
//package are used to organize your related java types(class,interface,enum)
//package also resolves naming conflict
//meaningful package name
//package name are always reverse of domain name
//package name are always in lower_case separated by underscore
//eg: com.lnt.emp_project.model.emp
import com.lnt.polymorphism.model.emp.Employee;
import com.lnt.polymorphism.model.emp.mgr.Manager;
import com.lnt.polymorphism.model.emp.mgr.sales.SalesManager;

/**
 * @author Smita
 *
 */
public class PolymorphismMain {
	public static void main(String[] args) {
		Employee e1 =new Employee("Zara",999.99);
		/*new keyword does 3 task
		 * 1> create object
		 * 2> allocates memory on heap
		 * 3> invoke constructor to initialize the newly created object 
		 */
		System.out.println("\nTotal Salary of e1 "+e1.getEmpName()+" is : "+e1.calculateSalary()+"\n");
		//which calculateSalary () method will be invoked... 
		//let achieve polymorphic behaviour
		e1=new Manager("Sia", 8888.88, 100.00);
		System.out.println("\nTotal Salary of e1 "+e1.getEmpName()+" is : "+e1.calculateSalary()+"\n");
	//	System.out.println( " and Bonus is: "+e1.getBonus());//error
		//if method is not present in employee class but present in mgr class .it will give compiler error
		//which getEmpName () method will be invoked... 
		//which calculateSalary () method will be invoked... 
		e1= new SalesManager("Raj", 777.77, 100.00, 40.00);
		System.out.println("\nTotal Salary of e1 "+e1.getEmpName()+ " is "+e1.calculateSalary()+"\n");
	}

}








