/**
 * 
 */
package com.lnt.java_day05.arm;

/**
 * @author brije
 *
 */
//java 7 onwards there are two interfaces AutoColosable
public class Door implements AutoCloseable{//will invoke the close method automatically
	public void open() {
		System.out.println("*****opening the Door.....");
	}
	@Override
	public void close() {
		System.out.println("*****Close the Door.....");
	}
	public static void main(String[] args) {
		try(Door d1 = new Door();
				Windows w1 = new Windows();//error	
				){//try with resource block, 
			//it handles only those classes which has implemented either CLosable or AutoClosable interface
			//and the close will be invoked automatically 
			//this is known as ARM -automatic resource management
			d1.open();
		}catch (Exception e) {
			e.printStackTrace();
		}
		//d1.close();//i want the door to be closed automatically
	}
}
//
class Windows implements AutoCloseable{
	public void open() {
		System.out.println("*****opening the Windows.....");
	}
	public void close() {
		System.out.println("*****Close the Windows.....");
	}
}
