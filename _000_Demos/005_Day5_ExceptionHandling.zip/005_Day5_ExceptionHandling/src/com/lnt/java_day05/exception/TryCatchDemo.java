/**
 * 
 */
package com.lnt.java_day05.exception;

/**
 * @author Smita
 *
 */
public class TryCatchDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int n1,n2,div=0;//local var must be initialized before use
		//accepting numbers from Command line arguments
		String name=null;
		try {
			System.out.println("Name is : "+name);
			//
			n1= Integer.parseInt(args[0]);
			n2= Integer.parseInt(args[1]);
			
		//always initialize the var outside try block (best practice)
		//any thing initialized inside try will be available only within try block,
			div= n1/n2;//this line of code is expected to throw exception... must be wrapped or put inside try catch block
			//try block must be either followed by catch block or finally block
			System.out.println("Name is : "+name.toUpperCase());
		}catch(ArithmeticException ae) {
			System.out.println("Number connot be divisible by ZERO.");
		}catch(ArrayIndexOutOfBoundsException e){
			System.out.println("Command line argument not passed...");
		}catch(NumberFormatException e){
			System.out.println("the Argument passed must be only numeric type...");
		}catch (Exception e) {//top in the exception hierarchy
			System.out.println("Sorry Boss ...Something went wrong");
		}
		finally {
		//finally block which will be executed always 
		//whether exception occurs or not
			System.out.println("\n_____________________________________________________________\n"
					+ "Thanks for using our application, closing files and db ....\n"
					+ "and realsing all other resources before application exit!!\n"
					+ "\n_____________________________________________________________\n");
			
			//the code to release resources like closing of file
			//closing of Database connection
			//any resource which needs to be closed
		}
		System.out.println("Division of two numbers is : "+div);
	}

}
