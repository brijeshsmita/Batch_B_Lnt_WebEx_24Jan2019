/**
 * 
 */
package com.lnt.java_day05.throws_demo;

/**
 * @author brije
 *
 */
public class ThrowsDemo {

	/**
	 * @param args
	 * @throws ClassNotFoundException 
	 */
	//we can handle the exception either using try-ctach or throws keyword
	public static void main(String[] args) throws ClassNotFoundException{
		// lets load the class dynamically
		try {
			Class c=Class.forName("com.lnt.java_day05.throws_demo.MyClass");
			System.out.println("Class loaded dynamically : "+c.getName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Class does not exists!!!");
		}
		//checked Exception also known compile-time exception
		//it will force you to handle it at the compile time itself

	}

}
