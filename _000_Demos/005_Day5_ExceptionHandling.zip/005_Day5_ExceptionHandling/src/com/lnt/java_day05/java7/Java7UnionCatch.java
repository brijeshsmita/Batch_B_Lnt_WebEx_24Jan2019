/**
 * 
 */
package com.lnt.java_day05.java7;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author Smita
 *
 */
public class Java7UnionCatch {
	public static void main(String[] args) {
		//standard try catch block
		/*Scanner scan=null;
		try {
			scan= new Scanner(new File("src/demo1.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		//try with resource block
		try(Scanner scan = new Scanner(new File("src/demo1.txt"));){
			System.out.print(Integer.parseInt(scan.nextLine()));
		} catch (FileNotFoundException | NumberFormatException e) {
			//multi-catch or union catch block java7 onwards
			System.err.println(e.getMessage());
		}finally {
			System.out.println("\nbbye");
		}
	}

}
