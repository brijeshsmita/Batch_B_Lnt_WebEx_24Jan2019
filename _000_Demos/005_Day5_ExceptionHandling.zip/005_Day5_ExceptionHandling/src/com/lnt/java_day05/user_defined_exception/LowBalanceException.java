/**
 * 
 */
package com.lnt.java_day05.user_defined_exception;

/**
 * @author Smita
 *
 */
//step 1: creating user defined Exception class by Extending from Exception
public class LowBalanceException extends Exception {
	//step 2: provide no-arg constructor
	public LowBalanceException() {
		// TODO Auto-generated constructor stub
	}
	//step 3: provide parameterized- constructor with String as a parameter
	public LowBalanceException(String msg){
		//step 4: invoke super class constructor by passing string msg
		super(msg);//super is a keyword in java which is used to invoke parent class constructor/method
	}
}
