/**
 * 
 */
package com.lnt.java_day05.user_defined_exception;

import com.lnt.java_day05.account.Account;

/**
 * @author brije
 *
 */
public class TestUserDefinedException {
	public static void main(String[] args) {
		//lets create Account object and invoke withdraw method
		Account a1 = new Account("Zara", 100.00);
		//print acc details
		a1.print();
		//now lets withdraw
		try {
			a1.withDraw(200.00);//it will ask the use to handle the exception...as wihdraw method is throwing exception
		} catch (LowBalanceException e) {
			System.out.println(e.getMessage());
		}finally {
			//finally block which will be executed always 
			//whether exception occurs or not
				System.out.println("\n_____________________________________________________________\n"
						+ "Thanks for using our Banking application, closing files and db ....\n"
						+ "and realsing all other resources before application exit!!\n"
						+ "\n_____________________________________________________________\n");
				
				//the code to release resources like closing of file
				//closing of Database connection
				//any resource which needs to be closed
			}
	}
}
