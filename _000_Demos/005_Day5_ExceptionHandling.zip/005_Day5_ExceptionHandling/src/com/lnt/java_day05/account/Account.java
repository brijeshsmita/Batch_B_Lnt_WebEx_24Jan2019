/**
 * 
 */
package com.lnt.java_day05.account;

import javax.security.auth.login.LoginException;

import com.lnt.java_day05.user_defined_exception.LowBalanceException;

//step 1: package declaration (one/none)
//step 2: imports (many/none)
/**
 * @author brije
 *
 */
//step 3: public class
public class Account {
	//step 4: private instance variables	
	private Integer accountId;
	private String accHolderName;
	private Double balance;
	//step 5: private static variables
	private static Integer numId;
	//step 6: static initializer block
	static {
		System.out.println("************static initializer block of Account class invoked...only once as it is single copy per class*****************");
		//we want auto-generate accountId 
		//therefore we are storing the auto-generated number in numId and then will assign to accountId
		numId=  (int) (10000+ Math.random()*123.123);//auto-boxing (primitive is wrapped to Object
		//we are generating a random number using Math.random and adding it to 10000
		//then converting it to int
		//then assigning it to numId
	}
	//step 7:  initializer block
	{
		System.out.println("************init block of Account class invoked...for every object*****************");
		//we will not assign the auto-generated numId to accountId
		accountId=numId++;
	}
	/*
	 * Constructor is a special kind of method
	 * 1> which has the SAME NAME of the CLASS NAME
	 * 2> which has NO RETURN TYPE (not even void)
	 * 3> which is used to initialize newly created Object
	 * 4> can be overloaded
	 * 5> cannot be inherited
	 * 6> can throw Exceptions
	 * 7> invoked automatically as per arguments passed at the time of creating an object
	 */
	//step 8: no_arg constructor
	public Account() {
		System.out.println("************no_arg constructor of Account class invoked...for every object*****************");
		//initialize newly created Object
		accHolderName="unknown";
		balance=0.0;
	}
	//step 9: overloaded/parameterized constructor
	public Account(String accHolderName, Double balance) {
		super();//at time of inheritance
		System.out.println("************Parameterized constructor of Account class invoked...for every object*****************");
		this.accHolderName = accHolderName;
		this.balance = balance;
	}
	//constructor with ...specific parameter only
	public Account(String accHolderName) {
		super();
		this.accHolderName = accHolderName;
		this.balance=0.0;
	}
	//step 10: toSTring
	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accHolderName=" + accHolderName + ", balance=" + balance + "]";
	}
	
	//step 11: business methods
	public void print() {
		// this is a keyword in java- which refers to current Object
		// no need of explicitly writing this ... it s already available
		System.out.println(
				"\n============================================================================================================================================\n"
						+ "\n                                  Account Details"
						+ "\n============================================================================================================================================\n"
						+ "\n            			Account Id          : " + accountId
						+ "\n            			Account Holder Name : " + accHolderName
						+ "\n            			Balanace            : " + balance

						+ "\n============================================================================================================================================\n");
	}
	public Double checkBalance() {
		return balance;
	}
	//inform the withdraw method that if exception occurs then it will handled by LowBalanceException class
	//using throws keyword
	//lets create LowBalanceException class by extending Exception
	//re-usability of code
	//extending the properties and behavior of parent class to child class
	public void withDraw(Double amount)throws LowBalanceException {
		if(balance>amount) {
			balance-=amount;// balance = balance-amount;
			System.out.println("Withdraw successful !! ");
		}
		else {
			//is any in-build exception class to handle such type of scenario
			//in such scenario . we can create our own Exception Class
			//delegate of execution will be made to LowBalanceException class to handle it
			throw new LowBalanceException("Balance is low ... withdraw cannot be possible... "
					+ "\nAs Your balance is : "+balance
					+"\n And the withdraw amount is : "+amount);
		}
	}
	
}






