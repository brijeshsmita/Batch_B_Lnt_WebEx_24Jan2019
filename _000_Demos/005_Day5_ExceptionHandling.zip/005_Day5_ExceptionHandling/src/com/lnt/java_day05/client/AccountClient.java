/**
 * 
 */
package com.lnt.java_day05.client;

import com.lnt.java_day05.account.Account;

/**
 * @author Smita
 *method - name,return type, parameters,values,exceptions
 */
/*
 * ()- parenthesis
 * {}- braces
 * []- brackets
 */
public class AccountClient {
	public static void main(String[] args) {
		// let us create an oBject of Account class
		Account a1 = new Account();//invoked constructor
		//objectName.methodName();
		//a1.init();
		a1.print();
		Account a2 = new Account("Smita",1000.99);//at the time of creation of an object 
		//parameter is passed - compiler will try to invoke a construct which takes String and double as args
		a2.print();
		Account a3 = new Account("Brijesh",9999.88);//invoked constructor
		a3.print();
		Account a4 = new Account("Shivansh");//invoked constructor
		a4.print();
		//internally constructing an Object of account class
		//by invoking a constructor
		//if the class dosen't contain ANY constructor, then java compiler generate a default constructor
		//if it contains then the specific constructor will be invoked
/*
 * Constructor is a special kind of method
 * 1> which has the SAME NAME of the CLASS NAME
 * 2> which has NO RETURN TYPE (not even void)
 * 3> which is used to initialize newly created Object
 * 4> can be overloaded
 * 5> cannot be inherited
 * 6> can throw Exceptions
 * 7> invoked automatically as per arguments passed at the time of creating an object
 *
 */
		//lets invoke 
	}

}
