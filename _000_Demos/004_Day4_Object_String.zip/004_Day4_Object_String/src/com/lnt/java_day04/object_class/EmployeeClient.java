/**
 * 
 */
package com.lnt.java_day04.object_class;

/**
 * @author Smita
 *
 */
public class EmployeeClient {
	//main is the execution point to a class
	//keep the main method in a seprate class as it is the client code
	public static void main(String[] args) {
		// lets create an Object of employee
		Employee e1 = new Employee();
		Employee e2 = new Employee();
		//every object is create on heap and its reference local var is created on stack\
		//and as an object get created java compiler provides a unique hashCode to every object created
		System.out.println("e1 : "+e1);//callback is happening
		System.out.println("e2 : "+e2.toString());//callback is happening
		/*
		 * whenever you try to print an Object ... it gives a callback to the toString() method which
		 * return the String representation of an Object 
		 * Firstly it will check the toString() method of the class , if it is not available then , 
		 * will invoke the toString() method of an Object class.
		 * a string representation of the object.
    
		    public String toString() {
		        return getClass().getName() + "@" + Integer.toHexString(hashCode());
		        //com.lnt.java_day04.object_class.Employee@7852e922
		    }
		*/
	}

}
