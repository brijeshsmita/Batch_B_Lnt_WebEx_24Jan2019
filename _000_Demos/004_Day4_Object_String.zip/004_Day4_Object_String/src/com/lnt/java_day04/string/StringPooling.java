/**
 * 
 */
package com.lnt.java_day04.string;

/**
 * @author Smita
 *
 */
public class StringPooling {
	public static void main(String[] args) {
		// every String is by default stored on heap
		//strings are case sensitive 
		String str1="India";
		//compiler encounters the same vaule
		String str2="India";
		String str3="India";
		String str="INDIA";
		//when the value of the string is same then internally compiler create a String pool
		//all the reference var will refer the same pool\//String pool helps in saving lots of space for java runtime
		String str4="LNT";
		System.out.println("str.hashCode() : "+str.hashCode());
		System.out.println("str1.hashCode() : "+str1.hashCode());
		System.out.println("str2.hashCode() : "+str2.hashCode());
		System.out.println("str3.hashCode() : "+str3.hashCode());
		System.out.println("str4.hashCode() : "+str4.hashCode());

	}

}
