/**
 * 
 */
package com.lnt.java_day04.string;

import com.lnt.java_day04.object_class.Employee;

/**
 * @author brije
 *
 */
public class StringEquality {

	public static void main(String[] args) {
		Employee e1 = new Employee();
		Employee e2 = new Employee();
		//did we defined any equals method in employee class , 
		//so it will check the parent class i.e Object class
		//equals method of Object class checks the equality on the basis of hashCode
		if(e1.equals(e2)) {
			System.out.println("Both EMployees are equals");
		}else {
			System.err.println("Both EMployees are NOT equals");
		}
		System.out.println("\nHashcode of e1 : "+e1.hashCode());
		System.out.println("Hashcode of e2 : "+e2.hashCode());
		String s1 = new String("India");//STring class equlas method compares value rather then hashCode
		//case sensitive
		String s2 = new String("INDIA");
//equals method of String class checks the equality on the basis of Value not hashCode
		if(s1.equals(s2)) {
			System.out.println("Both String are equals in terms of value");
		}else {
			System.err.println("Both String are NOT equals in terms of value");
		}
//check the equality by igoring the case sensitivy
		if(s1.equalsIgnoreCase(s2)) {
			System.out.println("check the equality by igoring the case sensitivy");
		}
// == operator checks the equality on the basis of hashCode ,avoid using == with string
		//always use equals to check String equality
		if(s1==s2) {
			System.out.println("Both String are equals in terms of HashCode");
		}else {
			System.err.println("Both String are NOT equals in terms of HashCode");
		}
	}
}
