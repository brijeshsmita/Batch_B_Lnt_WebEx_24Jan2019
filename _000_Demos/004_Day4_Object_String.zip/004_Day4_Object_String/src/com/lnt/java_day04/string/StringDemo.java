/**
 * 
 */
package com.lnt.java_day04.string;

/**
 * @author brije
 *
 */
public class StringDemo {
	public static void main(String[] args) {
		//1> String is a class in java
		String str = new String("Lnt");
		//2> in case of String class ... it can be treated as primitive i.e declared with using new keyword
		String str1 ="Lnt";//object of the string class , we can create it without new
		// 3> String is a first class object in java , as it is always created on heap weather you use new keyword or not.
		System.out.println("str1 : "+str1+" and hashCode is : "+str1.hashCode());
		// 4> we can use + operator in String for String concatenation
		str1+=" Infotech";
		// 5>String Object are immutable Object - any changes made to a string object will create a new Object every time.
		System.out.println("str1 after concatenation : "+str1+" and hashCode is : "+str1.hashCode());
		// 6> String Operations
		str1 =str1.toLowerCase();
		System.out.println("str1.toLowerCase() : "+str1+" and hashCode is : "+str1.hashCode());
		str1 =str1.toUpperCase();
		System.out.println("str1.toUpperCase() : "+str1+" and hashCode is : "+str1.hashCode());
		System.out.println("str1.length() : "+str1.length()+" and hashCode is : "+str1.hashCode());
		//lnt infotech
		System.out.println("str1.substring(4, 8) : "+str1.substring(4, 8)+" and hashCode is : "+str1.hashCode());
		//index starts from 0 ... substring will print from startIdex to endIndex excluding the endIndex  
		/*
		 * @param      beginIndex   the beginning index, inclusive.
		 * @param      endIndex     the ending index, exclusive.
		 */
		System.out.println("str1.charAt(4) : "+str1.charAt(4));//String index starts at 0
		//if index not present the throws exception java.lang.StringIndexOutOfBoundsException
		System.out.println("str1.indexOf('I') : "+str1.indexOf('I'));
		//if the character does not exists then print -1
		System.out.println("str1.indexOf('Z') : "+str1.indexOf('Z'));
		//what is the role of intern() method ?
	}

}
