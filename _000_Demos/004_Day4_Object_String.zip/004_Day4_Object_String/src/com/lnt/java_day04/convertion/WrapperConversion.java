/**
 * 
 */
package com.lnt.java_day04.convertion;

import com.lnt.java_day04.object_class.Employee;

/**
 * @author brije
 *
 */
public class WrapperConversion {
	public static void main(String[] args) {
		// accept values from command line arguments
		//at the time of running the program , the value passed is known as command line arguments
		//these values are always accepted in STring format and get stored in the main method arguments
		//String [] args
		
		
		System.out.println("Accepted name from command line argumets ... Hello , "+ args[0]);
		int age = Integer.parseInt(args[1]);// we can accept only string as a command line Arguments
		//converting the STring to Integer
		System.out.println("Accepted Age from command line argumets ... Age , "+ age);
		//we are using spaces to pass more than 1 cmd line arguments

	}

}
