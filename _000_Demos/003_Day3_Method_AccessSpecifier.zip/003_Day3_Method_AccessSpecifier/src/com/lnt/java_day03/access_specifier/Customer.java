/**
 * 
 */
package com.lnt.java_day03.access_specifier;

import java.util.Date;

/**
 * @author brije
 *
 */
//all top level class can only marked as public- or it can have default/package level access
//public class name and the .java file name must be same
//public means - accessible with the package as well outside the package to all the class
//if you dont provide any modifier then the access level become default/package
//default/package access level mean , class will be available only to the class within the same package not outside the package
public class Customer {
	// instance variable - all the object/instance will have it own copy of variable
	private int customerId; // instance variable of type int

	// (int byte short long float double boolean char)
	private String firstName;// reference instance variable of type String class
	private String lastName;
	private String email;
	private String phoneNo;
	private String address;
	private static String countryName;
	static {
		countryName="India";
	}

	

	public void print() {
		// this is a keyword in java- which refers to current Object
		// no need of explicitly writing this ... it s already available
		System.out.println(
				"\n============================================================================================================================================\n"
						+ "\n                             Customer Details"
						+ "\n============================================================================================================================================\n"
						+ "\n            			Customer Id   : " + this.customerId
						+ "\n            			First Name   : " + this.firstName
						+ "\n            			Last Name    : " + this.lastName
						+ "\n            			Email        : " + this.email
						+ "\n            			Phone Number : " + this.phoneNo
						+ "\n            			Adress       : " + this.address

						+ "\n============================================================================================================================================\n");
	}

	// static methods- class method (will have class reference rather then object
	// reference	
	public static void showtodaysDate() {
		System.out.println("Today's Date : "+new Date());
				
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public static String getCountryName() {
		return countryName;
	}

	public static void setCountryName(String countryName) {
		Customer.countryName = countryName;
	}

}
