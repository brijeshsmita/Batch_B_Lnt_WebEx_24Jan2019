/**
 * 
 */
package com.lnt.java_day03.methods;

/**
 * @author brije
 *
 */
public class Trainee {
	//instance variable - all the object/instance will have it own copy of variable
		private int traineeId; //instance variable of type int
		
		//(int byte short long float double boolean char)
		private String firstName;//reference instance variable of type String class
		private String lastName;
		private String email;
		private String phoneNo;
		private String address;
		private static String coName;//all will have same coName 
		//static variable have single copy per class
		//it can be access with class reference
		//only instance variable can be static
		//we cannot declare local variable as static
		//static variable are having class reference- is also known as class variable	
		//static initializer block- to initialize only static variables
		//it is invoked before creation of an object
		static {
			coName="Lnt Infotech";
		}//static variable must be accessed with class reference (else warning)
		
		public void print(){
			//this is a keyword in java- which refers to current Object
			//no need of explicitly writing this ... it s already available 
			System.out.println(
					 "\n============================================================================================================================================\n"
					+"\n                             Trainee Details"
					+"\n============================================================================================================================================\n"
					+ "\n            			Trainee Id   : "+this.traineeId
					+ "\n            			First Name   : "+this.firstName
					+ "\n            			Last Name    : "+this.lastName
					+ "\n            			Email        : "+this.email
					+ "\n            			Phone Number : "+this.phoneNo
					+ "\n            			Adress       : "+this.address
					+ "\n            			Co Name      : "+Trainee.coName
					+"\n============================================================================================================================================\n");
		}//static variable/methods have class refrence , if you give object reference then conpiler will give warning
		//static methods 
		public static void main(String[] args) {
			Trainee t1 = new Trainee();
			t1.firstName="Ayush";
			t1.address="Mumbai";
			t1.print();//dot operator is used to call the method
			
			Trainee t2 = new Trainee();
			t2.firstName="Swathi";
			t2.print();
		}
}
