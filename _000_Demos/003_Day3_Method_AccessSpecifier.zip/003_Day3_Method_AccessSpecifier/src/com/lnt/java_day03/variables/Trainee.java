/**
 * 
 */
package com.lnt.java_day03.variables;

import java.util.Date;

/**
 * @author Smita
 *
 */
public class Trainee {
	//instance variable - all the object/instance will have it own copy of variable
	private int traineeId; //instance variable of type int
	
	//(int byte short long float double boolean char)
	private String firstName;//reference instance variable of type String class
	private String lastName;
	private String email;
	private String phoneNo;
	private String address;
	
	public static void main(String[] args) {
	
		int choice=1;//local variable of type int
		Date todaysDate=null;//reference local variable of type java.util.Date
		System.out.println("Choice is : "+choice);
		//lets create an instance/object of a class Trainee
		Trainee trainee1 = new Trainee();
		//new keyword is used to create an instance/object of a class
		/*
		 * 1> it creates object on head
		 * 2> invoke constructor
		 * 3> allocates memory
		 */
		Trainee trainee2 = new Trainee();
		//todaysDate= new Date();
		System.out.println(" todaysDate : "+todaysDate);
		
		Object objRef =null;
	}
}
