/**
 * 
 */
package com.lnt.java_day03.static_methods;

/**
 * @author brije
 *
 */
public class Customer {
	// instance variable - all the object/instance will have it own copy of variable
	private int customerId; // instance variable of type int

	// (int byte short long float double boolean char)
	private String firstName;// reference instance variable of type String class
	private String lastName;
	private String email;
	private String phoneNo;
	private String address;

	public void print() {
		// this is a keyword in java- which refers to current Object
		// no need of explicitly writing this ... it s already available
		System.out.println(
				"\n============================================================================================================================================\n"
						+ "\n                             Customer Details"
						+ "\n============================================================================================================================================\n"
						+ "\n            			Customer Id   : " + this.customerId
						+ "\n            			First Name   : " + this.firstName
						+ "\n            			Last Name    : " + this.lastName
						+ "\n            			Email        : " + this.email
						+ "\n            			Phone Number : " + this.phoneNo
						+ "\n            			Adress       : " + this.address

						+ "\n============================================================================================================================================\n");
	}

	// static methods- class method (will have class reference rather then object
	// reference
	public static void greet(String message) {
		System.out.println(
				message + " ...Hello I am a static method ..having class reference rather then object reference");
	}
	public static void main(String[] args) {
		Customer.greet("Welcome...");
		
		Customer c1 = new Customer();
		c1.firstName="Swathi";//private member are accessible only within the class not outside the class
		//firtName is private - cannot be accessed outside the class
	}
}
