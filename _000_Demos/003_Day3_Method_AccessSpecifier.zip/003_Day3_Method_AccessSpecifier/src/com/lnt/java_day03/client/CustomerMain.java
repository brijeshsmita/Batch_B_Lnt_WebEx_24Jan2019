/**
 * 
 */
package com.lnt.java_day03.client;

import com.lnt.java_day03.access_specifier.Customer;

/**
 * @author Smita
 *
 */
public class CustomerMain {		
	public static void main(String[] args) {
		Customer.showtodaysDate();
		Customer c1 = new Customer();
		//c1.firstName="Swathi";//error
		c1.setFirstName("Swathi");//setting the firstName
		//firtName is private - cannot be accessed outside the class
		//in certain scenario when we have to provide access to the private member outthe class
		//we generate getter/setters also known as accessor/mutators
		//all private instance variable must have getters and setters
		c1.print();
		//c1.getCountryName();//static method need class reference
		System.out.println("Country Name :"+Customer.getCountryName());
	}
}
