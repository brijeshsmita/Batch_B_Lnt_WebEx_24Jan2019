/**
 * 
 */
package com.lnt.interface_demo.service;

import java.util.List;

import com.lnt.interface_demo.model.emp.Employee;

/**
 * @author brije
 *
 */
//interface name must be in PascalCase
//even class name is in PasacalCase , so to diffentiate , we prefix it with capital 'I'
public interface IEmployeeService {
	//no implementation
	//by default all interface are abstract
	//by default all method in an interface are public and abstract
	Employee searchEmployeeById(Integer empId);
	Integer addEmployee(Employee employee);
	Integer deleteEmployee(Integer empId);
	Employee updateEmployee(Employee employee);
	List<Employee> listAllEmployee();
	//java 8 onward interface can have default and static method 
}
