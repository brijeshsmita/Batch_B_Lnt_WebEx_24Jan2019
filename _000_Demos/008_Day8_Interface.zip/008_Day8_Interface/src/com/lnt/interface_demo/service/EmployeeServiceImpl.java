/**
 * 
 */
package com.lnt.interface_demo.service;

import java.util.List;

import com.lnt.interface_demo.model.emp.Employee;

/**
 * @author brije
 *
 */
//to inherit interface ewe use implements keyword
public class EmployeeServiceImpl implements IEmployeeService{
	//golden rule- a class implementing an interface must override all the abstract method
	@Override
	public Employee searchEmployeeById(Integer empId) {
		System.out.println("searching Employee By Employee Id");
		return null;
	}

	@Override
	public Integer addEmployee(Employee employee) {
		System.out.println("Adding Employee...");
		return employee.getEmpId();
	}

	@Override
	public Integer deleteEmployee(Integer empId) {
		System.out.println("Deleteing Employee By Employee Id");
		return empId;
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		System.out.println("Updating Employee ....");
		return null;
	}

	@Override
	public List<Employee> listAllEmployee() {
		System.out.println("Fetching the list of all Employees ....");
		return null;
	}
	

}
