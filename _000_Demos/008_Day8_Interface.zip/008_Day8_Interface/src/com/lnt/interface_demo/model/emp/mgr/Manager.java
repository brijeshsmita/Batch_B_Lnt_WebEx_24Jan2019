/**
 * 
 */
package com.lnt.interface_demo.model.emp.mgr;

import com.lnt.interface_demo.model.emp.Employee;

/**
 * @author Smita
 *
 */
public class Manager extends Employee{//Inheritance
	//inherits all the properties and method of parent class
	//instance variables
	protected Double bonus;
	//no_arg Constructor
	public Manager() {
		//by default call to super is made 
		//super(); //super without parameter
		//whether you explicitly invoke super or not.... super is by default there
		System.out.println("*****Manager class no-arg constructor*******");
		this.bonus =0.0;
	}
	//overloaded constructor
	public Manager(String empName, Double empSal, Double bonus) {
		//call to super in constructor must be first line of code
		super(empName, empSal);//super with parameter therefore it will invoke super clas overlaoded constr
		//call to super in case of constructor must be first line of code
		System.out.println("*****Manager class Overloaded constructor*******");
		this.bonus = bonus;
	}
	//override - same method name, same arg list, same return type
	//(return type may be of sub-type -known as co-variant return type)
	//with different implementation 
	//polymorphism -> different object (EMployee,Manager, same method , different implementation
	@Override
	public Double calculateSalary() {//this method will calculate the totalSalary of Manager		
		Double totalSal=empSal+bonus ;//protected variable are available to the subclass
		System.out.println("*****Manager's calculateSalary invoked....");
		return totalSal;//best practice
	}
	/*@Override
	public Employee getEmployee() {
		// TODO Auto-generated method stub
		return super.getEmployee();
	}*/
	//co-variant return type (we can change the return type to sub-type)
	//else while overring method return type must be same
	@Override
	public Manager getEmployee() {
		// TODO Auto-generated method stub
		return this;//it will return current Object i.e Manager
	}
	@Override
	public void print() {
		// TODO Auto-generated method stub
				System.out.println("================================================================================\n"
						+ "\n                               Manager : Bonus "+bonus);
		super.print();
	}
	public Double getBonus() {
		return bonus;
	}
	public void setBonus(Double bonus) {
		this.bonus = bonus;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Manager : Bonus "+bonus+"\t"+super.toString() ;
		//super keyword is used to invoke parent/super class methods/constructor
	}
	
}
