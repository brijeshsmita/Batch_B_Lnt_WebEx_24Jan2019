/**
 * 
 */
package com.lnt.interface_demo.client;

import java.util.List;
import java.util.Scanner;

import com.lnt.interface_demo.model.emp.Employee;
import com.lnt.interface_demo.model.emp.mgr.Manager;
import com.lnt.interface_demo.service.EmployeeServiceImpl;
import com.lnt.interface_demo.service.IEmployeeService;

/**
 * @author brije
 *
 */
public class EmployeeClient {
	public static void main(String[] args) {
		//error//IEmployeeService service = new IEmployeeService();//we cannot instantiate an interface
		Scanner scan = new Scanner(System.in);
		IEmployeeService service = new EmployeeServiceImpl();
		Employee e1 = new Manager("Zara", 999.99, 100.00);
		int choice = 0;
		while(true) {
			System.out.println(
					"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
					+"                     Enter your choice from (1-6) \n"
					+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
					+"\n                       1> addEmployee" 
					+"\n                       2> searchEmployee"
					+"\n                       3> updateEmployee"   
					+"\n                       4> deleteEmployee"
					+"\n                       5> listAllEmployee"
					+"\n                       6> Exit"
					+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
			choice=scan.nextInt();
			switch(choice) {
			case 1: service.addEmployee(e1);
				break;
				
			case 2: service.searchEmployeeById(e1.getEmpId());
				break;
			case 3: service.updateEmployee(e1);
				break;
			case 4: service.deleteEmployee(e1.getEmpId());
				break;
			case 5: service.listAllEmployee();
				break;
			case 6: System.out.println(""
					+ "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
					+ "							Thank you for using our application"
					+ "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				System.exit(0);
				break;
			default:
				System.out.println("Sorry you have entered wrong option.... enter option from (1-6)");
			}
		}
		
	}
}
