package com.lnt.abstract_demo.account;
//we create abstract class to be further extended (to achieve extensibility of code)
//must be extended /inherited/sub-classed (opposite of final class)
//marked with abstract
//cannot be instantiated ( object of an abstract class cannot be created)
public abstract class Account {
	protected Integer accId;
	protected String accHolderName;
	protected Double accBalance;
	private static int numId;//to auto-generate empId
	static {
		System.out.println("*****Account class static block *******");
		numId= (int) (1000+ Math.random()*123*123);
		//empId=numId++;//error
		// non-static var cannot be accessed through static method/block directly (it need object reference)
	}
	//init block
	{
		System.out.println("*****Account class init block *******");
		accId= numId++;//static var can be accessed through non-static block
		//but non-static var cannot be accessed through static method/block directly (it need object reference)
	}
	//abstract class can have constructor- as for creating a child class object , 
	//always super class constructor is invoked
	
	public Account() {
		System.out.println("***Account no-arg costructor invoked.....");
		accHolderName="unknown";
	}

	public Account(String accHolderName, Double accBalance) {
		System.out.println("***Account overlaoded costructor invoked.....");
		this.accHolderName = accHolderName;
		this.accBalance = accBalance;
	}

	@Override
	public String toString() {
		return "Account [accId=" + accId + ", accHolderName=" + accHolderName + ", accBalance=" + accBalance + "]";
	}
	//when we can't provide any implementation to a method then it must be marked as abstract
	//abstract method does not have any body , and terminated with a semicolan
	//business method
	public abstract void withdraw(Double amount);/* {
		if(accBalance>amount)
			accBalance-=amount;
		else
			System.out.println("Withdrawal not possible...as it low balanace in your account...");
		
	}*/
	//abstract class can have both abstract as well as concrete method( method with implementation/body)
	public void print() {
		System.out.println(
				"\n============================================================================================================================================\n"
						+ "\n                             Account Details"
						+ "\n============================================================================================================================================\n"
						+ "\n            		Account Id            : " + this.accId
						+ "\n            		Account Holder Name   : " + this.accHolderName
						+ "\n            		Account Balance       : " + this.accBalance

						+ "\n============================================================================================================================================\n");

	}
}












