/**
 * 
 */
package com.lnt.abstract_demo.account.save;

import com.lnt.abstract_demo.account.Account;

/**
 * @author brije
 *
 */
//golden rule for inheriting abstract - a class inheriting an abstract class must override all the abstract method
//or declare the class itself as an abstract class
public class CurentAccount extends Account {
	private Double overdraftLimit;
	
	public CurentAccount() {
		System.out.println("***CurentAccount no-arg costructor invoked.....");
		overdraftLimit=0.0;
	}
	
	public CurentAccount(String accHolderName, Double accBalance, Double overdraftLimit) {
		super(accHolderName, accBalance);
		this.overdraftLimit = overdraftLimit;
		System.out.println("***CurentAccount no-arg costructor invoked.....");
	}

	@Override
	public void withdraw(Double amount) {
		if((accBalance+overdraftLimit)>amount) {
			accBalance-=amount;
			System.out.println("Withdrawal successful from your CurentAccount"
					+ "...The Current balanace in your account..."+accBalance);
		}
		else
			System.err.println("Withdrawal not possible from your CurentAccount"
					+ "\n you have crossed the Overdraft Limit " +
					"\n As per policy overdraftLimit should be maintained in your saving account must be : "+overdraftLimit);	

	}
	//upto your choice , you may or maynot override concrete method of an abstract class
	public void print() {
		System.out.println(
				"\n============================================================================================================================================\n"
						+ "\n                             CurentAccount Details"
						+ "\n============================================================================================================================================\n"
						+ "\n            		CurentAccount Overdraft Limit          : " + this.overdraftLimit

						+ "\n============================================================================================================================================\n");
		super.print();

	}
}
