/**
 * 
 */
package com.lnt.abstract_demo.account.save;

import com.lnt.abstract_demo.account.Account;

/**
 * @author Smita
 *
 */
//a class extending from an abstract class must override all the abstract method
//or declare itself as abstract
public class SavingAccount extends Account{
	private Double minBalance;
	public SavingAccount() {
		System.out.println("***SavingAccount no-arg costructor invoked.....");
		minBalance=0.0;
	}
	
	public SavingAccount(String accHolderName, Double accBalance, Double minBalance) {
		super(accHolderName, accBalance);
		System.out.println("***SavingAccount overloaded costructor invoked.....");
		this.minBalance = minBalance;
	}

	@Override
	public void withdraw(Double amount) {
		if((accBalance-minBalance)>amount) {
			accBalance-=amount;
			System.out.println("Withdrawal successful from your savingAccount"
					+ "...The Current balanace in your account..."+accBalance);
		}
		else
			System.err.println("Withdrawal not possible from your savingAccount"
					+ "...as it low balanace in your account..."+accBalance+
					"\n As per policy Minium Balance should be maintained in your saving account must be : "+minBalance);
		
	}
	//for non-abstract method compiler will never force to override
	public void print() {
		System.out.println(
				"\n============================================================================================================================================\n"
						+ "\n                             SavingAccount Details"
						+ "\n============================================================================================================================================\n"
						+ "\n            		SavingAccount Minimum Balance          : " + this.minBalance

						+ "\n============================================================================================================================================\n");
		super.print();

	}

}
