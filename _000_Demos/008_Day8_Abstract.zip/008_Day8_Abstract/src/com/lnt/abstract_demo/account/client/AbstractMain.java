/**
 * 
 */
package com.lnt.abstract_demo.account.client;

import com.lnt.abstract_demo.account.Account;
import com.lnt.abstract_demo.account.save.CurentAccount;
import com.lnt.abstract_demo.account.save.SavingAccount;

/**
 * @author brije
 *
 */
public class AbstractMain {
	public static void main(String[] args) {
		//error//Account a1 = new Account();
		//a1.withdraw();
		//abstract class annot be instantiated/object of abstract class cannot be created
		Account a1 = new SavingAccount("Zara", 1000.00, 100.00);
		a1.withdraw(100.00);
		a1.print();
		
		//lets create CurrentAccount 
		a1= new CurentAccount("Sia", 100.00, 15000.00);
		a1.withdraw(15000.00);
		a1.print();
	}
}
