package com.lnt.abstract_demo.shape.sqaure;

import com.lnt.abstract_demo.shape.Shape;

public class Square extends Shape{
	private Float sides;
	public Square() {
		// TODO Auto-generated constructor stub
	}
	
	public Square(Float sides) {
		super();
		this.sides = sides;
	}

	@Override
	public void draw() {
		System.out.println("Drawing a Square with a sides of "+sides);
	}

	@Override
	public double area() {
		System.out.println("Calculating Area of a SQuare with a sides of "+sides);
		
		return sides*sides;
	}
}
