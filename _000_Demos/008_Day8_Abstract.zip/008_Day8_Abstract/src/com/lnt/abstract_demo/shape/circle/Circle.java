/**
 * 
 */
package com.lnt.abstract_demo.shape.circle;

import com.lnt.abstract_demo.shape.Shape;

/**
 * @author brije
 *
 */
public class Circle extends Shape{
	private static Float PI=3.14f;
	private Float radius;

	public Circle() {
		// TODO Auto-generated constructor stub
	}
	
	public Circle(Float radius) {
		super();
		this.radius = radius;
	}

	@Override
	public void draw() {
		System.out.println("Drawing a circle with a radius of "+radius);
	}

	@Override
	public double area() {
		System.out.println("Calculating Area of a circle with a radius of "+radius);
		
		return PI*radius*radius;
	}

}
