/**
 * 
 */
package com.lnt.abstract_demo.shape.client;

import com.lnt.abstract_demo.shape.Shape;
import com.lnt.abstract_demo.shape.circle.Circle;
import com.lnt.abstract_demo.shape.sqaure.Square;

/**
 * @author brije
 *
 */
public class ShapeClient {
	public static void main(String[] args) {
		Shape shape = new Circle(12.4f);
		System.out.println(" Area of Circle : "+shape.area()+"\n");
		
		shape = new Square(12.4f);
		System.out.println(" Area of Square : "+shape.area()+"\n");
	}
}
