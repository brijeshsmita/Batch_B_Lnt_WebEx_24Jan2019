/**
 * 
 */
package com.lnt.abstract_demo.shape;

/**
 * @author brije
 *
 */
//abstract class cannot me instantiated
//it is used for futher extensibility of code
public abstract class Shape {
	//class containing an abstract method must be marked as abstract
	public abstract void draw();//draw method does have any implementation
		//which shape??? - draw a circle and a square
	
	public abstract double area();//calculate area of circle and square
	//public abstract double periphery();//calculate periphery
	
}
