/**
 * 
 */
package com.lnt.final_var;

/**
 * @author brije
 *
 */
public class Employee {
	private Integer empId;
	private String empName;
	//naming convention for final variable is ...ALL_UPPER_CASE separated with underscore
	private final static String CO_NAME; //must be initialize and cannot be re-initialized
	//can be initialized at the time of declaration/ in contructor/static block/ init block
	static {
		CO_NAME="Lnt Infotech ltd.";
	}
}
