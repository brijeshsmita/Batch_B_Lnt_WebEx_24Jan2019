/**
 * 
 */
package com.lnt.final_var;

/**
 * @author brije
 *
 */
class Calci{
	//non-access specifier are used after access specifier
	private final float PI;//=3.14f;//all float must be suffixed by f or F
	//1st rule-final variable must be initialized
	//3rd rule-final variable must be initialized at the time of declaration or within a constructor/static/init block
	//4th rule- when a final variable is initialized within a constructor/static/init block ... it is known as BLANK FINAL
	public Calci() {
		// lets change the value of PI
		PI=4.14f;//when the value of any variable is foxed or constant the mark that variable as final
		//2nd rule-final variable cannot be re-initialized
	}
}
public class FinalVariable {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
