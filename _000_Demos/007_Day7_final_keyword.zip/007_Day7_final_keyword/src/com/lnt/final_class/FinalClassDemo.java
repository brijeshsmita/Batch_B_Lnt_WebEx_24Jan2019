/**
 * 
 */
package com.lnt.final_class;

/**
 * @author brije
 *
 */
public class FinalClassDemo {
	public static void main(String[] args) {
		//final class can be instantiated
		//i.e we can create the object of final class
		Greetings g1 = new Greetings();
		System.out.println(g1.greet("Smita"));
	}
}

 final class Greetings{
	 public String greet(String name) {
		 return "Hello , "+name;
	 }
 }
//All Wrapper classes are final (int-Integer,char-Character,Byte,Short,Long,Float,Double,Boolean)
 /*
  * Final class cannot be extended/inherited/sub-classed
  * for example : String class in java is Final
  */
 /*class NewGreetings extends Greetings{
	 public String greet(String name) {
		 return "Welcome to Final inherited class... , "+name;
	 }
 }*/
 //error - because String class in java is final and that s why cannot be extended
/* class MyString extends String{
	 
 }*/