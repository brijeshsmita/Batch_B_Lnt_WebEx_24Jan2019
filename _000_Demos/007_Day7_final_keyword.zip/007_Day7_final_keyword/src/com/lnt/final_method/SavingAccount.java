/**
 * 
 */
package com.lnt.final_method;

/**
 * @author Smita
 *
 */
public class SavingAccount extends Account {
	private Double rateOfInterest;
	//let try to override final method
	//final method cannot be overridden
	//error
	/*public static final String getBankName() {
		return "My Bank Ltd.";
	}	*/
}
