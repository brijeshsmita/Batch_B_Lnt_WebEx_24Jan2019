/**
 * 
 */
package com.lnt.final_method;

/**
 * @author Smita
 *
 */
public class Account {
	private Integer accNo;
	private String accHolderName;
	private Double accBalance;
	private static final String BANK_NAME;//blank final
	static {
		BANK_NAME="Lnt Cooperative Bank";
	}
	//final variable does not have setters method
	public static final String getBankName() {
		return BANK_NAME;
	}	
	public Integer getAccNo() {
		return accNo;
	}
	public void setAccNo(Integer accNo) {
		this.accNo = accNo;
	}
	public String getAccHolderName() {
		return accHolderName;
	}
	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}
	public Double getAccBalance() {
		return accBalance;
	}
	public void setAccBalance(Double accBalance) {
		this.accBalance = accBalance;
	}
	
}
