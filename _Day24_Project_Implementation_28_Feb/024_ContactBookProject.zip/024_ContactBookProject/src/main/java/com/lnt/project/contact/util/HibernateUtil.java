/**
 * 
 */
package com.lnt.project.contact.util;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
/** * @author Smita B Kumar * */
public class HibernateUtil {
	private static SessionFactory sessionFactory;
	public static SessionFactory getSessionFactory() {
		if(sessionFactory==null) {
			sessionFactory=new Configuration().configure().buildSessionFactory();
		}
		return sessionFactory;
	}
	public static void setSessionFactory(SessionFactory sessionFactory) {
		HibernateUtil.sessionFactory = sessionFactory;
	}
	public static SessionFactory closeFactory(SessionFactory sessionFactory) {
		if(sessionFactory!=null) {
			sessionFactory.close();
			sessionFactory=null;
		}
		return sessionFactory;
	}
	public static void main(String[] args) {
		SessionFactory factory=getSessionFactory();
		try {
		if(factory!=null)
			System.out.println("Factory configured!!");
		else
			System.err.println("Factory NOT configured!!");
		}catch (Exception e) {
			e.printStackTrace();
		}
		factory=closeFactory(factory);
		if(factory==null)
			System.out.println("Factory closed!!");
		else
			System.err.println("Factory NOT closed!!");
	}
}
