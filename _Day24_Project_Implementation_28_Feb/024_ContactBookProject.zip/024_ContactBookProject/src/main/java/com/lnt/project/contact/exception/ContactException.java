/**
 * 
 */
package com.lnt.project.contact.exception;
/** * @author Smita B Kumar * */
public class ContactException extends Exception {
	private static final long serialVersionUID = -7500232798281989303L;
	public ContactException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ContactException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
