/**
 * 
 */
package com.lnt.project.contact.test;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import com.lnt.project.contact.dao.ContactDaoImpl;
import com.lnt.project.contact.dao.IContactDao;
import com.lnt.project.contact.entities.Contact;
import com.lnt.project.contact.exception.ContactException;
/** * @author Smita* */
public class TestContactDao {
	private static IContactDao contactDao;
	LocalDate localDate=LocalDate.of(2011, 11, 11);
	Date dob = Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
	Contact contact= new Contact("Smita", "Kumar", "7738206222",
			"smitakumar@synergetics-india.com", "Mumbai", dob);
	Integer contactId;
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		//inorder to call the method of ContactDaoImpl class , we should first create the object of ContactDaoImpl
		contactDao= new ContactDaoImpl();
	}	
	/**
	 * Test method for {@link com.lnt.contactBook.dao.ContactDaoImpl#addNewContact(com.lnt.contactBook.entities.Contact)}.
	 * @throws ContactException 
	 */
	@Test
	//@Ignore
	public void testAddNewContact() throws ContactException {
		contactId=contactDao.addNewContact(contact);
		contact.setContactId(contactId);
		assertTrue(contactId>0);
		System.out.println("Contact Persisted with Id : "+contactId);
	}
	/**
	 * Test method for {@link com.lnt.contactBook.dao.ContactDaoImpl#updateContact(com.lnt.contactBook.entities.Contact)}.
	 * @throws ContactException 
	 */
	@Test
	@Ignore
	public void testUpdateContact() throws ContactException {
		Contact updatedContact= new Contact("Yara", "Khan", "9999977777",
				"yarakhan@synergetics-india.com", "Hydrabad", dob);
		updatedContact.setContactId(6);//existing contact
		contact=contactDao.updateContact(updatedContact);
		System.out.println("Uodated Contact : "+contact);
	}
	/**
	 * Test method for {@link com.lnt.contactBook.dao.ContactDaoImpl#getAllContacts()}.
	 * @throws ContactException 
	 */
	@Test
	public void testGetAllContacts() throws ContactException {
		List<Contact> contactList=contactDao.getAllContacts();
		assertNotNull("No Contact Records Found!!", contactList);
		for (Contact contact : contactList) {
			System.out.println(contact);
		}
	}	
	/**
	 * Test method for {@link com.lnt.contactBook.dao.ContactDaoImpl#removeContact(com.lnt.contactBook.entities.Contact)}.
	 * @throws ContactException 
	 */
	@Test
	//@Ignore
	public void testRemoveContact() throws ContactException {
		contact=contactDao.removeContact(contact);
		assertNull("No Contact Records Found!!", contact);
		System.out.println("Deleted Contact : "+contact);
	}
	/**
	 * Test method for {@link com.lnt.contactBook.dao.ContactDaoImpl#searchContactByName(java.lang.String)}.
	 * @throws ContactException 
	 */
	@Test
	@Ignore
	public void testSearchContactByName() throws ContactException {
		String name ="Yara";
		Contact expected = contactDao.searchContactByName(name);
		assertNotNull("No Contact Records Found!", expected);
		System.out.println("Search Contact by Name "+name+": "+expected);
	}
	/**
	 * Test method for {@link com.lnt.contactBook.dao.ContactDaoImpl#searchContactById(java.lang.Integer)}.
	 * @throws ContactException 
	 */
	@Test
	@Ignore
	public void testSearchContactById() throws ContactException {
		Integer id =15;
		Contact expected = contactDao.searchContactById(id);
		assertNotNull("No Contact Records Found!", expected);
		System.out.println("Search Contact by Id "+id+": "+expected);
	}
	/**
	 * Test method for {@link com.lnt.contactBook.dao.ContactDaoImpl#terminateApplication()}.
	 * @throws ContactException 
	 */
	@AfterClass
	public static void testTerminateApplication() throws ContactException {
		Object obj=contactDao.terminateApplication();
		assertNull("Not able to terminate the Session Factory!!", obj);
		System.out.println("Session Factory Terminated : "+obj);
	}
}
