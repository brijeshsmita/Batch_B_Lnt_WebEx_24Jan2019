/**
 * 
 */
package com.lnt.project.contact.test;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import org.hibernate.SessionFactory;
import org.junit.Test;
import com.lnt.project.contact.util.HibernateUtil;
/** * @author Smita B Kumar * */
public class HibernateUtilTest {
	private static SessionFactory sessionFactory;
	/**
	 * Test method for {@link com.lnt.project.contact.util.HibernateUtil#getSessionFactory()}.
	 */
	@Test
	public  void testGetSessionFactory() {
		sessionFactory = HibernateUtil.getSessionFactory();
		assertNotNull("sessionFactory is null", sessionFactory);
	}
	/**
	 * Test method for {@link com.lnt.project.contact.util.HibernateUtil#closeFactory(org.hibernate.SessionFactory)}.
	 */
	@Test 
	public void testCloseFactory() {
		sessionFactory = HibernateUtil.closeFactory(sessionFactory);
		assertNull("sessionFactory not closed", sessionFactory);
	}
}
