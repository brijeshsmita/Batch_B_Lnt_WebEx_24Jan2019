/**
 * 
 */
package com.lnt.project.contact.service;
import java.util.List;
import com.lnt.project.contact.entities.Contact;
import com.lnt.project.contact.exception.ContactException;
/** * @author Smita B Kumar * */
public interface IContactService {
	public Integer addNewContact(Contact contact)throws ContactException;        //-Create   //add contact
	public List<Contact> getAllContacts()throws ContactException;                //-Retrieve //Get All contact
	public Contact updateContact(Contact updatedContact)throws ContactException; //-Update   //edit contact
	public Contact removeContact(Contact contact)throws ContactException;		  //-Delete   //remove contact
	public Contact searchContactByName(String name)throws ContactException;      //-Search   //find contact
	public Contact searchContactById(Integer contactId)throws ContactException;  
	public Object terminateApplication()throws ContactException;
	//if any vaidation or calculation to be performed 
	//then additional method to be provided at Service layer for the same 
}
