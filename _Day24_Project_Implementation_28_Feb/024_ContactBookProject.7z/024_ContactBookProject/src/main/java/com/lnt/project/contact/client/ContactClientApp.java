/**
 * 
 */
package com.lnt.project.contact.client;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import com.lnt.project.contact.entities.Contact;
import com.lnt.project.contact.exception.ContactException;
import com.lnt.project.contact.service.ContactServiceImpl;
import com.lnt.project.contact.service.IContactService;
/** * @author Smita B Kumar * */
public class ContactClientApp {
// prep work Step 1: create object of service inorder to invoke service methods
	// prep work Step 2:create object of Scanner and BufferedReader to accept input
	// from user
	private static IContactService contactService;
	static boolean status;
	static BufferedReader br;
	static {
		contactService = new ContactServiceImpl();
		status=true;
		br = new BufferedReader(new InputStreamReader(System.in));
	}

	public static void main(String[] args){
		try {
		selectChoice();
		}catch (Exception e) {
			System.err.println(new ContactException("Sorry Boss !, Something went Wrong while entering Input!!"+e));			
		}finally {
			if(br!=null)
				try {
					br.close();
				} catch (IOException e) {
					System.err.println(new ContactException("Sorry Boss !, Something went Wrong while entering Input!!"+e));
				}
		}	
	}
	public static void selectChoice(){
		// display the menu		
		int choice=0;	
		do{
			try {					
				displayMenu();	
				choice=Integer.parseInt(br.readLine());
				switch (choice) {
				case 1:
					System.out.println("Your have selected ...to Add New Contact");
					addContactDetails(br,new Contact());						
					break;
				case 2:
					System.out.println("Your have selected ...to List All Contacts");
					listAllContact();
					break;
				case 3:
					System.out.println("Your have selected ...to Update Existing Contact");
					updateContactDetails(br);					
					break;
				case 4:
					System.out.println("Your have selected ...to Search Contact By Id");
					getContactById(br);					
					break;
				case 5:
					System.out.println("Your have selected ...to Search Contact By Name");
					getContactByName(br);					
					break;
				case 6:
					System.out.println("Your have selected ...to Remove Contact");
					removeContact(br);
					break;
				
				case 7:
					System.out.println("Your have selected ...to Terminate the contact Application"
							+ "\n Thanks For Visting Our Aplication....Do Visit AGain !!");
					contactService.terminateApplication();	
					System.exit(0);
					break;
	
				default:
					System.out.println("Sorry Boss! you have entered a wrong choice....."
							+ "\nKindly Select Your Choice from (1-7)Numeric Only\n");
					break;
				}
				System.out.println("Hit 7 to Exit the Apllication ");
			}catch (ContactException e) {
				System.err.println("Sorry Boss !, Something went Wrong while accessing the Contact Book!!"+e);
				//scan.nextLine(); // clears the buffer	
				selectChoice();
			}catch (InputMismatchException e) {
				System.err.println("Sorry Boss !, Input Missmatched while entering Input!!"+e);
				selectChoice();
			}catch (IOException e) {
				System.err.println("Sorry Boss !, Something went Wrong while entering Input!!"+e);				
				selectChoice();
			}	
			catch (Exception e) {
				System.err.println("Sorry Boss !, Something went Wrong while entering Input!!"+e);				
				selectChoice();
			}
		}while(status);//end of while
	}
	private static void displayMenu() {
		System.out.println(
				"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
						+ "\n             Contact Book Application"
						+ "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
						+ " Select Your Choice from (1-7)Numeric Only\n" 
						+ "   			1. Add New Contact\n"
						+ "   			2. List AllContacts\n" 
						+ "   			3. Update Contact\n"
						+ "   			4. Search Contact By Id\n" 
						+ "   			5. Search Contact By Name\n" 
						+ "   			6. Remove Contact\n"
						+ "   			7. Exit\n"
						+ "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
	}
	private static Contact acceptContactDetails(BufferedReader br,Contact contact) throws ContactException {
		// accepting the contact details from user
		try {
			System.out.println("Enter Contact First Name : ");
			String firstName = br.readLine();
			System.out.println("Enter Contact Last Name : ");
			String lastName = br.readLine();
			System.out.println("Enter Contact email : ");
			String email = br.readLine();
			System.out.println("Enter Contact phoneNo : ");
			String phoneNo = br.readLine();
			System.out.println("Enter Contact Address : ");
			String address = br.readLine();
			LocalDate localDate = LocalDate.of(2011, 11, 11);
			Date dob = Date.from(localDate.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
			contact.setFirstName(firstName);
			contact.setLastName(lastName);
			contact.setEmail(email);
			contact.setPhoneNo(phoneNo);
			contact.setAddress(address);
			contact.setDob(dob);			

		} catch (Exception e) {
			System.out.println("Something went worng while accepting Contact Details!!");
		}

		return contact;
	}
	private static Contact addContactDetails(BufferedReader br,Contact contact) throws ContactException {
		// accepting the contact details from user
		Contact addedContact= acceptContactDetails(br,contact);
		int contactId = contactService.addNewContact(contact);
		if (contactId > 0) {
			System.out.println("Contact Added successfully with a unique contactId : " + contactId);
		} else {
			System.err.println("Sorry Boss !, Not able to persist the Contact Object in Contact Book");
		}
		return addedContact;
	}
	private static void listAllContact() {
		List<Contact> contactList = null;
		try {
			contactList = contactService.getAllContacts();
			if (contactList != null) {
				System.out.println("List Of all the Contact Records Found");
				contactList.forEach(System.out::println);// java 8
			} else {
				System.err.println("Sorry Boss !, No Contact Records found in the Contact Book");
			}
		} catch (ContactException e) {
			System.err.println("Sorry "
					+ "Boss !, No Contact Records found in the Contact Book" + e);
		}
	}
	private static Contact updateContactDetails(BufferedReader br) throws ContactException {
		// accepting the contact Id from user and checking weather user exists or not
		Contact updatedContact = getContactById(br);
		if (updatedContact != null) {				
			updatedContact= acceptContactDetails(br,updatedContact);			
			updatedContact = contactService.updateContact(updatedContact);
			if (updatedContact != null) {
				System.out.println("Contact Updated successfully  : " + updatedContact);
			} else {
				System.err.println("Sorry Boss !, Not able to Update the Contact Object in Contact Book");
			}
		}
		return updatedContact;
	}
	private static Contact  getContactById(BufferedReader br) throws ContactException{
		System.out.println("Enter the Contact Id to be Search....");
		Integer id=0;
		try {
			id = Integer.parseInt(br.readLine());
		} catch (IOException e) {
			System.out.println("Something went worng while accepting Contact Name!!");
			//selectChoice();
		}
		Contact searchedcontact=contactService.searchContactById(id);
		if(searchedcontact!=null) {
			System.out.println("Contact Found successfully  : "+searchedcontact);
		}else {
			System.err.println("Sorry Boss !, Not able to Find the Contact Object in Contact Book");
		}
		return searchedcontact;
	}
	private static Contact  getContactByName(BufferedReader br) throws ContactException{
		System.out.println("Enter the Contact Name to be Search....");
		String name=null;
		try {
			name = br.readLine();
		} catch (IOException e) {
			System.out.println("Something went worng while accepting Contact Name!!");
			//selectChoice();
		}
		Contact searchedcontact=contactService.searchContactByName(name);
		if(searchedcontact!=null) {
			System.out.println("Contact Found successfully  : "+searchedcontact);
		}else {
			System.err.println("Sorry Boss !, Not able to Find the Contact Object in Contact Book");
		}
		return searchedcontact;
	}		
	private static void removeContact(BufferedReader br) throws ContactException, IOException {
		System.out.println("Enter the contactId to be Deleted....");
		Integer id= Integer.parseInt(br.readLine());
		Contact contactFound=contactService.searchContactById(id);
		if(contactFound!=null) {
			Contact deletedContact= contactService.removeContact(contactFound);
			if(deletedContact==null) {
				System.out.println("Contact Removed successfully : "+contactFound);
				contactFound=null;
			}else {
				System.err.println("Sorry Boss !, Not able to remove the Contact Object from the Contact Book");
			}
		}else {
			System.err.println("Sorry Boss !, Not able to remove As Contact Onject Not Found");
		}		
	}	
}//end of class
