/**
 * 
 */
package com.lnt.day14.reflection;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * @author brije
 *
 */
public class AccessPrivateMethod2 {

	public static void main(String[] args) throws ClassNotFoundException, 
	InstantiationException, IllegalAccessException, 
	NoSuchMethodException, SecurityException,
	IllegalArgumentException, InvocationTargetException {
		//private is accessible only within the class not outside the class
		
		//lets resolve it using java.lang.reflect.Method class
		/*
		 * 1> setAccessibilitiy()
		 * 2> invoke()
		 */
		//load the class dynamically
		Class c1 = Action.class;//Class.forName("com.lnt.day14.reflection.Action");
		Action actionObj = (Action) c1.newInstance();//throws 	InstantiationException, IllegalAccessException
		
		Method method = c1.getDeclaredMethod("sceret", null);
		method.setAccessible(true);
		method.invoke(actionObj, null);
		
		method = c1.getDeclaredMethod("cube", new Class[] {int.class});//array of Class as a parameter
		method.setAccessible(true);
		method.invoke(actionObj, 5);//passing the value for the argument
		
		method = c1.getDeclaredMethod("max",new Class[] { int.class,int.class});//array of Class as a parameter
		method.setAccessible(true);
		System.out.println("The max of two numbers 10,20 is :  "+method.invoke(actionObj, 10,20));//passing the value for the argument
		
		method = c1.getDeclaredMethod("max",int.class,int.class);//array of Class as a parameter
		method.setAccessible(true);
		System.out.println("The max of two numbers 100,200 is :  "+method.invoke(actionObj, 100,200));//passing the value for the argument
	
		method = c1.getDeclaredMethod("printInfo",new Class[] { int.class,String.class});//array of Class as a parameter
		method.setAccessible(true);
		method.invoke(actionObj, 20,"Zara");//passing the value for the argument
		
	}

}
class Action{
	private void sceret() {
		System.out.println("-> this is a private secret method");
	}
	private void cube(int n1) {
		System.out.println("***Cube of number "+n1+" is :"+(n1*n1*n1));
	}
	
	private int max( int n1, int n2) {
		return n1>n2? n1:n2;
	}
	
	private void printInfo(int age, String name) {
		System.out.println("***Hello ,"+name +"....Age is  "+age);
	}
}
