/**
 * 
 */
package com.lnt.day14.reflection;

/**
 * @author brije
 *
 */
public class TestNewInstance {
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		
		Class c1 = Class.forName("ClassFirst");
		
		//ClassFirst obj = new ClassFirst();
		// one more way to create instance of a class
		ClassFirst obj = (ClassFirst) c1.newInstance();//return Object , thats y need to type casted
		obj.sayHello("Smita");
	}

}
class ClassFirst{
	public void sayHello(String name) {
		System.out.println("Hello ,"+name);
	}
}
