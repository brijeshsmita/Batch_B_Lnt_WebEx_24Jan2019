/**
 * 
 */
package com.lnt.day14.reflection;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * @author brije
 *
 */
public class AccessPrivateMethod {

	public static void main(String[] args) throws ClassNotFoundException, 
	InstantiationException, IllegalAccessException, 
	NoSuchMethodException, SecurityException,
	IllegalArgumentException, InvocationTargetException {
		Sample s1 = new Sample();
		s1.print();
		//lets access the private method
		//s1.secret();//compiler error
		//private is accessible only within the class not outside the class
		
		//lets resolve it using java.lang.reflect.Method class
		/*
		 * 1> setAccessibilitiy()
		 * 2> invoke()
		 */
		//load the class dynamically
		Class c1 = Class.forName("com.lnt.day14.reflection.Sample");
		Sample s2 = (Sample) c1.newInstance();//thorws 	InstantiationException, IllegalAccessException
		
		Method m1 = c1.getDeclaredMethod("sceret",null);//NoSuchMethodException, SecurityException
		m1.setAccessible(true);//setting the accessiblity of the private method to true
		m1.invoke(s2, null);//throws IllegalArgumentException, InvocationTargetException

	}

}
class Sample{
	
	public void print() {
		System.out.println("Sample class");
	}
	private void sceret() {
		System.out.println("***this is a sceret private method");
	}
}
