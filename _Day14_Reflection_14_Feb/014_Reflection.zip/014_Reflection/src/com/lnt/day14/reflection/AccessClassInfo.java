/**
 * 
 */
package com.lnt.day14.reflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * @author Smita B Kumar
 *
 */
public class AccessClassInfo {

	public static void main(String[] args) {
		try {
			AccessClassInfo.testClassInfo(new Customer());
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException
				| SecurityException e) {
			e.printStackTrace();
		}
	}

	public static void testClassInfo(Object obj) throws NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Class c1 = obj.getClass();
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
				+ "			Information about " + c1.getSimpleName() + " Class"
				+ "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		System.out.println("\nAccess Private Method\n");
		Method m1 = c1.getDeclaredMethod("sceretInfo", null);
		System.out.println("m1 -> " + m1);
		Customer cust = (Customer) obj;// type casting Object to Customer
		//error//m1.invoke(cust, null);//if u try to invoke private method --- it throws IllegalAccessException
		// we cant invoke private method
		// so we have to make the accessibility to public then only we can access the
		// private method
		 m1.setAccessible(true);
			System.out.println("\n Invoking Private Method by changing the accessibility to true :setAccessible(true) \n");
		 m1.invoke(cust, null);

		System.out.println("\nField List of all the public field from current-super class : getFields() \n");
		Field[] fields = c1.getFields();
		for (Field f : fields) {
			System.out.println(" -> " + f);
		}

		System.out.println("\nField List of all the field from current class : getDeclaredFields() \n");
		fields = c1.getDeclaredFields();
		for (Field f : fields) {
			System.out.println(" -> " + f);
		}

		System.out.println("\nPublic Constructors List getConstructors() : \n");
		Constructor[] constructors = c1.getConstructors();
		for (Constructor c : constructors) {
			System.out.println(" -> " + c);
		}

		System.out.println("\nAll Constructors List getDeclaredConstructors(): \n");
		constructors = c1.getDeclaredConstructors();
		for (Constructor c : constructors) {
			System.out.println(" -> " + c);
		}

		System.out.println("\nPublic Methods List  of Current and super class: getMethods()\n");
		Method[] methods = c1.getMethods();
		for (Method m : methods) {
			System.out.println(" -> " + m);
		}
		System.out.println("\nAll Methods List of Current class: getDeclaredMethods()\n");
		methods = c1.getDeclaredMethods();
		for (Method m : methods) {
			System.out.println(" -> " + m);
		}

	}

}
