/**
 * 
 */
package com.lnt.day14.reflection;

import com.lnt.inheritance.model.emp.Employee;
import com.lnt.inheritance.model.emp.mgr.Manager;

/**
 * @author Smita B Kumar
 *
 */
public class ReflectObject {

	public static void main(String[] args) {
		// lets invoke the testObject method
		ReflectObject.testObject(new Employee());
		ReflectObject.testObject(new Customer());
		ReflectObject.testObject(new Manager());
	}
	
	public static void testObject(Object obj) {
		Class c1 = obj.getClass();//Object class getClass method which return the Class object
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
				+ "Information about \""+c1.getSimpleName()+"\" Class "
				+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		System.out.println("Super class : "+c1.getSuperclass());
		System.out.println("FUlly Qualified name of the class : "+c1.getName());
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	}

}
