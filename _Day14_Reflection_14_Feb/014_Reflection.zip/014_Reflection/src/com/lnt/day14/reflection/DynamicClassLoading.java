/**
 * 
 */
package com.lnt.day14.reflection;

/**
 * @author Smita B Kumar
 * Reflection in java means fetching the information about the class at runtime/
 *dynamically loading the class 
 *describe the class dynamically
 *modify the class method at runtime
 *Java documentation is created using reflection API
 *
 */
public class DynamicClassLoading {

	public static void main(String[] args) throws ClassNotFoundException {
		// load the class at runtime to fetch ,describe or modify the structure of a class at runtime
		String className="com.lnt.day14.reflection.Customer";//fully qualified name of the class
		//packageName.subPackageName.className
		Class<?> c1=Class.forName(className);//Class class provide forName method to load the class dynamically
		//forName static method throws ClassNotFoundException---checked exception
		System.out.println("loding the class Dynamically...");
		//lets fetch the info about the class at runtime (methods,fields,constructor)
		System.out.println("Class Loaded fully Qualified : "+c1.getName());
		System.out.println("Is Interface ? "+c1.isInterface());
		System.out.println("Simple Name : "+c1.getSimpleName());
	}
}
