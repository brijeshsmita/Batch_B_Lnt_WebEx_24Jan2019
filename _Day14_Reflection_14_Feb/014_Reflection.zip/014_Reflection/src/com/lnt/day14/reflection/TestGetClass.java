/**
 * 
 */
package com.lnt.day14.reflection;

import com.lnt.inheritance.model.emp.Employee;

/**
 * @author brije
 *
 */
public class TestGetClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Employee e1 = new Employee();
		TestGetClass.getObjectInfo(e1);//employee obj
		TestGetClass.getObjectInfo("Smita");//string obje
		TestGetClass.getObjectInfo(true);//Boolean obje
		TestGetClass.getObjectInfo(new MyClass());//MyClass Obj
		
		//third way is .class syntax
		Class c1 = MyInterface.class;//3rd way
		System.out.println("*****************************************************");
		System.out.println("The third way is by .class : "+c1.getName());
		System.out.println("Is it an interface : "+c1.isInterface());

	}
	public static void getObjectInfo(Object obj) {
		// second way to get the name of the class
		Class c1= obj.getClass();//2nd way
		System.out.println("The class name is : "+c1.getName());
		System.out.println("Is it an interface : "+c1.isInterface());		
		
	}
}
interface MyInterface{
	
}
class MyClass implements MyInterface{
	
}