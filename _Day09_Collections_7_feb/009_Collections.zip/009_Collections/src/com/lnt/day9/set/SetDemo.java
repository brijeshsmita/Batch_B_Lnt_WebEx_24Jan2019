/**
 * 
 */
package com.lnt.day9.set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

/**
 * @author Smita
 *
 */
public class SetDemo {
	public static void main(String[] args) {
		//Set has a contract with equals and hashCode- as it does not allows duplicate
		//so it checks the equality of the object by implicitly invoking equals and hashCode method
		Set<String> nameSet = new HashSet<>();//java 7 onwards right side diamond does not need types declaration
		nameSet.add("Diya");nameSet.add("Ciaz");nameSet.add("Anne");nameSet.add("Ben");
		nameSet.add("Era");//adding object to the specific index
		nameSet.add("Diya");//overlap the duplicate value
		System.out.println("Arrays List of String Names :");
		//nameSet.remove("Diya");
		/*for(String i:nameSet ) {
			System.out.println(i);
		}*/
		//HashSet
		Set<Employee> hashSet = new HashSet<>();//no order
		Set<Employee> linkedHashSet = new LinkedHashSet<>();//insertion order
		Set<Employee> treeSet = new TreeSet<>();//Ordered(by the properties)
		Employee e1 = new Employee(444,"Diya", 3333.33);
		Employee e2 = new Employee(111,"Ciaz", 2222.22);
		Employee e3 = new Employee(333,"Era", 4444.44);
		Employee e4 = new Employee(222,"Aish", 5555.55);
		Employee e5 = new Employee(555,"Ben", 1111.111);
		Employee e6 = new Employee(444,"Diya", 3333.33);
		System.out.println("HashSet Of Employee....Set Does not allows duplicate");
		hashSet.add(e1);hashSet.add(e6);//trying to add e1 twice
		hashSet.add(e2);hashSet.add(e3);hashSet.add(e4);hashSet.add(e5);
		Iterator<Employee> iter = hashSet.iterator();
		/*while (iter.hasNext()) {
			System.out.println(iter.next());			
		}*/
		//although the value of e1 and e6 is same , then also set is allowing to add duplicate value
		//because it is comaring Object by reference(hashCode) not by its value
		//therefore whenever we are dealing with set collection ,we must override equals and hashCode in the specific Object class
		System.out.println("LinkedHashSet Of Employee....Insertion Order");
		linkedHashSet.add(e1);linkedHashSet.add(e6);linkedHashSet.add(e2);linkedHashSet.add(e3);linkedHashSet.add(e4);linkedHashSet.add(e5);
		iter = linkedHashSet.iterator();
		while (iter.hasNext()) {
			System.out.println(iter.next());			
		}
	}
}
