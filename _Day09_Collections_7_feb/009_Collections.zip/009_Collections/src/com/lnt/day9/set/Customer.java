package com.lnt.day9.set;

import java.util.Comparator;

/**
 * @author Smita
 *
 */
//golden rule for an interface
//a class implementing an interface must override all the abstract method
public class Customer implements Comparable<Customer>{
	//instance variables
	private Integer custId;
	private String custName;
	private Double billAmt;
	@Override
	public int compareTo(Customer o) {
		//it returns int value
		//if both object are equals then 0
		//if first object is greater then 1
		//if first object is smaller then -1
		// we will do sorting in natural order i.e with custId
		return this.getCustId()-o.getCustId();//sort by id
		//return this.getCustName().compareTo(o.getCustName());//sort by name
	}
	public Customer() {
		this.custName="unknown";
		this.billAmt=00.00;
	}
	//overloaded constructor 
	public Customer(String custName,Double billAmt) {
		//when the instance variable name and the local variable name is same
		//then to use the instance variable ... we refer instance variable with the help this keyword
		this.custName=custName;//explicit this is used to refer to the instance variable
		this.billAmt=billAmt;
	}
	/*
	 * Overloading is a process of re-writing the method with same name
	 * and different argument list return type may or many not be same
	 */
	public Customer(Integer custId,String custName,Double billAmt) {
		this.custId=custId;
		//when the instance variable name and the local variable name is same
		//then to use the instance variable ... we refer instance variable with the help this keyword
		this.custName=custName;//explicit this is used to refer to the instance variable
		this.billAmt=billAmt;
	}
	//override ToString() method 
	//to print the STring representation of an object
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", billAmt=" + billAmt + "]";
	}
	
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return custId;//if custId is same then the object will be same
		//therefore we are returning custId as a unique hashCode
	}
	@Override
	public boolean equals(Object obj) {
		return this.hashCode()==obj.hashCode();//both the object hashCode(custId) is same then both the objects are equals
	}
	//business method
	public void print() {
		// this is a keyword in java- which refers to current Object
		// no need of explicitly writing this ... it s already available
		System.out.println(
				"\n============================================================================================================================================\n"
						+ "\n                             Customer Details"
						+ "\n============================================================================================================================================\n"
						+ "\n            			Customer Id     : " + this.custId
						+ "\n            			Customer Name   : " + this.custName
						+ "\n            			Bill Amount     : " + this.billAmt

						+ "\n============================================================================================================================================\n");
	}
	//generate getters and setters
	//to provide access to private variables outside the class
	public Integer getCustId() {
		return custId;
	}
	public void setCustId(Integer custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public Double getBillAmt() {
		return billAmt;
	}
	public void setBillAmt(Double billAmt) {
		this.billAmt = billAmt;
	}
	
	
}














