package com.lnt.day9.set;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class DemoTreeSet {
	public static void main(String[] args) {
		//when we want to maintain unique collection- go for SET
		//hashSet
		Set<String> nameSet = new TreeSet<>();	
//TreeSet has a contract with Comparable or Comparator interface
		//the object should be of either Comparable or Comparator type because TreeSet are sorted set
		nameSet.add("Cena");//as we are adding string therefore it will sort bcoz String implements Comparable
		nameSet.add("Diya");
		nameSet.add("Diya");//overlapping will be done, no error
		nameSet.add("Aish");
		nameSet.add("Bill");
		System.out.println("\n*************Treeset are unique and sorted collection *****************\n");
		Iterator iter = nameSet.iterator();
		while(iter.hasNext()) {
			System.out.println(iter.next());		//printing the next value in the set	
		}	

		Customer c1 = new Customer(101, "Zara", 3333.33);
		Customer c2 = new Customer(103, "Yara", 1111.11);
		Customer c3 = new Customer(102, "Xenith", 2222.22);
		Customer c4 = new Customer(101, "Zara", 3333.33);
		//when we are trying to Customer to TreeSet , treeSet has a contract with Comparable/Comparator
		//treeSet will check that the object has implement it or not if not
		//then throws ClassCastException bcoz TreeSet accepts object of type Comparable/Comparator
		//thus implements Comparable/Comparator in Customer class
		Set<Customer> empSet = new TreeSet<>();	
		empSet.add(c4);
		empSet.add(c1);
		empSet.add(c2);
		empSet.add(c3);
		
		//set is internally comparing the hashcode of e1 and e4 , not the value
		//solution is whenever operating with set , always override hashcode and equals method
		iter = empSet.iterator();
		System.out.println("\n*************Iterating through empSet*****************\n");
		while(iter.hasNext()) {
			System.out.println(iter.next());		//printing the next value in the set	
		}	
		/*
		 * whenever we try to add object in set, it check the hashCode of the object to compare the object
		 * rather than the value
		 * every object in java get a unique hashcode when it is create  
		 */
	}
}











