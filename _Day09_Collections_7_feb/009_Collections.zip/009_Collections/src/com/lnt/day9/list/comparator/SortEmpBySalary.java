/**
 * 
 */
package com.lnt.day9.list.comparator;

import java.util.Comparator;

import com.lnt.day9.emp.Employee;

/**
 * @author Smita
 *
 */
public class SortEmpBySalary implements Comparator<Employee> {
	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		return (int) (o1.getEmpSal()-o2.getEmpSal());
	}
}
