/**
 * 
 */
package com.lnt.day9.list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.lnt.day9.emp.Employee;

/**
 * @author brije
 *
 */
public class ListDemo1 {
	public static void main(String[] args) {
		//we have not specified the type of ArrayList- so it can allow us to store any type of Object
		//if i want to store list of only STring oBject
		// we can achieve this using generic-> generic enforces type safety in java
		List<String> nameList = new ArrayList<>();//java 7 onwards right side diamond does not need types declaration
		nameList.add("Diya");nameList.add("Ciaz");nameList.add("Anne");nameList.add("Ben");
		nameList.add(0, "Era");//adding object to the specific index
		System.out.println("Arrays List of String Names :");
		//nameList.remove("Diya");
		for(String i:nameList ) {
			System.out.println(i);
		}
		System.out.println("\nSorted Names List :");
		Collections.sort(nameList);//Collections is a class which provides sort method
		for(String i:nameList ) {
			System.out.println(i);
		}
		List<Employee> empList = new ArrayList<>();//enforced type safety using generics
		
		Employee e1 = new Employee(444,"Diya", 3333.33);
		Employee e2 = new Employee(111,"Ciaz", 2222.22);
		Employee e3 = new Employee(333,"Era", 4444.44);
		Employee e4 = new Employee(222,"Aish", 5555.55);
		Employee e5 = new Employee(555,"Ben", 1111.111);
		empList.add(e1);empList.add(e2);empList.add(e3);empList.add(e4);empList.add(e5);
		System.out.println("\nPrinting List of Employee");
		Iterator<Employee> iter = empList.iterator();
		while (iter.hasNext()) {
			System.out.println(iter.next());			
		}
		Collections.sort(empList);
		//sort method has a contract with Comparable/Comparator Interface
		//means sort method can sort only those object which has implemented either of the Comparable/Comparator Interface
		// so in Employee class implement Comparable<Employee> interface
		//and override compareTo() method
		System.out.println("\nPrinting List of Sorted Employee By Employee Id");
		//iterator are forward only
		iter = empList.iterator();
		while (iter.hasNext()) {
			System.out.println(iter.next());			
		}
	}

}
