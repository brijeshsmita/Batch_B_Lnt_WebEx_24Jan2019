/**
 * 
 */
package com.lnt.day9.list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.lnt.day9.emp.Employee;
import com.lnt.day9.list.comparator.SortEmpByName;
import com.lnt.day9.list.comparator.SortEmpBySalary;

/**
 * @author Smita
 *
 */
public class EmpListComparator {

	public static void main(String[] args) {
List<Employee> empList = new ArrayList<>();//enforced type safety using generics
		
		Employee e1 = new Employee(444,"Diya", 3333.33);
		Employee e2 = new Employee(111,"Ciaz", 2222.22);
		Employee e3 = new Employee(333,"Era", 4444.44);
		Employee e4 = new Employee(222,"Aish", 5555.55);
		Employee e5 = new Employee(555,"Ben", 1111.111);
		empList.add(e1);empList.add(e2);empList.add(e3);empList.add(e4);empList.add(e5);
		System.out.println("\nPrinting List of Employee in Insertion Order");
		Iterator<Employee> iter = empList.iterator();
		while (iter.hasNext()) {
			System.out.println(iter.next());			
		}
		Collections.sort(empList);
		//sort method has a contract with Comparable/Comparator Interface
		//means sort method can sort only those object which has implemented either of the Comparable/Comparator Interface
		// so in Employee class implement Comparable<Employee> interface
		//and override compareTo() method
		System.out.println("\nPrinting List of Sorted Employee By Employee Id");
		//iterator are forward only
		iter = empList.iterator();
		while (iter.hasNext()) {
			System.out.println(iter.next());			
		}
		
		System.out.println("\nPrinting List of Sorted Employee By Name");
		Collections.sort(empList, new SortEmpByName());
		//SortEmpByName must implement Comparator<Employee> interface and override compare() method
		//iterator are forward only
		iter = empList.iterator();
		while (iter.hasNext()) {
			System.out.println(iter.next());			
		}
		System.out.println("\nPrinting List of Sorted Employee By Salary");
		Collections.sort(empList, new SortEmpBySalary());
		//SortEmpByName must implement Comparator<Employee> interface and override compare() method
		//iterator are forward only
		iter = empList.iterator();
		while (iter.hasNext()) {
			System.out.println(iter.next());			
		}

	}

}
