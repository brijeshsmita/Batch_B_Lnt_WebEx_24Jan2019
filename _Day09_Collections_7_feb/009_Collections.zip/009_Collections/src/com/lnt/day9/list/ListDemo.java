/**
 * 
 */
package com.lnt.day9.list;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.lnt.day9.emp.Employee;

/**
 * @author Smita
 *
 */
public class ListDemo {
	public static void main(String[] args) {
	/*	//list is storing different Object , heterogeneous Objects
		//list are in insertion ordered , allows duplicate
		List list = new ArrayList<>();
		list.add(10);
		//auto-boxing-implicitly converting value type to object type (int-Integer)
		list.add(new Integer(20));
		list.add(new Integer(30));
		list.add(new Integer(40));
		list.add(new Integer(40));
		
		System.out.println(list);
		
		list.add(new String("Smita"));
		list.add(new String("Smita"));
		list.add(new Double(999.99));
		list.add(new Employee(111,"Zara",888.88));
		System.out.println("altered list "+list);
		//Iterator interface is use to iterate over the collection ... visit each element of the collection
		Iterator iter= list.iterator();
		while(iter.hasNext())//hasNext method checks weather list has the next object or not
		{//if list has the next object the next method will take the cursor to the next object in the list
			System.out.println(iter.next());
		}*/
	}
}
