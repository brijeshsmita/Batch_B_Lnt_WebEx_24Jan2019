/**
 * 
 */
package com.lnt.day9.list.comparator;

import java.util.Comparator;

import com.lnt.day9.emp.Employee;

/**
 * @author brije
 *
 */
public class SortEmpByName implements Comparator<Employee> {
	//this compare method is invoked by sort method implicitly
	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		return o1.getEmpName().compareTo(o2.getEmpName());
		//0 if both objects are equals
		//1 if first object is greater
		//-1 if first object is smaller
	}


}
