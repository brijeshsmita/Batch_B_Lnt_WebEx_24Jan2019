/**
 * 
 */
package com.lnt.day9.arrays;

import com.lnt.day9.emp.Employee;

/**
 * @author brije
 *
 */
public class ArraysDemo {
	public static void main(String[] args) {
		int marks=99;//variable
		//how to store the marks of 5 subjects
		int [] marksArr1= new int[5];//declared the array which will 5 int value
		//index of array start with 0
		//assigning the values to the array index
		marksArr1[0]=70;marksArr1[1]=80;marksArr1[2]=87;
		marksArr1[3]=67;marksArr1[4]=89;
		
		//declaring and assigning
		int [] marksArr2= {10,20,30,40,50};
		
		//just like string arrays are also first class object in java
		//that is string and arrays are always created on heap
		System.out.println("\nPrinting array of int");
		//enhanced for loop - var type will be always the data-type of the array/collections
		for(int i : marksArr2) {//always starts with 0th index and increment by 1 till the end of the array/collection
			System.out.println(i);
		}
		
		System.out.println("\nPrinting array of String");
		String strArr []= {"aaa","bbb","ccc"};
		//enhanced for loop - var type will be always the data-type of the array/collections
		for(String i: strArr) {
			System.out.println(i);
		}
		System.out.println("\nPrinting array of Employee");
		Employee e1 = new Employee(444,"Diya", 3333.33);
		Employee e2 = new Employee(111,"Ciaz", 2222.22);
		Employee e3 = new Employee(333,"Era", 4444.44);
		Employee e4 = new Employee(222,"Aish", 5555.55);
		Employee e5 = new Employee(555,"Ben", 1111.111);
		
		//we can create array of any object
		Employee [] empArr= {e1,e2,e3,e4,e5};
		for(Employee i: empArr) {
			System.out.println(i);
		}
	}//array cannot be re-sized, it can store homogeneous data(same type)
}
