/**
 * 
 */
package com.lnt.day9.emp;

/**
 * @author Smita
 *
 */
public class Employee implements Comparable<Employee>{
	//private variable are accessible only within the class
	//we have protected access specifier to provide access to the sub-class
	protected int empId;
	protected String empName;
	protected double empSal;
	protected static final String CO_NAME="Lnt Infotech.";
	protected static final String COURNTRY_NAME;//blank final
	//final variable must be initialized
	/*static int numId;*/
	static {
		//final variable which is declared but initialized inside a constructor or a block is known as blank final
		COURNTRY_NAME="India";
	//	System.out.println("static init Employee class");
		//static init block to initialize only static variable
	//	numId= (int) (1000+ Math.random()*1234.1234);
	}/*
//init block to initialize those variable which need to be created before invocation of a constructor
	{
		System.out.println("init block Employee class");
		empId=numId++;
	}*/
	//constructors to initialize the newly created object
	public Employee() {
		System.out.println("No-Arg constructor of Employee class");
		empName="unknown";
	}
	public Employee(int empId, String empName, double empSal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
	}
	public Employee(String empName, double empSal) {
		System.out.println("Overloaded constructor of Employee class");
		this.empName = empName;
		this.empSal = empSal;
	}
	//business method
	public void print() {
		//all object/reference variable data-type default value is null
		System.out.println(
		"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
		+"\n                    Employee Details                             \n"
		+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
		+"\n          Employee Id    : "+this.empId
		+"\n          Employee Name  : "+empName
		+"\n          Salary         : "+empSal
		+"\n          Company Name   : "+CO_NAME +" "+COURNTRY_NAME
		+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	}
	//inorder to provide access to private variable outside the class- generate getters and setters
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}
	//comments- description/information about of the specific code which is ignored by the java compiler
	//comments are ment only for programmers
	//annotations -description/information about of the specific code for both the java compiler
	//as well as for the programmers, annotation is prefixed with '@' PascalCase
	@Override //-decription about the method that it belongs to super class and re-written in the subclass with different implementation
	public String toString() {
		return "Empid : "+empId+"\t EmpName : "+empName+" \tEmpSal : "+empSal;
	}
	public Employee getEmployee(int empId) {
		Employee e1= new Employee();
		e1.setEmpId(empId);
		return e1;
	}
	public final void testEmp() {
		System.out.println("this is  final method i employee class"
				+ "...which cannot be overridden");
	}
	public static String getCoName() {
		return CO_NAME;
	}
	public static String getCourntryName() {
		return COURNTRY_NAME;
	}
	//this comparaTo method is invoked by sort method implicitly
	@Override
	public int compareTo(Employee o) {
		return this.empId-o.empId;//we are sorting the employee with empId
		//0 if both objects are equals
		//1 if first object is greater
		//-1 if first object is smaller
	}
	
	
}
