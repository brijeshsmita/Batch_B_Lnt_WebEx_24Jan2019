/**
 * 
 */
package com.lnt.io.file_byte;

import java.io.File;
import java.io.IOException;

/**
 * @author brije
 *
 */
public class FileDemo {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		String pathname="src/demo1.txt";
		File file = new File(pathname);
		//file class is used to get the info about the file
		//we can also create new file with the File class method
		if(!file.exists()) {
			System.out.println("File does not exists... creating a new file...");
			file.createNewFile();
		}else {
			System.out.println("file.getAbsolutePath() : "+
					file.getAbsolutePath());
			System.out.println("file.isFile() : "+
					file.isFile());
			System.out.println("file.isDirectory() : "+
					file.isDirectory());
			System.out.println("file.canWrite() : "+
					file.canWrite());
		}

	}

}
