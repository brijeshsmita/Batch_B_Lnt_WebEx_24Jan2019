/**
 * 
 */
package com.lnt.io.file_byte;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * @author brije
 *
 */
public class FileOutputByte {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args)  {
		String pathname="src/demo1.txt";
		File file = new File(pathname);
		//to perform write operation - byte by byte
		OutputStream outputStream=null;		
		//lets to perform input and output operation on the file
		try{
			outputStream = new FileOutputStream(file);
			//let write byte by byte on the destination i.e. file
			outputStream.write(1);
			outputStream.write('\n');
			outputStream.write('A');
			outputStream.write('\n');
			byte[] bArr = {'H','I'}; 
			outputStream.write(bArr);
			outputStream.flush();
			System.out.println("Written bytes into file : "+file.getAbsolutePath());
		}catch (IOException e) {
			System.err.println(e.getMessage());
		}finally {
			//release the resources
			try {
				outputStream.close();
			} catch (IOException e) {
				System.err.println(e.getMessage() +" Sorry Resource already closed");
			}
		}
	}

}
