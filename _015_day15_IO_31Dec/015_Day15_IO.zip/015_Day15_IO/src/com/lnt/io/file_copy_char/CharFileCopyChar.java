/**
 * 
 */
package com.lnt.io.file_copy_char;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
/** * @author Smita * */
public class CharFileCopyChar {
	/**
	 * @param args
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args)  {
		File fileSource = new File("src/Contact.java");
		File fileDest = new File("src/ContactCopy.txt");
		//read char by char using buffer
		System.out.println("\nReading char from the file using buffer : "+fileSource.getAbsolutePath()
		+" \n and Writing char to the file using buffer : "+fileDest.getAbsolutePath());
		try(/*read byte by byte using buffer*/
				BufferedReader br = new BufferedReader(new FileReader(fileSource));
				BufferedWriter bw = new BufferedWriter(new FileWriter(fileDest));
				){
			String str=null;
			while((str=br.readLine())!=null) {//read from buffer char till readLine is not Null (i.e EOF)
				//write to buffer char 
				bw.write(str+"\n");
				bw.flush();//clear the cache
			}			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
