/**
 * 
 */
package com.lnt.io.file_copy_byte;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * @author brije
 *
 */
public class ImageFileCopyByte {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args)  {
		File fileSource = new File("src/art.JPG");
		File fileDest = new File("src/artCopy.JPG");
		//read byte by byte using buffer
		System.out.println("\nReading byte from the file using buffer : "+fileSource.getAbsolutePath()
		+" \n and Writing byte to the file using buffer : "+fileDest.getAbsolutePath());
		try(/*read byte by byte using buffer*/
				BufferedInputStream bis = new BufferedInputStream(new FileInputStream(fileSource));
				BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(fileDest));
				){
			int b=0;
			while((b=bis.read())!=-1) {//read from buffer byte byte till EOF (-1)
				//write to buffer byte by byte 
				bos.write(b);
				bos.flush();//clear the cache
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
