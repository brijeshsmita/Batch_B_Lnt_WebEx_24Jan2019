/**
 * 
 */
package com.lnt.day12.thread;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MaximizeAction;

/**
 * @author Smita B Kumar
 * Thread execution is taken care by Operating System , as our JVM is running on top of OS
 * currentThread()- is a static method of Thread class to fetch the Thread info (ThreadName,threadPriority,methodName)
 * getName()- return the name of the thread - the default name of Thread start with 'thread-0'...thread-1...thread-2 and so on...
 * setName()- set the name of the thread
 * start()- it will inform the OS that this thread is ready to run- give a callback to run method by the OS
 * run()- now Operating system will execute the thread and now the thread will be in running state
 * we will always have difference in output , as OS takes care of execution of thread
 * setPriority(),- to set the Priority of the Thread
 * getPriority()- to get the Priority of the Thread
 *  Default priority is 5 NORM_PRIORITY (final var in Thread class)
 * Thread priority can be set from 1-10
 * min priority is 1 MIN_PRIORITY
 * max priority is 10 MAX_PRIORITY
 * setPriority(),getPriority()
 * Thread.sleep(1000l);//time in long milliseconds
	//Thread .sleep is a static method of Thread class - throws InterruptedException
	//purpose is to make the thread to wait for the specific number of millisecond
	//thread will got waiting state
 */
public class ThreadPriorityDemo {
	/*
	 * Thread class Constructors
	 * Thread()
	 * Thread(String name)
	 */
	public static void main(String[] args) {
		Thread t1 = new PriorityTask("Ram");//1
		Thread t2 = new PriorityTask("Laxman");//5
		Thread t3 = new PriorityTask("Sita");//10
		t1.setPriority(1);t3.setPriority(Thread.MAX_PRIORITY);t2.setPriority(Thread.NORM_PRIORITY);
		t1.start();// thread is ready to run
		t2.start();
		t3.start();
	/*
	 * Default priority is 5 NORM_PRIORITY (final var in Thread class)
	 * Thread priority can be set from 1-10
	 * min priority is 1 MIN_PRIORITY
	 * max priority is 10 MAX_PRIORITY
	 * setPriority(),getPriority()
	 * 
	 */

	}

}
//java.lang.Thread
class PriorityTask extends Thread{
	//constructor with String parameter
	public PriorityTask(String name){
		super(name);//invoking Thread class constructor with STring
	}
	//which task has to be done - the logic will be written in run method
	@Override
	public void run() {
		String tName=Thread.currentThread().getName();
		System.out.println("\n~~~~~~~~~~~~~~~~~"+tName+" Thread is running~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("Thread Info : "+Thread.currentThread());//(,ThreadName,threadPriority,methodName)
		System.out.println("Thread Name : "+tName+"\tThread Priority : "+this.getPriority());
		System.out.println("~~~~~~~~~~~~~~~~~~~"+tName+" Thread is Destroyed~~~~~~~~~~~~~~~~~~~~~~\n");
	}	
	
}
