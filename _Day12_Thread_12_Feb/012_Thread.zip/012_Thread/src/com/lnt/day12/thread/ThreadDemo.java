/**
 * 
 */
package com.lnt.day12.thread;

/**
 * @author Smita B Kumar
 * Thread execution is taken care by Operating System , as our JVM is running on top of OS
 * currentThread()- is a static method of Thread class to fetch the Thread info (ThreadName,threadPriority,methodName)
 * getName()- return the name of the thread - the default name of Thread start with 'thread-0'...thread-1...thread-2 and so on...
 * start()- it will inform the OS that this thread is ready to run- give a callback to run method by the OS
 * run()- now Operating system will execute the thread and now the thread will be in running state
 * we will always have difference in output , as OS takes care of execution of thread
 */
public class ThreadDemo {
	/*
	 * Thread class Constructors
	 * Thread()
	 * Thread(String name)
	 */
	public static void main(String[] args) {
		Thread t1 = new PriorityTask("Ram");//created the thread
		//we can set the name of the Thread
	//	t1.setName("Ram");
		Thread t2 = new PriorityTask("Laxman");
	//	t2.setName("Laxman");
		Thread t3 = new PriorityTask("Sita");
	//	t3.setName("Sita");
		t1.start();// thread is ready to run
		t2.start();
		t3.start();
		//difference between the thread.run and thread.start?
		//call back is made to run method by the OS , so thread will be started and run
		//t3.run();// we are running the method with simple java object
		//not treated as a thread

	}

}
//java.lang.Thread
class Task extends Thread{
	//constructor with String parameter
	public Task(String name){
		super(name);//invoking Thread class constructor with STring
	}
	//which task has to be done - the logic will be written in run method
	@Override
	public void run() {
		String tName=Thread.currentThread().getName();
		System.out.println("\n~~~~~~~~~~~~~~~~~"+tName+" Thread is running~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("Thread Info : "+Thread.currentThread());//(,ThreadName,threadPriority,methodName)
		System.out.println("Thread Name : "+tName);
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	}	
	
}
