/**
 * 
 */
package com.lnt.day12.thread;

/**
 * @author Smita B Kumar Thread execution is taken care by Operating System , as
 *         our JVM is running on top of OS currentThread()- is a static method
 *         of Thread class to fetch the Thread info
 *         (ThreadName,threadPriority,methodName) getName()- return the name of
 *         the thread - the default name of Thread start with
 *         'thread-0'...thread-1...thread-2 and so on... setName()- set the name
 *         of the thread start()- it will inform the OS that this thread is
 *         ready to run- give a callback to run method by the OS run()- now
 *         Operating system will execute the thread and now the thread will be
 *         in running state we will always have difference in output , as OS
 *         takes care of execution of thread setPriority(),- to set the Priority
 *         of the Thread getPriority()- to get the Priority of the Thread
 *         Default priority is 5 NORM_PRIORITY (final var in Thread class)
 *         Thread priority can be set from 1-10 min priority is 1 MIN_PRIORITY
 *         max priority is 10 MAX_PRIORITY setPriority(),getPriority()
 *         Thread.sleep(1000l);//time in long milliseconds //Thread .sleep is a
 *         static method of Thread class - throws InterruptedException //purpose
 *         is to make the thread to wait for the specific number of millisecond
 *         //thread will got waiting state //join() - which allows the waiting
 *         thread to join the execution only when the current thread will
 *         complete its task //join method throws InterruptedException
 *         Thread.yield();//give the execution to the current waiting thread
 *         Daemon Thread - lowest priority thread which runs at the backgroud
 *         setDaemon()- to make the thread as daemon thread isDaemon()- return
 *         weather the thread is daemon thread or not
 */
public class YieldDemo {
	public static void main(String[] args) {
		/*
		 * first episode 1 will complete then episode 2 will complete then episode 3
		 */
		Runnable target = new LiveStreamingWithAdd();
		Thread t1 = new Thread(target, "Episode1");
		Thread t4 = new Thread(target, "Add Break");

		t1.start();
		Thread.yield();
		// give the execution to the current waiting thread
		t4.start();		
	}
}

class LiveStreamingWithAdd implements Runnable {

	@Override
	public void run() {
		String tName = Thread.currentThread().getName();
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~" + tName + " Started~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		for (int i = 1; i <= 30; i++) {			
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if(tName.equals("Add Break")) {//running add break at every 10 minutes between the addbreaks
				if(i%10==0)
					System.out.println("*****Running "+tName );
			}else {
				System.out.println(tName + " : " + i);
			}
		}
		System.out.println("~~~~~~~~~~~~~~~~~~~~~" + tName + " Ended~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	}
}
