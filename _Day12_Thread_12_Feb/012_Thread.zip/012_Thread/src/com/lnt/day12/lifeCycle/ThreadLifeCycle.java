/**
 * 
 */
package com.lnt.day12.lifeCycle;

/**
 * @author Smita B Kumar
 *
 */
public class ThreadLifeCycle {
	public static void main(String[] args) {
		Thread t1 = new Thread(new MyRunnableThread(),"T1");
		System.out.println("The thread is created/born but is Alive ?... "+t1.isAlive());
		t1.start();System.out.println("The thread is started and is alive...and now ready to run...");
		System.out.println("T1 is alive .... "+t1.isAlive());

	}
}
class MyRunnableThread implements Runnable{

	@Override
	public void run() {
		System.out.println("The Thread is in Running State... in run() method");
		try {
			Thread.sleep(1000);
			System.out.println("The Thread is in now Waiting State... in sleep()/wait()/interrupt() method");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("The Thread is in now again in Running State");
		System.out.println("The Thread is in now about to die...ending run() method");
	}
	
}
