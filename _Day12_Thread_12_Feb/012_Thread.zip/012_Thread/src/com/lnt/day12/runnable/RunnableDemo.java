/**
 * 
 */
package com.lnt.day12.runnable;

/**
 * @author Smita B Kumar
 *
 */
public class RunnableDemo {
	
	public static void main(String[] args) {
		//Step 3: create the Object of Runnable
		Runnable target = new MyRunnableSleepTask();		
		//Step 4: create the Object of Thread and associated it with runnable object
		Thread t1 = new Thread(target, "Ram");//3rd flavor of Thread Constructor takes Runnable ,String threadName as a parameter
		Thread t2 = new Thread(target, "Laxman");
		Thread t3 = new Thread(target, "Sita");
		//Step 5: invoke start on thread object
		t1.start();t2.start();t3.start();

	}

}
//2nd way to create multi-threaded program is implementing Runnable Interface
//Golden rule for abstract class and interface - override all the abstract method
//Step 1
class MyRunnableTask implements Runnable{

	@Override
	public void run() {//Step 2
		String tName = Thread.currentThread().getName();
		System.out.println("\n``````````````````````````````````\n"
		+tName+" started the task...");
		for (int i = 1; i <=5; i++) {
			System.out.println(tName+" completed: "+i+" task...");			
		}
		System.out.println(tName+" ended the task...\n``````````````````````````````````\n");		
	}	
}
//java 8 onward - @FunctionalInterface - are the interface which contains only one abstract method
//Tagging or Marker Interface - are the interface which does not contain any method