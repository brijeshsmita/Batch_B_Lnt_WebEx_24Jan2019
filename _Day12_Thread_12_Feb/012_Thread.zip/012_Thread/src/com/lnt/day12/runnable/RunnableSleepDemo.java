/**
 * 
 */
package com.lnt.day12.runnable;

/**
 * @author Smita B Kumar
 * Thread execution is taken care by Operating System , as our JVM is running on top of OS
 * currentThread()- is a static method of Thread class to fetch the Thread info (ThreadName,threadPriority,methodName)
 * getName()- return the name of the thread - the default name of Thread start with 'thread-0'...thread-1...thread-2 and so on...
 * setName()- set the name of the thread
 * start()- it will inform the OS that this thread is ready to run- give a callback to run method by the OS
 * run()- now Operating system will execute the thread and now the thread will be in running state
 * we will always have difference in output , as OS takes care of execution of thread
 * setPriority(),- to set the Priority of the Thread
 * getPriority()- to get the Priority of the Thread
 *  Default priority is 5 NORM_PRIORITY (final var in Thread class)
 * Thread priority can be set from 1-10
 * min priority is 1 MIN_PRIORITY
 * max priority is 10 MAX_PRIORITY
 * setPriority(),getPriority()
 * Thread.sleep(1000l);//time in long milliseconds
	//Thread .sleep is a static method of Thread class - throws InterruptedException
	//purpose is to make the thread to wait for the specific number of millisecond
	//thread will got waiting state
	 * //join() - which allows the waiting thread to join the execution only when the current thread will complete its task
		//join method throws InterruptedException
 */
public class RunnableSleepDemo {
	
	public static void main(String[] args) {
		//Step 3: create the Object of Runnable
		Runnable target = new MyRunnableSleepTask();		
		//Step 4: create the Object of Thread and associated it with runnable object
		Thread t1 = new Thread(target, "Ram");//3rd flavor of Thread Constructor takes Runnable ,String threadName as a parameter
		Thread t2 = new Thread(target, "Laxman");
		Thread t3 = new Thread(target, "Sita");
		//Step 5: invoke start on thread object
		t1.start();t2.start();t3.start();

	}

}
//2nd way to create multi-threaded program is implementing Runnable Interface
//Golden rule for abstract class and interface - override all the abstract method
//Step 1
class MyRunnableSleepTask implements Runnable{

	@Override
	public void run() {//Step 2
		String tName = Thread.currentThread().getName();
		System.out.println("\n``````````````````````````````````\n"
		+tName+" started the task...");
		for (int i = 1; i <=5; i++) {
			System.out.println(tName+" completed: "+i+" task...");
			try {
				Thread.sleep(1000l);//time in long milliseconds
				//Thread .sleep is a static method of Thread class - throws InterruptedException
				//purpose is to make the thread to wait for the specific number of millisecond
				//thread will got waiting state
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		System.out.println(tName+" ended the task...\n``````````````````````````````````\n");		
	}	
}
//java 8 onward - @FunctionalInterface - are the interface which contains only one abstract method
//Tagging or Marker Interface - are the interface which does not contain any method