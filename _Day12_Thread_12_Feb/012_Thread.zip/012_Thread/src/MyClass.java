/**
 * 
 */

/**
 * @author Smita B Kumar
 * Java is multiThreaded
 */
public class MyClass {

	public MyClass() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	protected void finalize() throws Throwable {
		System.out.println("Garbage collector running finalize method ..to de-allocate the memory which is referring to null or no more longer in use");
	}

	public static void main(String[] args) {
		System.out.println("Main Process is running....");
		MyClass c1 = new MyClass();
		c1=null;
		//we can request Garbage collector -backgroud low priority thread(sub-process) process-within a process
		//Garbage collection is a utility process which runs at the background 
		//to de-allocate the memory which is referring to null or no more longer in use
		System.gc();//to request Garbage collector
		//Runtime.getRuntime().gc();
	}

}
