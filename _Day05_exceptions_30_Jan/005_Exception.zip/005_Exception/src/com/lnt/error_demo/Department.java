package com.lnt.error_demo;

import java.util.ArrayList;
import java.util.List;

public class Department {
	int deptId;
	Employee emp ;
	@Override
	public String toString() {
		return "Department [deptId=" + deptId + ", emp=" + emp + "]";
	}
	public Department(int deptId, Employee emp) {
		super();
		this.deptId = deptId;
		this.emp = emp;
	}
	
	
}
