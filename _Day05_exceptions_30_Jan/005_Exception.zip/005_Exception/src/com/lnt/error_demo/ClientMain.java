package com.lnt.error_demo;

public class ClientMain {

	public static void main(String[] args) {
		/*Employee e1 = new Employee(101,new Department(10, new Employee(empId, dept)));
		Department d1 = new Department();
		System.out.println(e1);
		System.out.println(d1);*/

	}

}
