package com.lnt.error_demo;

public class Employee {
	int empId;
	Department dept ;
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", dept=" + dept + "]";
	}
	public Employee(int empId, Department dept) {
		super();
		this.empId = empId;
		this.dept = dept;
	}
	
}
