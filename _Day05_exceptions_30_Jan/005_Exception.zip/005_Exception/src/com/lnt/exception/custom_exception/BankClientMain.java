package com.lnt.exception.custom_exception;
/**
 * @author Smita
 *
 */
public class BankClientMain {
	public static void main(String[] args) {
		//let s create a BankAccount using no-arg constructor and setter method
		BankAccount b1 = new BankAccount();
		b1.setAccHolderName("Zara");b1.setAccBalance(1000);
		
		//let s create a BankAccount using parameterized constructor 
		BankAccount b2 = new BankAccount("Smita", 500);
		
		BankAccount b3 = new BankAccount("Raj", 1500);
		
		//lets withdraw from all the 3 accounts
		try {
			System.out.println("Trying to withdraw from : "+b1.getAccHolderName()+"'s , account");
			b1.withdraw(1000);
			System.out.println("Trying to withdraw from : "+b2.getAccHolderName()+"'s , account");
			b2.withdraw(1000);//exception occurs ... so rest of the try block code will not get executed
			System.out.println("Trying to withdraw from : "+b3.getAccHolderName()+"'s , account");
			b3.withdraw(1000);
		} catch (LowBalanceException e) {
			System.out.println(e.getMessage());
		}finally {
			System.out.println("Finally...If connection isOpen then .....closing the conection");
		}
	}

}
