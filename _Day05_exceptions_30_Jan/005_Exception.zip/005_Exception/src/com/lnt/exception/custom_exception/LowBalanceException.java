package com.lnt.exception.custom_exception;

/**
 * @author Smita
 *
 */
//to create custom exception or user-defined exception class 
//1->create a class and extends it from Exception class
//2->generate constructor from super class , no-arg (Exception()) and constructor with String arg Exception(String)
//LowBalanceException class is inheriting all the properties and method of Exception class
//we are using inheritance feature in java with the help of extends keyword
//in java a class can extends only one class
//multiple inheritance is not permitted in java only one class can be extended by a class
public class LowBalanceException extends Exception{

	public LowBalanceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LowBalanceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
