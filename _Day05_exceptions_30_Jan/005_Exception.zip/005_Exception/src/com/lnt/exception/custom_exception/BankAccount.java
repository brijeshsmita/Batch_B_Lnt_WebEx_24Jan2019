package com.lnt.exception.custom_exception;
/**
 * @author Smita
 *
 */
public class BankAccount {
	private long accId;
	private String accHolderName;
	private float accBalance;
	private static long numId;
	//generating unique id in java code
	static {
		numId= (long) (100000+ Math.random()*12345*12345);
	}
	//init block
	{
		accId=numId++;
	}
	public BankAccount() {
		// No-arg constructor
	}

	public BankAccount(String accHolderName, float accBalance) {
		super();
		this.accHolderName = accHolderName;
		this.accBalance = accBalance;
	}
	//what if the balance is low i.e less than amount to be withdraw
	//1000 is bal and u r trying t withdraw  2500
	//we need to inform the withdraw method that if somethign went worng then 
	//it will be handled by LowBalanceException using throws keyword
	public void withdraw(double amount) throws LowBalanceException{
		if(accBalance>=amount) {
			accBalance-=amount;//this is a keyword used to refer to the current object
			System.out.println("Withdrawal of amount "+amount+"succesfull and the current bal is "+this.accBalance);
		}else {
			//delegate the exceptin handling to other custom exception class
			throw new LowBalanceException("Withdrwal not possible as the current balance is low : "+accBalance);
			//LowBalanceException is a custom exception class need to be created by the programmer
		}
	}
	public void deposit(double amount) {
		this.accBalance+=amount;
	}
	//getters and setters

	public long getAccId() {
		return accId;
	}

	public void setAccId(long accId) {
		this.accId = accId;
	}

	public String getAccHolderName() {
		return accHolderName;
	}

	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}

	public float getAccBalance() {
		return accBalance;
	}

	public void setAccBalance(float accBalance) {
		this.accBalance = accBalance;
	}
	
}
