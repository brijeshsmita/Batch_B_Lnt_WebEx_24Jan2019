package com.lnt.exception.java7;
/**@author Smita
 */
public class MultipleExceptionDemo {
	public String greet() {
		return null;
	}

	public static void main(String[] args) {//array index starts from 0 
		//accepting inputs from command line args
		MultipleExceptionDemo obj=null;
		int n1=0;
		int n2=0;
		double div = 0;
		//try is a block which is used to write the code which is expected to throw an Exception
		//try block must be followed by either catch block or finally block
		//never declare variable inside try block , becoz it won't accessible outside try block
		//it will become local var which will available only within try block
		//div=n1/n2;//handle the exception
		 
		try {
			//System.out.println(obj.greet());//obj is pointing to null and we are trying to invoke method of null pointer -> throw NullPointerException
			n1=Integer.parseInt(args[0]);//"1" -> 1 
			//"ten" -> will throw NumberFormatException
			n2=Integer.parseInt(args[1]);
			System.out.println("Opening the file...");
			System.out.println("Writing on the file...");
			div=n1/n2;//handle th exception
			//for multiple catch block , the hierarchy of the exception must be followed from sub-class to super-class i.e child class to parent class		
		}
		catch (ArithmeticException e) {
			System.out.println("Sorry Boss!, Number cannot be divisible by Zero '0'");
			//multi-catch option using java 7 pipe operator, it has only 1 object 
			//in java 7 multi-catch Exception (super class) and child class cannot be written togather
			//as super class can handle both the exception so no need of writing sub-class
			//eg: in case of FileNotFoundException and IOException , write only parent class that is IOException
			//no need of writing child class i.e FileNotFoundException
		}catch (ArrayIndexOutOfBoundsException | NumberFormatException| NullPointerException  e) {
			System.out.println("Sorry Boss!,Somethign went wrong "+e);
			//when we try to print an object .... callback is made to ... toString() method of that class
			//if that class does not contain toString() method then Object class toString method is inoked...
		}finally {
			System.out.println("*****finally block is used to release the resources i.e close file or close DB connection"
					+ "\n *************finally block is always executed weather exception occurs or not!! ");
			System.out.println("if file is open then .... Close the file ......");
		}		
		//compilation error if local var are not initialized before use- must be initialized before use
		System.out.println("Division of two number is :"+div);
	}
}
