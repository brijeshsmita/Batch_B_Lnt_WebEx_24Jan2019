package com.lnt.exception;
/**@author Smita
 */
public class MultipleExceptionDemo {
	public String greet() {
		return null;
	}

	public static void main(String[] args) {//array index starts from 0 
		//accepting inputs from command line args
		MultipleExceptionDemo obj=null;
		int n1=0;
		int n2=0;
		double div = 0;
		//try is a block which is used to write the code which is expected to throw an Exception
		//try block must be followed by either catch block or finally block
		//never declare variable inside try block , becoz it won't accessible outside try block
		//it will become local var which will available only within try block
		//div=n1/n2;//handle the exception
		 
		try {
			System.out.println(obj.greet());//obj is pointing to null and we are trying to invoke method of null pointer -> throw NullPointerException
			n1=Integer.parseInt(args[0]);//"1" -> 1 
			//"ten" -> will throw NumberFormatException
			n2=Integer.parseInt(args[1]);
			System.out.println("Opening the file...");
			System.out.println("Writing on the file...");
			div=n1/n2;//handle th exception
			//for multiple catch block , the hierarchy of the exception must be followed from sub-class to super-class i.e child class to parent class		
		}
		catch (ArithmeticException e) {
			System.out.println("Sorry Boss!, Number cannot be divisible by Zero '0'");
		}catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Kindly pass the command line arguments before running the program!!");
		}catch (NumberFormatException e) {
			System.out.println("Kindly pass only numbers as input through the command line arguments before running the program!!");
		}catch (NullPointerException e) {
			System.out.println("Sorry You are trying to invoke method on an Object referecing to null pointer");
		}catch (Exception e) {
			System.out.println("Sorry Boss!,Somethign went wrong");
		}finally {
			System.out.println("*****finally block is used to release the resources i.e close file or close DB connection"
					+ "\n *************finally block is always executed weather exception occurs or not!! ");
			System.out.println("if file is open then .... Close the file ......");
		}		
		//compilation error if local var are not initialized before use- must be initialized before use
		System.out.println("Division of two number is :"+div);
	}
}
