/**
 * 
 */
package com.lnt.day13.t04.synchronization_block_runnable;

/**
 * @author Smita B Kumar
 *
 */
public class TestBankAccountSyncBlock {
	public static void main(String[] args) {
		// Lets create a shared bankAccountSyncBlock fro two thread
		BankAccountSyncBlock bankAccountSyncBlock = new BankAccountSyncBlock(101, "Kapoor", 10000.00) ;
		Runnable target1 = new MomSyncBlock(bankAccountSyncBlock);
		Thread momThread = new Thread(target1,"MomSyncBlock");
		
		Runnable target2 = new DadSyncBlock(bankAccountSyncBlock);
		Thread dadThread = new Thread(target2,"DadSyncBlock");
		
		Runnable target3 = new SonSyncBlock(bankAccountSyncBlock);
		Thread sonThread = new Thread(target3,"SonSyncBlock");
		
		momThread.start();dadThread.start();sonThread.start();
	}
}
class MomSyncBlock implements Runnable{
	private BankAccountSyncBlock bankAccountSyncBlock;
	public MomSyncBlock(BankAccountSyncBlock bankAccountSyncBlock) {
		this.bankAccountSyncBlock=bankAccountSyncBlock;
	}
	@Override
	public void run() {
		
		bankAccountSyncBlock.withdraw(8000);//business logic
	}
}
class DadSyncBlock implements Runnable{
	private BankAccountSyncBlock bankAccountSyncBlock;
	public DadSyncBlock(BankAccountSyncBlock bankAccountSyncBlock) {
		
		this.bankAccountSyncBlock=bankAccountSyncBlock;
	}
	@Override
	public void run() {		
		bankAccountSyncBlock.withdraw(5000);//business logic
	}
}
class SonSyncBlock implements Runnable{
	private BankAccountSyncBlock bankAccountSyncBlock;
	public SonSyncBlock(BankAccountSyncBlock bankAccountSyncBlock) {
		
		this.bankAccountSyncBlock=bankAccountSyncBlock;
	}
	@Override
	public void run() {
		
		bankAccountSyncBlock.withdraw(5000);//business logic
	}
}







