/**
 * 
 */
package com.lnt.day13.t04.synchronization_block_runnable;

/**
 * @author brije
 *
 */
public class TestPrinterSyncBlock {
	public static void main(String args[]) {
		SynchronizedPrinterBlock printer = new SynchronizedPrinterBlock();// only one object
		// both desktop1 and desktop2 is sharing the same printerSynMethod resource
		Thread t1 = new Desktop1(printer);t1.setName("Desktop-1");
		Thread t2 = new Desktop2(printer);t2.setName("Desktop-2");
		Thread t3 = new Desktop3(printer);t3.setName("Desktop-3");
		t1.start();
		t2.start();
		t3.start();
	}
}
