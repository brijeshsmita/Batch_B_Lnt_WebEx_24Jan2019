/**
 * 
 */
package com.lnt.day13.t01.without_synchronization;

/**
 * @author brije
 *
 */
// Shared Resource
public class Printer {
	// printing table of any number passed
	void printTable(int n) {// method not synchronized
		String threadName=Thread.currentThread().getName();
		for (int i = 1; i <= 10; i++) {
			System.out.println(threadName+ " : "+n * i);
			try {
				Thread.sleep(400);// 0.4 secs
			} catch (InterruptedException e) {
				System.out.println(e);
			}
		}
	}
}

class Desktop1 extends Thread {
	Printer printer;

	public Desktop1(Printer printer) {
		this.printer = printer;
	}

	public void run() {
		printer.printTable(30);
	}

}
class Desktop2 extends Thread {
	Printer printer;

	public Desktop2(Printer printer) {
		this.printer = printer;
	}

	public void run() {
		printer.printTable(50);
	}
}
class Desktop3 extends Thread {
	Printer printer;

	public Desktop3(Printer printer) {
		this.printer = printer;
	}

	public void run() {
		printer.printTable(70);
	}
}