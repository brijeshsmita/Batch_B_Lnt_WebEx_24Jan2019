/**
 * 
 */
package com.lnt.day13.t01.without_synchronization;

/**
 * @author Smita B Kumar
 *
 */
public class TestBankAccount {
	public static void main(String[] args) {
		// Lets create a shared bankAccount fro two thread
		BankAccount bankAccount = new BankAccount(101, "Kapoor", 10000.00) ;
		Thread momThread = new Mom(bankAccount);momThread.setName("MomSyncBlock");
		Thread dadThread = new Dad(bankAccount);dadThread.setName("SonSyncBlock");
		momThread.start();dadThread.start();
	}
}
class Mom extends Thread{
	private BankAccount bankAccount;
	public Mom(BankAccount bankAccount) {
		this.bankAccount=bankAccount;
	}
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName()+"\n******Your Account balance is : "+bankAccount.getAccBalanace());
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		bankAccount.withdraw(8000);//business logic
	}
}
class Dad extends Thread{
	private BankAccount bankAccount;
	public Dad(BankAccount bankAccount) {
		
		this.bankAccount=bankAccount;
	}
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName()+"\n******Your Account balance is : "+bankAccount.getAccBalanace());
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		bankAccount.withdraw(5000);//business logic
	}
}







