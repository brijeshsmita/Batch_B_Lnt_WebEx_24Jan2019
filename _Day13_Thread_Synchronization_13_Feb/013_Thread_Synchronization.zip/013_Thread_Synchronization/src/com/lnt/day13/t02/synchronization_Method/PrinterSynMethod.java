/**
 * 
 */
package com.lnt.day13.t02.synchronization_Method;

/**
 * @author brije
 *
 */
// Shared Resource
public class PrinterSynMethod {
	// printing table of any number passed
	synchronized void printTable(int n) {// method not synchronized
		String threadName=Thread.currentThread().getName();
		System.out.println(threadName+"...Requesting Printer for printing");
		for (int i = 1; i <= 10; i++) {
			System.out.println(threadName+ " : "+n * i);
			try {
				Thread.sleep(400);// 0.4 secs
			} catch (InterruptedException e) {
				System.out.println(e);
			}
		}
	}
}

class Desktop1SyncM extends Thread {
	PrinterSynMethod printerSynMethod;

	public Desktop1SyncM(PrinterSynMethod printerSynMethod) {
		this.printerSynMethod = printerSynMethod;
	}

	public void run() {
		printerSynMethod.printTable(30);
	}

}
class Desktop2SyncM extends Thread {
	PrinterSynMethod printerSynMethod;

	public Desktop2SyncM(PrinterSynMethod printerSynMethod) {
		this.printerSynMethod = printerSynMethod;
	}

	public void run() {
		printerSynMethod.printTable(50);
	}
}
class Desktop3SyncM extends Thread {
	PrinterSynMethod printerSynMethod;

	public Desktop3SyncM(PrinterSynMethod printerSynMethod) {
		this.printerSynMethod = printerSynMethod;
	}

	public void run() {
		printerSynMethod.printTable(70);
	}
}