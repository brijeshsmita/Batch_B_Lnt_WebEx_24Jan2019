package com.lnt.day13.t02.synchronization_Method;

/**
 * 
 * @author Smita B Kumar Thread Synchronization (One at a Time) That in case of
 *         shared resource , if one thread is accessing the resource , he will
 *         obtain the lock for it and none other thread can access that resource
 *         till he release the lock.
 */
public class BankAccountSync {
	private int accId;
	private String accHolderName;
	private double accBalanace;

	public BankAccountSync() {
		// TODO Auto-generated constructor stub
	}

	public BankAccountSync(int accId, String accHolderName, double accBalanace) {
		super();
		this.accId = accId;
		this.accHolderName = accHolderName;
		this.accBalanace = accBalanace;
	}
//we are making the method as synchronized (one thread gets the access -other thread will be waiting )
	public synchronized void withdraw(double amount) {// shared resource... method
		String threadName = Thread.currentThread().getName();
		System.out.println("\nHello ," + threadName + "...You are trying to withdraw amount of " + amount
				+ " and  .....your account balance is :" + accBalanace);

		if (accBalanace > amount) {
			accBalanace -= amount;
			System.out
					.println("\n" + threadName + ",Withdrawal Successful .....your account balance is :" + accBalanace);

		} else {
			System.err.println("\n Sorry " + threadName + "!! ,Withdrawal NOt Possible "
					+ ".....As your account balance is low :" + accBalanace);
		}
		System.out.println("\nBye bye ," + threadName + "*******************");
	}

	public int getAccId() {
		return accId;
	}

	public void setAccId(int accId) {
		this.accId = accId;
	}

	public String getAccHolderName() {
		return accHolderName;
	}

	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}

	public double getAccBalanace() {
		return accBalanace;
	}

	public void setAccBalanace(double accBalanace) {
		this.accBalanace = accBalanace;
	}

	@Override
	public String toString() {
		return "BankAccountSyncBlock [accId=" + accId + ", accHolderName=" + accHolderName + ", accBalanace=" + accBalanace
				+ "]";
	}

}
