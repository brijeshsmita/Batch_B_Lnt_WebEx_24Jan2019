/**
 * 
 */
package com.lnt.day13.t02.synchronization_Method;

/**
 * @author brije
 *
 */
public class TestPrinterSyncM {
	public static void main(String args[]) {
		PrinterSynMethod printerSynMethod = new PrinterSynMethod();// only one object
		// both desktop1 and desktop2 is sharing the same printerSynMethod resource
		Thread t1 = new Desktop1SyncM(printerSynMethod);t1.setName("Desktop1SyncM");
		Thread t2 = new Desktop2SyncM(printerSynMethod);t2.setName("Desktop2SyncM");
		Thread t3 = new Desktop3SyncM(printerSynMethod);t3.setName("Desktop3SyncM");
		t1.start();		t2.start(); t3.start();
	}
}
