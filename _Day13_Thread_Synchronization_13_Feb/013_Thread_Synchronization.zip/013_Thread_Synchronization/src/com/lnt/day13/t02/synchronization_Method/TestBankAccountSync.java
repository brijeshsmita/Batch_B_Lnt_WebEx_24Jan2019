/**
 * 
 */
package com.lnt.day13.t02.synchronization_Method;

/**
 * @author Smita B Kumar
 *
 */
public class TestBankAccountSync {
	public static void main(String[] args) {
		// Lets create a shared bankAccountSync fro two thread
		BankAccountSync bankAccountSync = new BankAccountSync(101, "Kapoor", 10000.00) ;
		Thread momThread = new MomSync(bankAccountSync);momThread.setName("MomSyncBlock");
		Thread dadThread = new DadSync(bankAccountSync);dadThread.setName("SonSyncBlock");
		momThread.start();dadThread.start();
	}
}
class MomSync extends Thread{
	private BankAccountSync bankAccountSync;
	public MomSync(BankAccountSync bankAccountSync) {
		this.bankAccountSync=bankAccountSync;
	}
	@Override
	public void run() {
		
		bankAccountSync.withdraw(8000);//business logic
	}
}
class DadSync extends Thread{
	private BankAccountSync bankAccountSync;
	public DadSync(BankAccountSync bankAccountSync) {
		
		this.bankAccountSync=bankAccountSync;
	}
	@Override
	public void run() {
		
		bankAccountSync.withdraw(5000);//business logic
	}
}







