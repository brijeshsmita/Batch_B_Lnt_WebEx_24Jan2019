package com.lnt.day13.t03.synchronization_block;

/**
 * 
 * @author Smita B Kumar Thread Synchronization (One at a Time) That in case of
 *         shared resource , if one thread is accessing the resource , he will
 *         obtain the lock for it and none other thread can access that resource
 *         till he release the lock.
 */
public class BankAccountSyncBlock {
	private int accId;
	private String accHolderName;
	private double accBalanace;

	public BankAccountSyncBlock() {
		// TODO Auto-generated constructor stub
	}

	public BankAccountSyncBlock(int accId, String accHolderName, double accBalanace) {
		super();
		this.accId = accId;
		this.accHolderName = accHolderName;
		this.accBalanace = accBalanace;
	}
//we are making the few line of code i.e block of code as synchronized not the whole method
	public void withdraw(double amount) {// shared resource... method
		String threadName = Thread.currentThread().getName();
		System.out.println("\nHello ," + threadName + "Welcome to withdraw method");
		synchronized(this){
			System.out.println("\n" + threadName + "...Your account balance is :" + accBalanace);	
			if (accBalanace > amount) {
				System.out.println("\n" + threadName + "...Now Trying to withdaw amount :" + amount);
				accBalanace -= amount;
				System.out
						.println("\n" + threadName + ",Withdrawal Successful .....your account balance is :" + accBalanace);
			} else {
				System.err.println("\n Sorry " + threadName + "!! ,Withdrawal NOt Possible "
						+ ".....As your account balance is low :" + accBalanace);
			}			
			System.out.println("\nBye bye ," + threadName + "*******************");
		}
	}

	public int getAccId() {
		return accId;
	}

	public void setAccId(int accId) {
		this.accId = accId;
	}

	public String getAccHolderName() {
		return accHolderName;
	}

	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}

	public double getAccBalanace() {
		return accBalanace;
	}

	public void setAccBalanace(double accBalanace) {
		this.accBalanace = accBalanace;
	}

	@Override
	public String toString() {
		return "BankAccountSyncBlock [accId=" + accId + ", accHolderName=" + accHolderName + ", accBalanace=" + accBalanace
				+ "]";
	}

}
