/**
 * 
 */
package com.lnt.day13.t03.synchronization_block;

/**
 * @author Smita B Kumar
 *
 */
public class TestBankAccountSyncBlock {
	public static void main(String[] args) {
		// Lets create a shared bankAccountSyncBlock fro two thread
		BankAccountSyncBlock bankAccountSyncBlock = new BankAccountSyncBlock(101, "Kapoor", 10000.00) ;
		Thread momThread = new MomSyncBlock(bankAccountSyncBlock);momThread.setName("MomSyncBlock");
		Thread sonThread = new SonSyncBlock(bankAccountSyncBlock);sonThread.setName("SonSyncBlock");
		Thread dadThread = new DadSyncBlock(bankAccountSyncBlock);dadThread.setName("DadSyncBlock");
		momThread.start();dadThread.start();sonThread.start();
	}
}
class MomSyncBlock extends Thread{
	private BankAccountSyncBlock bankAccountSyncBlock;
	public MomSyncBlock(BankAccountSyncBlock bankAccountSyncBlock) {
		this.bankAccountSyncBlock=bankAccountSyncBlock;
	}
	@Override
	public void run() {
		
		bankAccountSyncBlock.withdraw(8000);//business logic
	}
}
class DadSyncBlock extends Thread{
	private BankAccountSyncBlock bankAccountSyncBlock;
	public DadSyncBlock(BankAccountSyncBlock bankAccountSyncBlock) {
		
		this.bankAccountSyncBlock=bankAccountSyncBlock;
	}
	@Override
	public void run() {		
		bankAccountSyncBlock.withdraw(5000);//business logic
	}
}
class SonSyncBlock extends Thread{
	private BankAccountSyncBlock bankAccountSyncBlock;
	public SonSyncBlock(BankAccountSyncBlock bankAccountSyncBlock) {
		
		this.bankAccountSyncBlock=bankAccountSyncBlock;
	}
	@Override
	public void run() {
		
		bankAccountSyncBlock.withdraw(5000);//business logic
	}
}







