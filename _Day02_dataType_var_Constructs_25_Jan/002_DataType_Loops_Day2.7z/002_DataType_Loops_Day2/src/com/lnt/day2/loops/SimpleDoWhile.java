package com.lnt.day2.loops;
/**
 * 
 */


import java.util.Scanner;

/**
 * @author brije
 *
 */
public class SimpleDoWhile {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//i want to print the name 5 times
		System.out.println("for .............");
		for (int i = 1; i <=5; i++) {
			System.out.println(i+" : SMita");
		}
		//lets accept the number from user and then print the name that many times
		int i=1;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number of print....");
		int noOfPrint=scan.nextInt();
		System.out.println("with  While .............");
		while(i<noOfPrint) {//condition is executed first
			System.out.println(i++  +" Smita , i="+i);
			// ++i prefix - first increment then print the value (i+1 =i)
			// i++ postfix - first print the value then increment (i =i+1)
		}
		System.out.println("with do While .............");
		int y=1;
		do {
			System.out.println(y++  +" Smita , y="+y);		
		}while(i<noOfPrint);//condition is executed at exit
				

	}

}
