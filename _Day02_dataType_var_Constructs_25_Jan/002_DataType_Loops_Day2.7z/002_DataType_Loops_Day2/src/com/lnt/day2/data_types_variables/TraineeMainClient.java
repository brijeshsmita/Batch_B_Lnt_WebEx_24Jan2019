/**
 * 
 */
package com.lnt.day2.data_types_variables;

/**
 * @author Smita
 *
 */
public class TraineeMainClient {
	public static void main(String[] args) {
		int i=10;
		// how to create object in java
		Trainee t1 = new Trainee();
		t1.print();
		
		Trainee t2 = new Trainee();
		t2.print();
		//new keyword perform 3 task
		/*
		 * 1> create an object
		 * 2> allocates memory on heap
		 * 3> invoke constructor to initialize newly created object
		 */
		/*
		 * What is a method?
		 * method is used to define behavior of an object
		 * it has a name 
		 * it has a return type
		 * it may or may not have arguments/parameters list
		 * it has a body
		 * eg: public int add(int n1, int n2){
		 * 		return n1+n2;
		 * }
		 */
		/*
		 * Constructor is a special kind of method
		 * it has the same name of the class name
		 * it does not have any return type , not even void
		 * used to initialize newly created object
		 * it can be overloaded
		 * it cannot be inherited
		 * eg: public Trainee(){
		 * 		traineeId=1;
		 * 		traineeName="unknown";
		 * }
		 */
	}
}
