/**
 * 
 */
package com.lnt.day2.data_types_variables;

/**
 * @author Smita
 * create Trainee app to store trainee information
 */
public class Trainee {
	//instance variables are declared within the and not inside any method
//instance variables- properties/attribute of the object
//each object/instance will have it own copy of instance variable
	private int traineeId;
	private String traineeName;
	private double salary;
	private String email;
	private String phoneNumber;
	private boolean status;
	
	public void print() {
		System.out.println(
		"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
		+"\n                    Trainee Details                             \n"
		+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
		+"\n          Trainee Id    : "+traineeId
		+"\n          Trainee Name  : "+traineeName
		+"\n          Salary        : "+salary
		+"\n          Email         : "+email
		+"\n          Phone Number  : "+phoneNumber
		+"\n          Status        : "+status
		+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	}
}
