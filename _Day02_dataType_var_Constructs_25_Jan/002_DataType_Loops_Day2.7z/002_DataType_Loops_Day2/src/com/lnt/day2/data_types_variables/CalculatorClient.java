/**
 * 
 */
package com.lnt.day2.data_types_variables;

/**
 * @author brije
 *
 */
public class CalculatorClient {
	public static void main(String[] args) {
		//created instance/object of calculator class
		Calculator mobileCalculator = new Calculator();
		int n1=10;
		int n2=20;
		//to invoke method in java we use '.' dot operator
		//objectName.methodName
		int result = mobileCalculator.add(n1, n2);
		System.out.println("Addition of two number is :"+result);
		//new keyword perform 3 task
		/*
		 * 1> create an object
		 * 2> allocates memory on heap
		 * 3> invoke constructor to initialize newly created object
		 */
	}

}
