package com.lnt.day2.data_types_variables;
//structure
public class Calculator {
	public int add(int n1, int n2){
				return n1+n2;
	}
}
