package com.lnt.day2.constructs;
/**
 * 
 */

import java.util.Scanner;
/**
 * @author Smita
 *
 */
public class SwitchEmpDemo {
	public static void main(String[] args) {
		//to accept input from user we will use java.util.Scanner class
		Scanner scan = new Scanner(System.in);
		//here we are associating scanner to standard input device 
		System.out.println("Enter Your Choice between 1-6");
		
		int choice = scan.nextInt();//accepting int value
		//type switch +cltr+space
		switch(choice) {
		case 1:
			System.out.println("1> Adding the Empolyee record");
			break;//terminate the current construct/loop		
		case 2:
			System.out.println("2> Modifying the Empolyee record");
			break;		
		case 3:
			System.out.println("3> Searching the Empolyee record");
			break;	
		case 4:
			System.out.println("4> Deleting the Empolyee record");
			break;	
		case 5:
			System.out.println("5> Exiting the Empolyee Application");
			break;
		default:
			System.err.println("Sorry You entered the wrong choice....");
			break;
		}
		//java 7 onward we can use String literals in switch case
		//here we are associating scanner to standard input device 
		System.out.println("Enter Your Payment Mode\n cash \n creditCard"
				+ "\n  debitCard \n NetBanking \n Wallet");
		
		String payMode = scan.next();//accepting String value with next method of scanner
		//type switch +cltr+space
		switch(payMode) {
		case "cash":
			System.out.println("1> Payment Mode is cash");
			break;//terminate the current construct/loop		
		case "creditCard":
			System.out.println("2> Payment Mode is creditCard");
			break;		
		case "debitCard":
			System.out.println("Payment Mode is debitCard");
			break;	
		case "NetBanking":
			System.out.println("Payment Mode is NetBanking");
			break;	
		case "Wallet":
			System.out.println("Payment Mode is Wallet");
			break;
		default:
			System.err.println("Sorry You entered the wrong payment mode....");
			break;
		}
	}
}
