/**
 * 
 */
package com.lnt.day2.constructs;

/**
 * @author Smita
 *
 */
public class StringSwitchDemo {
	public static void main(String args[]) {
//in switch case we can have String literals also java 7 onwards
		String color = "Blue";
		String bgColor = " BackGroud Colour";

		switch (color) {
		case "Blue":
			bgColor = "Blue is your " + bgColor;
			break;
		case "Red":
			bgColor = "Red is your " + bgColor;
			break;
		default:
			bgColor = "White is your " + bgColor;
		}

		System.out.println("bgColor type: " + bgColor);
	}
}
