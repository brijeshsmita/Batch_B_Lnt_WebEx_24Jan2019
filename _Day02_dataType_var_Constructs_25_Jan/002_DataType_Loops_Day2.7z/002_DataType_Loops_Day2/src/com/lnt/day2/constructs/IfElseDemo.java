/**
 * 
 */
package com.lnt.day2.constructs;

/**
 * @author Smita
 *
 */
public class IfElseDemo {
	public static void main(String[] args) {
		int age = Integer.parseInt(args[0]);//accepting number from cmd line arg
		if(age>=18) {//conditional operators in java
			System.out.println("Eligible to vote");
		}else {
			System.err.println("NOT Eligible to vote");
			System.out.println("Kindly wait for few years more to go for voting...");
			//System is a class in java which has 3 static properties
			/*
			 * 1> in : associated with standard input device to accept the input from it
			 * 2> out: associated with standard output device to display the output on it
			 * 3> err: associated with standard output device to display the error on it
			 */
		}		
		int n1=30;
		int n2=30;
		int n3=30;
		int max=0;
		//which number is the max number among 3 number		
		//&& - if both the statements are true
		if((n1>n2)&& (n1>n3)) {
			max=n1;
		}else if((n2>n1)&& (n2>n3)) {
			max=n2;
		}
		else if((n3>n1)&& (n3>n2)) {
			max=n3;
		}else {
			System.out.println("The number are equals or distinct");
		}
		System.out.println("The Max number is : "+max);
		/*if(n1>n2) {//nested if 
		if(n1>n3) {
			max=n1;
		}else {
			
		}
		
	}*/
	}

}
