/**
 * 
 */
package com.lnt.day2.constructs;
//inorder to use any class inside your class 
//we need to import the class 
//only public class can be imported
//import statement must be 2nd line of code of .java file
//there can be none or many import statements
import java.util.Scanner;//packageName.className

/**
 * @author Smita
 *
 */
public class SwtichDemo {
	public static void main(String[] args) {
		// many options for payments
		System.out.println("Enter your payment Mode from 1-6 Only"
				+ "\n 1. COD"
				+ "\n 2. Credit Card Option"
				+ "\n 3. Debit Card Option"
				+ "\n 4. Net Banking Option"
				+ "\n 5. Wallet Option"
				+ "\n 6. UPI Option");
		Scanner scanner = new Scanner(System.in);
		//we have created the object of Scanner class 
		//to accept input from Standard input device
		int payMode=scanner.nextInt();
		//nextInt method of Scanner class
		//is used to accept integer inputs
		switch (payMode) {
		case 1:
			System.out.println("Your payment will be done with COD");
			break;
	//break keyword it used to terminate the current construct or loop
		case 2:
			System.out.println("Your payment will be done with Credit Card Option");
			break;
		case 3:
			System.out.println("Your payment will be done with Debit Card Option");
			break;
		case 4:
			System.out.println("Your payment will be done with Net Banking Option");
			break;
		case 5:
			System.out.println("Your payment will be done with Wallet Option");
			break;
		case 6:
			System.out.println("Your payment will be done with UPI Option");
			break;
		default:
			System.err.println("Sorry Boss , you have enter worng option,"
					+ "\nKindly Re-Enter your payment Mode from 1-6 Only");
			break;
		}

	}

}
