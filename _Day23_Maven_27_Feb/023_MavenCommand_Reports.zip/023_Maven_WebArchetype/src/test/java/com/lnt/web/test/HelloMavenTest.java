/**
 * 
 */
package com.lnt.web.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.lnt.web.HelloMaven;

/**
 * @author Smita B Kumar
 *
 */
public class HelloMavenTest {
	String name;
	public HelloMavenTest() {
		name="Smita";
	}

	/**
	 * Test method for {@link com.lnt.maven.HelloMaven#greet(java.lang.String)}.
	 */
	@Test//wrong value
	public void testGreet1() {
		String actualResult;
		String expectedResult="Welcome, "+name;
		actualResult= HelloMaven.greet(name);
		assertEquals(expectedResult, actualResult);
		
	}
	@Test//correct input
	public void testGreet2() {
		String actualResult;
		String expectedResult="Welcome, "+name;
		actualResult= HelloMaven.greet(name);
		assertEquals(expectedResult, actualResult);		
	}
}
