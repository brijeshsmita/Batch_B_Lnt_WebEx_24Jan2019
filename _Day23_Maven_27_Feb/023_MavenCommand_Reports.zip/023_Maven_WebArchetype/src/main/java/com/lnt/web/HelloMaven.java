/**
 * 
 */
package com.lnt.web;

import java.util.Scanner;

/**
 * @author Smita B Kumar
 *
 */
public class HelloMaven {
	public HelloMaven() {
		// TODO Auto-generated constructor stub
	}
	public static String greet(String name) {
		return "Welcome, "+name;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        System.out.println("Enter two numbers");
        int n1=sc.nextInt();
        int n2=sc.nextInt();
        int sum=n1+n2;

        System.out.println("Sum of n1+ n2 = " + sum);
	}
}
