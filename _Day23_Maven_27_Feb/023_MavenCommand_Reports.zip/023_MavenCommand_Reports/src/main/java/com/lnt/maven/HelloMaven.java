/**
 * 
 */
package com.lnt.maven;

/**
 * @author Smita B Kumar
 *
 */
public class HelloMaven {
	public HelloMaven() {
		// TODO Auto-generated constructor stub
	}
	public static String greet(String name) {
		return "Welcome, "+name;
	}
}
