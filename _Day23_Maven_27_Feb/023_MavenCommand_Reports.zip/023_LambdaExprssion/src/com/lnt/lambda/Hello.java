/**
 * 
 */
package com.lnt.lambda;

/**
 * @author Smita B Kumar
 *
 */
public class Hello implements IGreeting {


	/* (non-Javadoc)
	 * @see com.lnt.lambda.IGreeting#greet(java.lang.String)
	 */
	@Override
	public String greet(String name) {
		// TODO Auto-generated method stub
		return "Hello, "+name;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/*IGreeting g1 = new Hello();
		System.out.println(g1.greet("Smita"));*/
		
		IGreeting g1 = (name) -> {return "Hello, "+ name;};
		 System.out.println(g1.greet("Smita"));
		   
	}

}
