/**
 * 
 */
package com.lnt.lambda;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Smita B Kumar
 *
 */
public class MethodRefLamda {

	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		list.add("Smita");list.add("Mita");list.add("Rita");list.add("Sita");list.add("Gita");
		System.out.println("List printed with Lambda :");
		list.forEach((name)->System.out.println(name));
		
		//method reference
		System.out.println("List printed with method referece :");
		list.forEach(System.out::println);

	}

}
