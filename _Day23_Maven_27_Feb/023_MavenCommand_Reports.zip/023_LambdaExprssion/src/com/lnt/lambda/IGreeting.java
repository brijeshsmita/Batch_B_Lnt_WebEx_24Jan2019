/**
 * 
 */
package com.lnt.lambda;

/**
 * @author Smita B Kumar
 *
 */
@FunctionalInterface//non mandatory to mark with annotation
public interface IGreeting {
	public String greet(String name);//no body - abstract
}
