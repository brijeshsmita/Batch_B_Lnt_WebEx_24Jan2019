/**
 * 
 */
package com.lnt.lambda;

/**
 * @author Smita B Kumar
 *
 */
public class LambdaDemo2 {	
	public static void main(String[] args) {
		ICalculator calci = (int n1, int n2)-> {return n1+n2;};
		System.out.println("Sum of two numbers is : "+calci.add(10, 20));
		
		calci = (n1,n2)-> {return n1+n2;};
		System.out.println("Sum of two numbers is : "+calci.add(100, 202));
		
		IGreeting g1 = (String name)-> {return "Hello ,"+name;};
		System.out.println(g1.greet("Smita"));
	}
}
@FunctionalInterface
interface ICalculator{
	int add(int n1,int n2);
}