/**
 * 
 */
package com.lnt.day13_thread01_without_synchronization;

/**
 * @author brije
 *
 */
public class TestAccount1 {
	public static void main(String[] args) {
		BankAccount acc1 = new BankAccount(101, "Smita", 10000);
		Thread t1 = new Mom(acc1);t1.setName("MOM");
		Thread t2 = new Dad(acc1);t2.setName("DAD");
		//mom and dad thread is sharing the same acc i.e acc1
		t1.start();
		t2.start();
	}

}
class Mom extends Thread{
	BankAccount acc1;
	public Mom(BankAccount acc1) {
		this.acc1=acc1;
	}
	@Override
	public void run() {
		acc1.withdraw(8000);
	}
}

class Dad extends Thread{
	BankAccount acc1;
	public Dad(BankAccount acc1) {
		this.acc1=acc1;
	}
	@Override
	public void run() {
		acc1.withdraw(5000);
	}
}