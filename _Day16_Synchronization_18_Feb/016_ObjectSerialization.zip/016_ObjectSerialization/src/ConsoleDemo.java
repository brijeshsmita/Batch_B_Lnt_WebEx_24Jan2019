import java.io.Console;
import java.io.Serializable;

import com.lnt.serialize.util.ObjectSerialization;
/** * @author brije * */
public class ConsoleDemo {
	public static void main(String[] args) {
		//java 6 onwards
		Console console = System.console();
		/* * System is a class in java
		 * which provide 3 static properties
		 * in - is associated with standard input device to accept input from user
		 * out - is associated with standard output device to display output on the console
		 * err - is associated with standard output device to display error on the console		 */
		System.out.println("Enter User name : ");
		String username=console.readLine();
		System.out.println("Enter Password : ");
		char[] password=console.readPassword();
		System.out.println("Hello ,"+username +" ,Your psssword is : "+password);
		System.out.println("coverting char arr to string :"+String.valueOf(password));//converting char array into string
		User user = new User(username, String.valueOf(password));
		String pathname="E:\\Batch_B_Lnt_WebEx\\BatchBLnt_WS\\016_ObjectSerialization\\src\\user.dat";
		//lets serialize the user object
		ObjectSerialization.serializeObject(user,pathname );		
		//deserialize the object
		User u1 = (User) ObjectSerialization.deSerializeObject(pathname);
		System.out.println("Deserialized User : "+u1);
	}
}
class User implements Serializable{
	private static final long serialVersionUID = 4679553289916271630L;
	String username;
	transient String password;/*we dont want the var to be serialized mark it as transient*/
	public User() {
		// TODO Auto-generated constructor stub
	}
	public User(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	@Override
	public String toString() {
		return "User [username=" + username + ", password=" + password + "]";
	}
}
