package com.lnt.day16.io.serialization;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Date;
import java.util.Scanner;
import com.lnt.day15_io_serialization03.ObjectSerialization;
/** * @author brije * */
public class EmployeeService implements IEmployeeService {
	
	@Override
	public Employee acceptEmpDetails() {
		String firstName;String lastName;String phoneNo;String email;Employee e1 = null;
		String address;
		Scanner sc = new Scanner(System.in);// java 5 onward
		System.out.println("Enter Your firstName : ");// next is used to accept STring input
		firstName = sc.next();
		System.out.println("Enter Your lastName : ");// next is used to accept STring input
		lastName = sc.next();
		System.out.println("Enter Your Phone No : " );// next is used to accept STring input
		phoneNo = sc.next();
		System.out.println("Enter Your email : ");// next is used to accept STring input
		email = sc.next();
		try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in));) {// legacy
			System.out.println("Enter You Address");// multiple line from user ,v vl use BufferedReader
			address = br.readLine();
			System.out.println("Address is :"+address);
			e1 = new Employee(firstName, lastName, phoneNo, email, new Date());

		} catch (Exception e) {
			e.printStackTrace();
		}
		return e1;
	}
	//persist/write the object on to the file/serialization	
	@Override
	public void addEmployee(Employee employee) {
		// in-order to read and writ on the file we need - FileInputStream and FileOutputStream
		//in-order to increase performance best practice -> BufferedInputStream, BufferedOutputSTream
		//as we will reading and writing objects so we will need- ObjectInputStream and ObjectOutputStream
		//as we want automatic resource management  -> thus we will use try-with-resource block
		String filePath="src/employee.dat";
		try(FileOutputStream out = new FileOutputStream(filePath);
			BufferedOutputStream bos = new BufferedOutputStream(out);
			ObjectOutputStream oos= new ObjectOutputStream(bos);){
			oos.writeObject(employee);
			oos.flush();
			System.out.println("\nEmployee Object Persisted in file : "+filePath);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	//read the object from the file/De-serialization
	@Override
	public Employee readEmployee() {
		// in-order to read from the file we need - FileInputStream -
		//in-order to increase performance best practice -> BufferedInputStream
		//as we will reading objects so we will need- ObjectInputStream
		//as we want automatic resource management  -> thus we will use try-with-resource block
		String filePath="src/employee.dat";
		Employee employee =null;
		try(FileInputStream in = new FileInputStream(filePath);
				BufferedInputStream bis = new BufferedInputStream(in);
				ObjectInputStream ois = new ObjectInputStream(bis);
				){
			employee= (Employee) ois.readObject();//readObject returns object thus need to type cast to employee object
			
		} catch (IOException |ClassNotFoundException e) {
			e.printStackTrace();
		}			
		return employee;
	}
}
