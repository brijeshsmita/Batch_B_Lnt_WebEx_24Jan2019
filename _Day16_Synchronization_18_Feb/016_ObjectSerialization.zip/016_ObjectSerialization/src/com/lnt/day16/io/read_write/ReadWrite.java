/**
 * 
 */
package com.lnt.day16.io.read_write;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * @author Smita B Kumar
 *
 */
public class ReadWrite {
	public static void main(String[] args) {
		// read byte from System.in(keyboard)
		byte [] bArr= {65, ' ','h','i'};
		try (InputStream dis = new ByteArrayInputStream(bArr);
			/*byte*/	BufferedInputStream bis = new BufferedInputStream(dis);
				/*char*/BufferedReader br = new BufferedReader(new InputStreamReader(System.in)) ;
/*writer char buffer in the file*/BufferedWriter bw = new BufferedWriter(new FileWriter("src//input.txt"))){
			for( byte b : bArr) {
				System.out.print((char)b);
			}
			String str;
			System.out.println("\nEnter lines of text, 'stop' to quit");
			do {
				str = br.readLine();
				System.out.println(str);
				bw.write(str+"\n");
				bw.flush();
			} while (!str.equalsIgnoreCase("stop"));
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
