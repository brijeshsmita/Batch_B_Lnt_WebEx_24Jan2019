/**
 * 
 */
package com.lnt.day16.io.serialization;

/**
 * @author Smita B Kumar
 *
 */
public interface IEmployeeService {

	Employee acceptEmpDetails();
	void addEmployee(Employee employee);//persist the object on the file/serialization
	Employee readEmployee();//read the object from the file/De-serialization

}
