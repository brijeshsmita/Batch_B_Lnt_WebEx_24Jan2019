/**
 * 
 */
package com.lnt.day16.io.serialization;

import java.io.IOException;

/**
 * @author Smita B Kumar
 *
 */
public class EmployeeClient {

	public static void main(String[] args) throws IOException {
		IEmployeeService employeeService = new EmployeeService();
		//invoking service to accept employee details
		Employee employee = employeeService.acceptEmpDetails();
		System.out.println("\nAccepted Employee details from User .... "+employee);
		//invoke service to persist employee object
		employeeService.addEmployee(employee);
		//if the employee class has not been marked/tagged/implemented Serializable interface
		//then the compiler will throw NotSerializableException
		Employee emp= employeeService.readEmployee();
		if(emp!=null) {
			System.out.println("\nObject De-serialized ... "+emp);
		}
	}
}
