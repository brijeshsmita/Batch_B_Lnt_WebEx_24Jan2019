package com.lnt.day16.io_04read_write_csv;

import java.io.BufferedReader;
import java.io.FileReader;
//First way is by using java.io.BufferedReader and split() method from java.lang.String class, 
public class CSVFileBufferedReader {
	public static void main(String[] args) {	
		String myFile = ".//src//emails.xlsx";
		final String DELIMITER = ";";
		String line = "";
		try(					
		BufferedReader fileReader = new BufferedReader(new FileReader(myFile));){
			// Read the file line by line
			while ((line = fileReader.readLine()) != null) {	//end of file			
				String[] tokens = line.split(DELIMITER);				
				for (String token : tokens)
				{
					System.out.println(token+";");
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}