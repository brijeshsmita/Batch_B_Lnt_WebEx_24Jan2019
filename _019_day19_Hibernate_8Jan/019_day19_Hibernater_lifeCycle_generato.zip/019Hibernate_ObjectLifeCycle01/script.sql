  create table  customerANTN
  (	
		custId float,
		custName varchar(20),
		email varchar(20),
		phone varchar(20)
 );