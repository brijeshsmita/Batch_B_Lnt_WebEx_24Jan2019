/**
 * 
 */
package com.lnt.jdbc.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author brije
 *
 */
public class MyConnection {
	private static Connection conn;

	public static Connection getConn() {
		String url="jdbc:oracle:thin:@localhost:1521:orahome";//(SID)hr,sysdb
		String user="system";
		String password="system";
		try {//Step 1:load the driver class at runtime
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//Step 2:get the connection
			conn=DriverManager.getConnection(url, user, password);
		} catch (ClassNotFoundException |SQLException e) {
			// multi-catch block of java7
			e.printStackTrace();
		}
		return conn;
	}
	public static void setConn(Connection conn) {
		MyConnection.conn = conn;
	}
	public static void closeConn() {
		if(conn!=null) {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

