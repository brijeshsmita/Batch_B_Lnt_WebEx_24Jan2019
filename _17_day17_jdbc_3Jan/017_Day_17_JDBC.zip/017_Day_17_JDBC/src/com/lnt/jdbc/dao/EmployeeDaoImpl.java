/**
 * 
 */
package com.lnt.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.lnt.jdbc.exception.EmployeeException;
import com.lnt.jdbc.model.Employee;
import com.lnt.jdbc.util.MyConnection;

/**
 * @author brije
 *
 */
public class EmployeeDaoImpl implements IEmployeeDao {
	private static Connection conn;
	//private static Statement stmt = null;//best practice say always use preparedStatment 
	private static PreparedStatement ps = null;
	private static ResultSet rs = null;
	private static Scanner scan = new Scanner(System.in);
	static {
		conn = MyConnection.getConn();
		if (conn != null)
			System.out.println("connection Obtained!!!");
		else
			System.err.println("Sorry Boss!! connection NOT Obtained!!!");
	}
	/* (non-Javadoc)
	 * @see com.lnt.jdbc.dao.IEmployeeDao#addEmployee(com.lnt.jdbc.model.Employee)
	 */
	@Override
	public Integer addEmployee(Employee employee) throws EmployeeException {
		String sql="insert into myemp values(?,?,?)";
		int noOfRec=0;
		try {
			//step 1: obtain ps obj
			ps= conn.prepareStatement(sql);
			//step 2: set the placeholder values of ps
			ps.setInt(1, employee.getEmpId());
			ps.setString(2, employee.getEmpName());//get the value from the employee object passed at runtime
			ps.setDouble(3, employee.getEmpSal());
			//step 3 execute the ps and return the int value for DML operation
			noOfRec= ps.executeUpdate();//never pass the sql in case of ps as it is pre-compiled
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();//at the time of development only later delete this line of code
			throw new EmployeeException("Error while addEmployee in dao ..."+e.getMessage());
		}		
		return noOfRec;
	}

	/* (non-Javadoc)
	 * @see com.lnt.jdbc.dao.IEmployeeDao#listAllEmployee()
	 */
	@Override
	public List<Employee> listAllEmployee() throws EmployeeException {
		String sql="select * from myemp";//no semicolan in case of sql string in java code
		Employee emp=null;
		List<Employee> empList=new ArrayList<>();
		try {
			//step 1: obtain ps obj
			ps= conn.prepareStatement(sql);
			//step 3 execute the ps and return the int value for DML operation
			rs= ps.executeQuery();//never pass the sql in case of ps as it is pre-compiled
			//step 4 check rs has the next value or not and then set the Employee value
			
			while(rs.next()) {
				//create emp object and set the value of emp by fetching it from rs
				emp= new Employee();
				emp.setEmpId(rs.getInt(1));
				emp.setEmpName(rs.getString(2));//pass either columnIndex or columnName 
				emp.setEmpSal(rs.getDouble("emp_sal"));//i have passed the column name instead of columnIndex
				//add the emp to the list
				empList.add(emp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();//at the time of development only later delete this line of code
			throw new EmployeeException("Error while deleteEmployee in dao ..."+e.getMessage());
		}		
		return empList;
	}

	/* (non-Javadoc)
	 * @see com.lnt.jdbc.dao.IEmployeeDao#updateEmployee(com.lnt.jdbc.model.Employee)
	 */
	@Override
	public Integer updateEmployee(Employee employee) throws EmployeeException {
		String sql="update myemp set emp_name=?,emp_sal=? where emp_id=?";//no semicolan in case of sql string in java code
		int noOfRec=0;
		try {
			//step 1: obtain ps obj
			ps= conn.prepareStatement(sql);
			//step 2: set the placeholder values of ps
			ps.setString(1, employee.getEmpName());
			ps.setDouble(2, employee.getEmpSal());
			ps.setInt(3, employee.getEmpId());//get the value from the employee object passed at runtime
			//step 3 execute the ps and return the int value for DML operation
			noOfRec= ps.executeUpdate();//never pass the sql in case of ps as it is pre-compiled
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();//at the time of development only later delete this line of code
			throw new EmployeeException("Error while updateEmployee in dao ..."+e.getMessage());
		}		
		return noOfRec;
	}

	/* (non-Javadoc)
	 * @see com.lnt.jdbc.dao.IEmployeeDao#deleteEmployee(java.lang.Integer)
	 */
	@Override
	public Integer deleteEmployee(Integer empId) throws EmployeeException {
		String sql="delete from myemp where emp_id=?";//no semicolan in case of sql string in java code
		int noOfRec=0;
		try {
			//step 1: obtain ps obj
			ps= conn.prepareStatement(sql);
			//step 2: set the placeholder values of ps
			ps.setInt(1, empId);//get the value from the employee object passed at runtime
			//step 3 execute the ps and return the int value for DML operation
			noOfRec= ps.executeUpdate();//never pass the sql in case of ps as it is pre-compiled
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();//at the time of development only later delete this line of code
			throw new EmployeeException("Error while deleteEmployee in dao ..."+e.getMessage());
		}		
		return noOfRec;
	}

	/* (non-Javadoc)
	 * @see com.lnt.jdbc.dao.IEmployeeDao#searchEmployeeById(java.lang.Integer)
	 */
	@Override
	public Employee searchEmployeeById(Integer empId) throws EmployeeException {
		String sql="select * from myemp where emp_id=?";//no semicolan in case of sql string in java code
		Employee emp=null;
		try {
			//step 1: obtain ps obj
			ps= conn.prepareStatement(sql);
			//step 2: set the placeholder values of ps
			ps.setInt(1, empId);//get the value from the employee object passed at runtime
			//step 3 execute the ps and return the int value for DML operation
			rs= ps.executeQuery();//never pass the sql in case of ps as it is pre-compiled
			//step 4 check rs has the next value or not and then set the Employee value
			
			if(rs.next()) {
				//create emp object and set the value of emp by fetching it from rs
				emp= new Employee();
				emp.setEmpId(rs.getInt(1));
				emp.setEmpName(rs.getString(2));//pass either columnIndex or columnName 
				emp.setEmpSal(rs.getDouble("emp_sal"));//i have passed the column name instead of columnIndex
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();//at the time of development only later delete this line of code
			throw new EmployeeException("Error while deleteEmployee in dao ..."+e.getMessage());
		}		
		return emp;
	}

}
