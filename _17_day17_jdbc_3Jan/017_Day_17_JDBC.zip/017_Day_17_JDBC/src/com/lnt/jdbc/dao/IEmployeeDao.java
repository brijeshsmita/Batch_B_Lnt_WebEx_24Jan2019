/**
 * 
 */
package com.lnt.jdbc.dao;

import java.util.List;

import com.lnt.jdbc.exception.EmployeeException;
import com.lnt.jdbc.model.Employee;

/**
 * @author Smita
 *
 */
//DAO- Data access layer , which is responsible to interact with database only
//restaurant - chef ( which takes care of data i.e food)
public interface IEmployeeDao {
	Integer addEmployee(Employee employee)throws EmployeeException;    //C-create/insert/add
	List<Employee> listAllEmployee()throws EmployeeException;          //R-Retrieve/select All
	Integer updateEmployee(Employee employee)throws EmployeeException;//U-Update/modify	
	Integer deleteEmployee(Integer empId)throws EmployeeException;     //D-delete/remove
	Employee searchEmployeeById(Integer empId)throws EmployeeException;//S-search
}
