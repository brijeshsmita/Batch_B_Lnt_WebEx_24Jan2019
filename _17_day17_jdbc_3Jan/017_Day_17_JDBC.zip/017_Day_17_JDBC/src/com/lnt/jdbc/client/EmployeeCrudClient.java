/**
 * 
 */
package com.lnt.jdbc.client;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.lnt.jdbc.dao.EmployeeDaoImpl;
import com.lnt.jdbc.dao.IEmployeeDao;
import com.lnt.jdbc.exception.EmployeeException;
import com.lnt.jdbc.model.Employee;

/**
 * @author brije
 *
 */
public class EmployeeCrudClient {
	private static IEmployeeDao employeeDao= new EmployeeDaoImpl();
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		//add employee record
		System.out.println("Enter Employee Id : ");
		Integer empId=scan.nextInt();
		Employee employee = new Employee(empId, "Mona", 999.99);
		
		try {
			//calling dao layer method to add employee
			Integer insert= employeeDao.addEmployee(employee);
			if(insert>0) {
				System.out.println("record Inserted!!!" +empId);
			
			}else {
				System.err.println("record NOT Inserted!!!");
			}
			
			//search the record which has been inserted
			Employee empFound = employeeDao.searchEmployeeById(empId);
			if(empFound!=null) {
				System.out.println("record FOund !!!"+empFound);
			
			}else {
				System.err.println("record NOT Found!!!");
			}
			//update the record which has been inserted
			employee.setEmpName("Saira");
			employee.setEmpSal(111.111);
			int update = employeeDao.updateEmployee(employee);
			if(update>0) {
				System.out.println("record Updated !!!"+employee);
			
			}else {
				System.err.println("record NOT Updated!!!");
			}
			//delete the record which has been inserted
			int delete = employeeDao.deleteEmployee(empId);
			if(delete>0) {
				System.out.println("record Deleted !!!"+empId);
			
			}else {
				System.err.println("record NOT Deleted!!!");
			}
			//delete the record which has been inserted
			List<Employee> empList = employeeDao.listAllEmployee();
			if(empList!=null) {
				System.out.println("****************************** Employee  Records ******************************");
				for (Employee e:empList) {
					System.out.println(e);
				}
			}else {
				System.err.println("record NOT Founds!!!");
			}
			} catch (EmployeeException e) {
			System.out.println("Error at main ...."+e);
		}
		
	}

}
