/*
C - create/insert   -> insert into myemp values(111,'Smita',999.99);
R - retrieve/select -> select * from myemp;
U - update/modify   -> update myemp set emp_sal=888.88 where emp_id=111;
D - delete/remove   -> delete from myemp where emp_id=111;
S - search          -> select * from myemp where emp_id=111;
*/

create table myemp
(emp_id number(8) primary key,
emp_name varchar2(30),
emp_sal number(5,2));

/*sequence which is used to generate automtic value in a sequence */
create sequence seq_myemp 
start with 1000
increment by 1;

insert into myemp values(seq_myemp.nextval,'Smita',999.99);
insert into myemp values(seq_myemp.nextval,'Rita',777.99);
commit;

select * from myemp;

update myemp set emp_sal=888.88 where emp_id=1000;

delete from myemp where emp_id=1000;

select * from myemp where emp_id=1001;