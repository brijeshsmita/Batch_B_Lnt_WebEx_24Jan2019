/**
 * 
 */
package com.lnt.day10.treeMap;

import java.util.Comparator;

/**
 * @author brije
 *
 */
public class SortEmpByName implements Comparator<Emp>{

	@Override
	public int compare(Emp o1, Emp o2) {
		// sorting by empName
		return o1.getEmpName().compareTo(o2.getEmpName());
	}

}
