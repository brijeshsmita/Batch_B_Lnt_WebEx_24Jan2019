package com.lnt.day10.treeMap;

public class Emp {
	private String empName;
	private double salary;
	public Emp() {
		// TODO Auto-generated constructor stub
	}
	public Emp(String empName, double salary) {
		super();
		this.empName = empName;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Emp [empName=" + empName + ", salary=" + salary + "]";
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
}
