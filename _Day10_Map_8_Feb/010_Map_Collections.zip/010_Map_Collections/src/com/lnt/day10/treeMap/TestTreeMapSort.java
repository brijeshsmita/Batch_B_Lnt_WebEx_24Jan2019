package com.lnt.day10.treeMap;
import java.util.Set;
import java.util.TreeMap;
public class TestTreeMapSort {
	public static void main(String[] args) {
		Emp e1 = new Emp("Ciaz", 222);
		Emp e2 = new Emp("Era", 444);
		Emp e3 = new Emp("Benz", 111);
		Emp e4 = new Emp("Aish", 555);
		Emp e5 = new Emp("Diya", 333);
		//lets create com.lnt.day10.treeMap to sort by empName
		TreeMap<Emp, String> treeMap = new TreeMap<>(new SortEmpByName());
		//sort the tree map with the comparator object
		treeMap.put(e1, e1.getEmpName());
		treeMap.put(e2, e2.getEmpName());
		treeMap.put(e3, e3.getEmpName());
		treeMap.put(e4, e4.getEmpName());
		treeMap.put(e5, e5.getEmpName());
		Set<Emp> set = treeMap.keySet();//another way of Map.entrySet 
		//here we are gettign only the keys in the set instead of the whole map
		System.out.println("\n*****************Sorting by Name*******************");
		for(Emp key : set) {
			System.out.println("Key : "+key+" \t Value : "+treeMap.get(key));
			/*passing the key and fetching the value from treemap*/
		}		
		TreeMap<Emp, String> treeMap1 = new TreeMap<>(new SortEmpBySal());
		treeMap1.put(e1, e1.getEmpName());
		treeMap1.put(e2, e2.getEmpName());
		treeMap1.put(e3, e3.getEmpName());
		treeMap1.put(e4, e4.getEmpName());
		treeMap1.put(e5, e5.getEmpName());
		Set<Emp> set1 = treeMap1.keySet();
		//another way of Map.entrySet 
				//here we are gettign only the keys in the set instead of the whole map
		System.out.println("\n*****************Sorting by Salary****************");
		for(Emp key : set1) {
			System.out.println("Key : "+key+" \t Value : "+treeMap.get(key));
			/*passing the key and fetching the value from treemap*/
		}
	}
}
