/**
 * 
 */
package com.lnt.day10.map;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

/**
 * @author brije
 *
 */
public class TreeMapDemoByValue {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Contact c1 = new Contact(444, "ciaz", "rez", "ciaz@gmail.com", "9879878888");
		Contact c2 = new Contact(555, "aish", "raj", "aish@gmail.com", "9879879999");
		Contact c3 = new Contact(111, "Bina", "mote", "bina@gmail.com", "9879877777");
		Contact c4 = new Contact(222, "Era", "rez", "era@gmail.com", "9879875555");
		Contact c5 = new Contact(333, "Dale", "fez", "dale@gmail.com", "9879876666");
		TreeMap<Contact,Integer> contactMap = new TreeMap<>(new SortContactById());
		contactMap.put(c1,111);//com.lnt.day10.treeMap does not allow null key
		contactMap.put(c2,555);//duplicate keys will be overlapped
		contactMap.put(c3,333);
		contactMap.put(c4,444);
		contactMap.put(c5,222);
		
		Set set = contactMap.entrySet();//step 1 > enter the map into set
		Iterator iter= set.iterator();//step 2> obtain the iterator for set
		System.out.println("Tree Map- Sorted By Id\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
				+ "Contact Key     | Contact Value"
				+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		while(iter.hasNext()) {//step 3> iterate through set
			//step 4> enter the map through map.entry
			Map.Entry<Integer, Contact> contactEntry= (Entry<Integer, Contact>) iter.next();
			System.out.println(contactEntry.getKey()+"\t\t| "+contactEntry.getValue());
			//if you try to print an object, call back is given to toString() method 
		}
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
		TreeMap<Contact,Integer> contactMap1 = new TreeMap<>(new SortContactByName());
		contactMap1.put(c1,111);//com.lnt.day10.treeMap does not allow null key
		contactMap1.put(c2,555);//duplicate keys will be overlapped
		contactMap1.put(c3,333);
		contactMap1.put(c4,444);
		contactMap1.put(c5,222);
		
		 set = contactMap1.entrySet();//step 1 > enter the map into set
		 iter= set.iterator();//step 2> obtain the iterator for set
		System.out.println("Tree Map- Sorted By Name\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
				+ "Contact Key     | Contact Value"
				+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		while(iter.hasNext()) {//step 3> iterate through set
			//step 4> enter the map through map.entry
			Map.Entry<Contact,Integer> contactEntry1= (Entry<Contact,Integer>) iter.next();
			System.out.println(contactEntry1.getKey()+"\t\t| "+contactEntry1.getValue());
			//if you try to print an object, call back is given to toString() method 
		}
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");

	}

}
