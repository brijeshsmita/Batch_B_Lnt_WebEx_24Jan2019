package com.lnt.day20_hibernate.namedQuey.client;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.hibernate.util.HibernateUtil;
import com.lnt.day20_hibernate.namedQuey.model.Customer;

public class HQLNamedQuery {
/*Named queries are created via class-level annotations on entities; normally, 
 * the queries apply to the entity in whose source file they occur, 
 * but there�s no absolute requirement for this to be true.
Named queries are created with the @NamedQueries annotation, which contains an array of @NamedQuery sets; 
each has a query and a name.
we can execute the named query using method getNamedQuery()
 */
	public static void main(String[] args) {

		 Customer customer1 = new Customer("Shiv", "shiv@g.com","9879879666");
		// created a customer object
		String custName="Smita";
		Customer customer2 = new Customer("Nysha", "nysha@g.com", "9879870000");
		Customer customer3 = new Customer("Shivanh", "shivansh@g.com","9879879111");
		Customer customer4 = new Customer("Dheeraj", "dheeraj@g.com","9871111666");
		Customer customer5 = new Customer("Aish", "aish@g.com","8889879666");
		// Customer is in Transient state, as it is not associated with db or
		// session object

		SessionFactory factory = HibernateUtil.getSessionFactory();
		// step 1 : session Factory
		Session session = null;

		Transaction transaction = null;
		try {
			session = factory.openSession();
			transaction=session.beginTransaction();
			session.save(customer1);session.save(customer2);session.save(customer3);session.save(customer4);session.save(customer5);
			transaction.commit();
			System.out.println("\n************Listing all Customer Records *************\n");
			Query query = session.getNamedQuery("customer.findAll");
			//accessing the namedQuery defined at the customer class 
			List<Customer> results =query.list();
			for (Customer c1 : results) {
				System.out.println(c1);
			}
		
			
			System.out.println("\n************Finding the Customer by name *************\n");
			query = session.getNamedQuery("customer.findByName");
			//accessing the namedQuery defined at the customer class 
			query.setString("custName", "Shiv");//set the named parameter
			//Customer c1 =(Customer) query.uniqueResult();//uniqueResult return Object
			for (Customer c1 : results) {
				System.out.println(c1);
			}
		
			session.close();// Closing the session
			
			System.out.println("\n************Update the Customer *************\n");
			session=factory.openSession();
			transaction=session.beginTransaction();
			query=session.getNamedQuery("customer.updateEmail");
			//set the parameter
			query.setParameter("email", "shiv1@gmail.com");
			query.setParameter("custId", 3L);
			//executeUpdate
			query.executeUpdate();
			transaction.commit();
			
			System.out.println("\n************Finding the Customer By Email*************\n");
			query=session.getNamedQuery("customer.findByEmail");
			//set the parameter
			query.setParameter("email", "shiv1@gmail.com");
			results =query.list();
			for (Customer c1 : results) {
				System.out.println(c1);
			}
			session.close();
		} catch (Exception ex) {
			ex.printStackTrace();
			if (transaction != null)
				transaction.rollback();
		} finally {
			if (factory != null)
				HibernateUtil.closeFactory();
		}
	}

}

