package com.lnt.day20_hibernate.creteriaQuery.client;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.hibernate.util.HibernateUtil;
import com.lnt.day20_hibernate.creteriaQuery.model.Employee;
public class HQLCreteriaQueryEmployee {
	public static void main(String[] args) {
		Employee employee1 = new Employee("Siya", "Raj", 2000.99,"9998885555", "siya@gmail.com", new Date());
		Employee employee2 = new Employee("Sita", "Kumar",9999.99, "9998887888", "sita@gmail.com", new Date());
		Employee employee3 = new Employee("Jiya", "Sen", 5000.99,"9998887770", "jiya@gmail.com", new Date());
			// step 1 : create session Factory
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = null;
		Transaction transaction = null;
		try {
			// //step 2 : open session
			session = factory.openSession();
			// step 3 : In case of DML operations (Data manipulation insert
			// update and delete)
			// then begin transactions
			transaction = session.beginTransaction();
			// step 4 : saving the employee -insert/create
			Long id = (long) session.save(employee1);
			System.out.println(" Employee record inserted with Id : " + id);
			Long id2 = (long) session.save(employee2);
			System.out.println(" Employee record inserted with Id : " + id2);
			Long id3 = (long) session.save(employee3);
			System.out.println(" Employee record inserted with Id : " + id3);
			// step 5 : committing transaction
			transaction.commit();
			System.out.println("\n**************Listing all the employee records Salary>10000 **************\n");
			Criteria cr = session.createCriteria(Employee.class);
			cr.add(Restrictions.gt("salary", 10000.00));//salary>10000
			List<Employee> empRes= cr.list();
			for (Employee e1 : empRes) {
				System.out.println(e1);
			}			
			cr = session.createCriteria(Employee.class);
			cr.addOrder(Order.desc("salary"));
			empRes= cr.list();
			System.out.println("\n**************Listing all the employee records ordered by Salary **************\n");
			for (Employee e1 : empRes) {
				System.out.println(e1);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			if (transaction != null)
				transaction.rollback();
		} finally {
			if (factory != null)
				factory.close();
		}
	}
}
