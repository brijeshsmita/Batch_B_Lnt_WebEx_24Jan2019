/**
 * 
 */
package com.hibernate.client;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.hibernate.entity.Customer;
import com.hibernate.util.HibernateUtil;

/**
 * @author Smita B Kumar
 *
 */
public class HQLCrud {
	static final String SELECT_ALL_CUSTOMER = "from Customer";
	static final String SELECT_CUSTOMER_BY_NAME = "from Customer c where c.custName =:custName";
	static final String SELECT_CUSTOMER_BY_NAME1 = "from Customer c where c.custName ='Smita'";
	//c is alias -> temporary name given for the class in the HQL
	public static void main(String[] args) {
		SessionFactory factory = HibernateUtil.getSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = null;
		Query query=null;
		List<Customer> custList=null;
		Long custId=1l;
		try {
			// HQL focus on CLASS AND its Property as its Object Query Language
			// hql queries are not case -sensitive only the class and property name are case-sensitive
			// fetch all the records from the customer table
			Customer customer = new Customer("Smita", "smita@lnt.com", "9879879876");
			
			//C-create
			System.out.println("\n Adding customer records");
			transaction=session.beginTransaction();
			custId=(Long) session.save(customer);
			if(custId>0)System.out.println("customer records added with unique id : "+custId);
			else System.out.println("customer records NOT added");
			transaction.commit();
			
			//R-read
			System.out.println("\n List all customer records");
			query = session.createQuery(SELECT_ALL_CUSTOMER);//from Customer
			custList= query.list();
			if(custList!=null)custList.forEach(cust->System.out.println(cust));
			else System.out.println("customer records NOT Found");			
			
				
			
			//Search By Email by dynamically passing the value 
			System.out.println("\n Get  customer records By CUstomer Email");
			query = session.createQuery("from Customer where email=:emailParam");
			String emailValue="smitakumar@g.com";
			query.setString("emailParam", emailValue);
			custList= query.list();
			if(custList!=null)custList.forEach(cust->System.out.println(cust));
			else System.out.println("customer records NOT Found with email : "+emailValue);	
			
			session.close();
			
			session= factory.openSession();
			//Update the record by HQL by passing static value
			System.out.println("\nUpdating the record by HQL by passing static value");
			String update_HQL="update Customer c set c.custName='Mona' where c.custId=4";
			transaction = session.beginTransaction();
			query = session.createQuery(update_HQL);
			int noOfRecords1=query.executeUpdate();//DML operations
			if(noOfRecords1>0)System.out.println("customer records Updated");
			else System.err.println("customer records NOT Updated");
			transaction.commit();
			//Search By Id 
			System.out.println("\n Get  customer records By CUstomer Id");
			Customer customer1 = (Customer) session.get(Customer.class, 4L);
			if(customer1!=null)System.out.println("customer records  Found"+customer1);
			else System.out.println("customer records NOT Found");			
			session.close();
			
			session= factory.openSession();
			//Update the record by HQL by passing dynamic value
			System.out.println("\nUpdating the record by HQL by passing dynamic value");
			String update_HQL1="update Customer c set c.email=:emailId where c.custName=:name ";
			//dynamic values
			String email="Mona@gmail.com";
			String custName="Mona";
//beign tx
			transaction = session.beginTransaction();
			//create query
			query= session.createQuery(update_HQL1);
			//set the query dynamic value parameters
			query.setParameter("emailId", email);
			query.setParameter("name", custName);
			//executeUpdate-DML operations
			noOfRecords1=query.executeUpdate();
			//commit tx
			transaction.commit();
			if(noOfRecords1>0)System.out.println("customer records Updated");
			else System.err.println("customer records NOT Updated");
			
			//Search By Id 
			System.out.println("\n Get  customer records By CUstomer Id");
			customer1 = (Customer) session.get(Customer.class, 4L);
			if(customer1!=null)System.out.println("customer records  Found"+customer1);
			else System.out.println("customer records NOT Found");			
			session.close();
			
			session= factory.openSession();
			//Delete the record by HQL by passing static value
			/*System.out.println("\n Deleting the record by HQL by passing static value");
			String delete_HQL="delete from Customer c where custId="+custId;
			transaction = session.beginTransaction();
			query = session.createQuery(delete_HQL);
			int rec=query.executeUpdate();//DML operations-del,ins,up
			transaction.commit();
			if(rec>0)System.out.println("customer records Deleted");
			else System.err.println("customer records NOT Deleted");*/
			
			//Delete the record by HQL by passing Dynamic value
			System.out.println("\n Deleting the record by HQL by passing Dynamic value");
			String delete_HQL1="delete from Customer c where c.custName=:custName";
			transaction=session.beginTransaction();
			query=session.createQuery(delete_HQL1);
			//set the parameter
			query.setParameter("custName", "Smita");
			int recDel=query.executeUpdate();//DML
			transaction.commit();
			if(recDel>0)System.out.println("customer records Deleted");
			else System.err.println("customer records NOT Deleted");
			
			//R-read
			System.out.println("\n List all customer records");
			query = session.createQuery(SELECT_ALL_CUSTOMER);//from Customer
			custList= query.list();
			if(custList!=null)custList.forEach(cust->System.out.println(cust));
			else System.out.println("customer records NOT Found");				
			
			session.close();
					
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			HibernateUtil.closeFactory();
		}

	}

}
