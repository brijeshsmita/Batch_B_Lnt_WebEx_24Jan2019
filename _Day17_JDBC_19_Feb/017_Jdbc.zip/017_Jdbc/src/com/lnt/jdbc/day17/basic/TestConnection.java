/**
 * 
 */
package com.lnt.jdbc.day17.basic;

import java.sql.Connection;

import com.lnt.jdbc.day17.util.ConnectionUtil;

/**
 * @author Smita B Kumar
 *
 */
public class TestConnection {
	public static void main(String[] args) {
		Connection conn = ConnectionUtil.getConnection();
		if(conn!=null) {
			System.out.println("Connection Obtained!!"+conn);
		}else {
			System.err.println("Connection NOT Obtained!!"+conn);
		}
	}
}
