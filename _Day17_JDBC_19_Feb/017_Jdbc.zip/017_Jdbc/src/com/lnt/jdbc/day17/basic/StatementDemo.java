/**
 * 
 */
package com.lnt.jdbc.day17.basic;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;

import com.lnt.jdbc.day17.util.ConnectionUtil;

/**
 * @author Smita B Kumar
 *
 */
public class StatementDemo {
	public static void main(String[] args) {
		//execute simple query using Stement Object
		//step 1 > obtain connection
		//step 2 > obtain statement object
		//step 3 > execute query by passing SQL and collect ResultSet
		//step 4 > iterate over ResultSet to get the data
		//step 5 > close everything or use try with resource block
		String sql = "SELECT * FROM EMP123";
		try(Connection conn = ConnectionUtil.getConnection();
			Statement st = conn.createStatement();) {
			ResultSet rs= st.executeQuery(sql);
			System.out.println("Fetching the list of all the employees");
			while (rs.next()) {//we will iterate till rs will have the record
				System.out.println(rs.getInt(1)+"\t|\t"+rs.getString(2)+"\t|\t"+rs.getDouble(3));//passed the column index
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
