/**
 * 
 */
package com.lnt.jdbc.day17.emp.exception;

/**
 * @author brije
 *
 */
public class EmployeeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2981714501324018516L;

	public EmployeeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
