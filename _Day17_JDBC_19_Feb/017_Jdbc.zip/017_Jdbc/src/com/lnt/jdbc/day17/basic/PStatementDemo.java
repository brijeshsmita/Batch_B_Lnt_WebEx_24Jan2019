/**
 * 
 */
package com.lnt.jdbc.day17.basic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.lnt.jdbc.day17.util.ConnectionUtil;

/**
 * @author Smita B Kumar
 *
 */
public class PStatementDemo {
	public static void main(String[] args) {
		//execute pre-compiled query using PreparedStatement Object
		//step 1 > obtain connection
		//step 2 > obtain PreparedStatement by passing SQL query for pre-compilation
		//step 3 > set the value for the placeholder, (value to be passed at runtime) 
		//step 4 > execute query and collect ResultSet (dont pass SQL here)
		//step 5 > iterate over ResultSet to get the data
		//step 6 > close everything or use try with resource block
		String sql = "SELECT * FROM EMP123 where eid=?";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee Id to be searched....");
		int empId = sc.nextInt();
		try(Connection conn = ConnectionUtil.getConnection();
			PreparedStatement pst = conn.prepareStatement(sql);/*pre-compiled statement*/) {
			//before executing the query-set the placeholder value (i.e value to the ?)
			pst.setInt(1, empId);//? index and setting eid = 3 at runtime
			ResultSet rs= pst.executeQuery();//dont pass SQL here
			System.out.println("Searching the employee record for Employee Id : "+empId);
			if (rs.next()) {//we will iterate till rs will have the record
				System.out.println(rs.getInt(1)+"\t|\t"+rs.getString(2)+"\t|\t"+rs.getDouble(3));//passed the column index
			}	else {
				System.err.println("Sorry No record found for Employee Id : "+empId);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
