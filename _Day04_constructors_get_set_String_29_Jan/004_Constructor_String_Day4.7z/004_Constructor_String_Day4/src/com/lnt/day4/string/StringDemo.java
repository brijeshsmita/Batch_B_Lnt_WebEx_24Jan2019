/**
 * 
 */
package com.lnt.day4.string;

/**
 * @author Smita
 *https://www.sanfoundry.com/java-mcqs-string-class/
https://www.javatpoint.com/methods-of-string-class
 */
public class StringDemo {
	public static void main(String[] args) {
		//1: String is a class in java
		String s = new String("Lnt");
		//2: String can be also used as Primitives- means can be declared without using new keyword
		String s1="Lnt";
		System.out.println("s1 :"+s1+" s1 hashCode :"+s1.hashCode());
		//any object created in java - gets a unique reference number 
		//by the java compiler that is known as hashCode
		//hashCode-(unique number generated for each and every object created in java)
		//3: Strings are immutable objects in java- 
		s1+="-Infotech";//concatenation
		System.out.println("s1 :"+s1+" s1 hashCode :"+s1.hashCode());
		//4: any changes made to String will create a new object as it can't be modified
		System.out.println("s1.substring(4) : "+s1.substring(4));//index starts with 0
		//Returns a string that is a substring of this string. The substring begins with the character at the specified index andextends to the end of this string. 
		System.out.println("s1.substring(4,8) : "+s1.substring(4,8));//starts with 4th- 7 as 8th will be excluded
		//start to (end-1)
		s1.concat("-Ltd.");//new object will be created but did we assigned the value to s1
		System.out.println("s1 after s1.concat(\"-Ltd.\"); : "+s1+" s1 hashCode :"+s1.hashCode());
		s1=s1.concat("-Ltd.");//new object will be created but did we assigned the value to s1
		System.out.println("s1 after s1=s1.concat(\"-Ltd.\"); : "+s1+" s1 hashCode :"+s1.hashCode());
		s1=s1.toUpperCase();
		System.out.println("s1.toUpperCase() :"+s1+" s1 hashCode :"+s1.hashCode());
		System.out.println("s1.toUpperCase() :"+s1.toLowerCase()+" s1 hashCode :"+s1.hashCode());

	}

}
