/**
 * 
 */
package com.lnt.day4.constructor;
//step 1: package declaration
//step 2: import statement

/**
 * @author Smita
 *
 */
//step 3: public class
public class Employee {
	//step 4: //instance variable
	private int empId;
	private String empName;
	private double empSal;
	//step 5: //static variable (if any)
	private static int numId;
	//step 6: //static block (if any)
	static {
		System.out.println("\n********Static block is used to initialize ... only static variable..."
				+ "\n invoked only once before creation of an object");
		//type casting means converting double value to int value
		numId=(int) (1000 + Math.random()*123.123);//Math is a in-build class from java.lang.* package 
		//it provide random() method to generate random numbers in double format.
	}
	//step 7: //init block 
	//initializer block or init block which is used to initialize non-static /instance variable 
	//which need to be initialize before constructing an object
	//variable before invocation of a constructors
	{
		System.out.println("\n********init block is used to initialize ... non static variable..."
				+ "\n invoked for every object created...... before invoking the constructor");
		empId=numId++;// numId=numId+1
	}
	/*
	 * Contructors 
	-a special kind of method 
	-which has the same name of the class name
	- no return type not even void
	- use to initialize the newly created object
	- can be parameterized/overloaded
	-cannot be inherited
	 */
	//mark constructor as public, so that object of this class can be created
	//step 8:Constructors
	public Employee(){
		System.out.println("********************Employee class NO-ARGS constructor********************");
		empName="unknown";
		empSal=1000.00;
	}
	//parameterized constructor/overloaded constructor
	public Employee(String empName, double empSal) {
		System.out.println("********************Employee class Parameterized constructor/overloaded constructor********************");
		this.empName = empName;
		this.empSal = empSal;
	}
	//step 9:methods	
	public void print() {
		//all object/reference variable data-type default value is null
		System.out.println(
		"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
		+"\n                    Employee Details                             \n"
		+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
		+"\n          Employee Id    : "+this.empId
		+"\n          Employee Name  : "+empName
		+"\n          Salary         : "+empSal
		+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	}
	
	//step 10:Generate getters and setters- use to provide access to private members outside the class
	//all getters n setters methods must be always marked as public
	//getter/accessors method naming convention - getXxx() eg: int  getEmpId() 
		//getter method has no arguments and returns same dataType as of the variable dataType
	public int getEmpId() {
		return empId;
	}
	//setter/mutators method naming convention -setXxx() eg:  void setEmpId(int empId) 
			//setter method same arguments dataType as of the variable dataType  and returns void
	public void setEmpId(int empId) {
	//local variable name and instance variable name can be same in java
		//then in-order to refer instance variable .... we will use this keyword in java
		this.empId = empId;// this keyword .... refers to current object
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}
	
}//end of Employee class
