/**
 * 
 */
package com.lnt.day4.constructor;

/**
 * @author brije
 *
 */
public class EmployeeMain {//client code which will execute
	public static void main(String[] args) {
		//3 employee will join the organization
		Employee e1 = new Employee();
		//at the time of creation of an object, the value of instance variable is passed
		Employee e2 = new Employee("Mona",9999.99);//compiler here is searching for the method/constrcutor
		//which has String,double parameters
		//parameterized constructor/overloaded constructor
		Employee e3 = new Employee("Raj",8888.88);
	/*	System.out.println("three emp object created by te compiler default contructors"
				+ "\n(only when there is no constructor in the class)");*/
		//e1.empName="Zara"; e1.empSal=20000.00;
		e1.setEmpName("Zara");e1.setEmpSal(20000.00);
		//instance variable are marked as private , therefore cannot be accessed outside the EMployee class directly
		//there are certain scenarios where we have to request for the access or setting of private data members
		//such a request can be made using ....accessors/mutators also known as getters and setters ..... methods
		e1.print();
		e2.print();
		e3.print();

	}

}
