/**
 * 
 */
package com.lnt.day6.client;

import com.lnt.day6.emp.Employee;
import com.lnt.day6.emp.mgr.Manager;
import com.lnt.day6.emp.mgr.sales.SalesManager;

/**
 * @author brije
 *
 */
public class EmployeeClient {
	public static void main(String[] args) {
		//Employee e1 = new Employee();//creating employee object by invoking no-arg constructor
		//System.out.println("E1 : "+e1);//trying to print employee object 
		//java s magic (java ka jadu)
		//whenever u try to print the object , a callback is made to --toString()(Returns a string representation of the object.)
		//first it will check toString() method in employee class
		//if there is no toString() method defined then toString() method of super class will be invoked
		//in out case super class of employee is Object class
		//Object class toString method return -> getClass().getName()+"@"+hexString(hashCode())
		//so lets override toString method of Object class
		
		//method Overriding- re-writing the method in the child class/subclass 
		//re-writing the method ... with same method name , same return type, same argument list, same exception list 
		//but different implementation of the method in the child-class/subclass
		//Manager m1 = new Manager();
		//System.out.println("M1 : "+m1);
		//constructor is invoked from super class to sub class
		//SalesManager sm1 = new SalesManager();
		//when we create object of sub-class//constructor is invoked from super class to sub class
		SalesManager sm2 = new SalesManager("Zara", 99.99, 9.0, 100.0);
		System.out.println("SM2: "+sm2);
		sm2.print();
	}

}
