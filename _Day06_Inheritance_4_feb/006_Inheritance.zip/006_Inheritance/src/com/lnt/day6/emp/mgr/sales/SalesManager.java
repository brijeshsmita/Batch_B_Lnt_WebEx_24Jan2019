/**
 * 
 */
package com.lnt.day6.emp.mgr.sales;

import com.lnt.day6.emp.mgr.Manager;

/**
 * @author brije
 *
 */
public class SalesManager extends Manager{
	//achieving inheritance using extends keyword, 
	//to inherit all the properties and methods of the extends class except constructor
	/*private int empId;
	private String empName;
	private double empSal;
	private double bonus;*/
	private double commission;
	
	/*static int numId;
	 static {
		//static init block to initialize only static variable
		numId= (int) (1000+ Math.random()*1234.1234);
	}
//init block to initialize those variable which need to be created before invocation of a constructor
	{
		empId=numId++;
	}*/
	public SalesManager() {
		System.out.println("No-Arg constructor of SalesManager class");
	}

	public SalesManager(String empName, double empSal, double bonus, double commission) {
		super(empName, empSal, bonus);
		this.commission = commission;
		System.out.println("Overloaded constructor of SalesManager class");
	}
	@Override
	public void print() {
		// TODO Auto-generated method stub
		super.print();
			//all object/reference variable data-type default value is null
			System.out.print(
			"\n          SalesManager Commission    : "+commission
			+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
	}
	@Override
	public String toString() {
		return "SalesManager [commission=" + commission + ", toString()=" + super.toString() + "]";
	}
	
}
