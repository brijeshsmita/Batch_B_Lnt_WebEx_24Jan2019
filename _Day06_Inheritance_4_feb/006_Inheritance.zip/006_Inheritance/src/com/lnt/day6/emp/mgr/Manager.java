/**
 * 
 */
package com.lnt.day6.emp.mgr;

import com.lnt.day6.emp.Employee;

/**
 * @author brije
 *
 */
public class Manager extends Employee{
	//achieving inheritance using extends keyword, 
	//to inherit all the properties and methods of the extends class except constructor
	/*private int empId;
	private String empName;
	private double empSal;*/
	private double bonus;
	/*static int numId;
	static {
		//static init block to initialize only static variable
		numId= (int) (1000+ Math.random()*1234.1234);
	}
//init block to initialize those variable which need to be created before invocation of a constructor
	{
		empId=numId++;
	}*/
	public Manager() {
		super();
		//by default call to super class constructor is there
		//super keyword has two usage
		//1> super is used to invoke super class constructor
			//- call to super in constructor must be the first line of code.
		//2> used to invoke super class method... can be invoked anywhere inside the method
		System.out.println("No-Arg constructor of Manager class");
		
	}
	public Manager(String empName, double empSal, double bonus) {
		super(empName, empSal);//super will invoke overloaded constructor of the super class
		//we can pass arguments to super keyword , so that we ca make call to specific constructor
		this.bonus = bonus;
		System.out.println("Overloaded constructor of Manager class");
	}
	
	@Override
	public void print() {
		// TODO Auto-generated method stub
		super.print();
			//all object/reference variable data-type default value is null
			System.out.println(
			"\n          Manager Bonus    : "+bonus
			+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		
	}
	@Override
	public String toString() {
		return "Manager [bonus=" + bonus + ", toString()=" + super.toString() + "]";
	}
	
	
}
