/**
 * 
 */
package com.lnt.day14.reflection;

/**
 * @author brije
 *
 */
public class Employee {

}
