/**
 * 
 */
package com.lnt.day14.reflection;

/**
 * @author brije
 *
 */
public class TestLoadClass {
	public static void main(String[] args) {
		
		try {
			//lets load the class at runtime with the help of Class.forName()
			Class c1 = Class.forName("com.lnt.day14.reflection.Employee");
			/*Returns the {@code Class} object associated with the class or
		     * interface with the given string name*/
			System.out.println("The class loaded at runtime : "+c1.getName());
		} catch (ClassNotFoundException e) {//checked exception
			e.printStackTrace();
		}
	}

}
