/**
 * 
 */
package com.lnt.day14.reflection;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * @author brije
 *
 */
public class AccessPrivateMethod2 {

	public static void main(String[] args) throws ClassNotFoundException, 
	InstantiationException, IllegalAccessException, 
	NoSuchMethodException, SecurityException,
	IllegalArgumentException, InvocationTargetException {
		//private is accessible only within the class not outside the class
		
		//lets resolve it using java.lang.reflect.Method class
		/*
		 * 1> setAccessibilitiy()
		 * 2> invoke()
		 */
		//load the class dynamically
		Class c1 = Class.forName("com.lnt.day14.reflection.Action");
		Action s2 = (Action) c1.newInstance();//throws 	InstantiationException, IllegalAccessException
		
		Method m1 = c1.getDeclaredMethod("cube",new Class[] {int.class});//NoSuchMethodException, SecurityException
		m1.setAccessible(true);//setting the accessiblity of the private method to true
		m1.invoke(s2, 5);//throws IllegalArgumentException, InvocationTargetException
//passing 2 the argument
		m1= c1.getDeclaredMethod("max", int.class,int.class);//variable arguments 
		m1.setAccessible(true);
		System.out.println("m1.invoke(s2, 99,88) ...Max of two numbers is :"+m1.invoke(s2, 99,88));//accepts var args - dynamic array 
		
//passing 2 the argument of different types		
		m1= c1.getDeclaredMethod("printInfo", int.class,String.class);//variable arguments 
		m1.setAccessible(true);
		m1.invoke(s2, 99,"Zara");//accepts var args - dynamic array 
	}

}
class Action{
	private void cube(int n1) {
		System.out.println("***Cube of number "+n1+" is :"+(n1*n1*n1));
	}
	private void printInfo(int age, String name) {
		System.out.println("***Hello ,"+name +"....Age is  "+age);
	}
	private int max( int n1, int n2) {
		return n1>n2? n1:n2;
	}
}
