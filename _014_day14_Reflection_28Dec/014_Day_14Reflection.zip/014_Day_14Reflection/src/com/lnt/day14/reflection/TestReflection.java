/**
 * 
 */
package com.lnt.day14.reflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Scanner;

/**
 * @author Smita
 *
 */
public class TestReflection {

	/**
	 * @param args
	 * @throws ClassNotFoundException
	 */
	public static void main(String[] args) throws ClassNotFoundException {
		// accept the name of the class through scanner
		System.out.println("Enter The fully qualified  name of the class to be loaded dynamically :");
		Scanner scan = new Scanner(System.in);
		String className = scan.next();
		Class c1 = Class.forName(className);
		System.out.println("\nThe class loaded dynamically : "+c1.getName());
		
		//let us display the list of all declared fields
		System.out.println("\n*****Display list of all declared fields*******");
		Field [] fieldArr = c1.getDeclaredFields();
		for (Field i:fieldArr) {
			System.out.println(i);
		}
		//let us display the list of all declared fields
		System.out.println("\n*****Display list of public fields*******");
		fieldArr = c1.getFields();//list only public fields
		for (Field i:fieldArr) {
			System.out.println(i);
		}
		
		//let us display the list of all the declared constructors
		System.out.println("\n*****Display list of all declared Constructors*******");
		Constructor [] constArr=c1.getDeclaredConstructors();
		for(Constructor i: constArr) {
			System.out.println(i);
		}
		
		//let us display the list of all the declared Methods
		System.out.println("\n*****Display list of all declared Methods*******");
		Method [] methodArr=c1.getDeclaredMethods();
		for(Method i: methodArr) {
			System.out.println(i);
		}
		//let us display the list of all the declared Methods
		System.out.println("\n*****Display list of all  Methods*******");
		methodArr=c1.getMethods();
		for(Method i: methodArr) {
			System.out.println(i);
		}

	}

}
