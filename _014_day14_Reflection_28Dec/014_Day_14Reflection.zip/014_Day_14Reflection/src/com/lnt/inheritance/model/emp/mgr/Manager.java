/**
 * 
 */
package com.lnt.inheritance.model.emp.mgr;

import com.lnt.inheritance.model.emp.Employee;

/**
 * @author Smita
 *
 */
//extends keyword is used to achieve inheritance in java
//we can extend only one class in java
//as java does not support multiple inheritance
public class Manager extends Employee{
	//instance variables
	private Double bonus;
	//no_arg Constructor
	public Manager() {
		//by default call to super is made 
		super(); //super without parameter
		System.out.println("*****Manager class no-arg constructor*******");
		this.bonus =0.0;
	}
//overloaded constructor
	public Manager(String empName, Double empSal, Double bonus) {		
		super(empName, empSal);//super with parameter therefore it will invoke super clas overlaoded constr
		//call to super in case of constructor must be first line of code
		System.out.println("*****Manager class Overloaded constructor*******");
		this.bonus = bonus;
	}
	//used a @Override annotation
	//Annotation are the entity which is used to provides the description about the specific method or class
	//both to the compiler as well as the programmer 
	//starts with @ and caps/ PascalCase
	//we can also create user defined Annotation
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Manager : Bonus "+bonus+"\t"+super.toString() ;
		//super keyword is used to invoke parent/super class methods/constructor
	}
/*
Method Overriding happens in only child class 
same method name and same argument list
return type must be also same ,can be only have co-variant return type ( sub-class type only is support)
the body or the definition of the method will be different
exception in overridden method must be only according to the super class method
means it super class method does not throw any exception then in child class overridden method cannot throw exception 
 */

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("================================================================================\n"
				+ "\n                               Manager : Bonus "+bonus);
		super.print();
	}
	//generate getters and setters
	public Double getBonus() {
		return bonus;
	}
	public void setBonus(Double bonus) {
		this.bonus = bonus;
	}
	//co-variant return type
	//return type can be of subclass-type
	//it can be of type Employee or child classtype i.e. Manager
	@Override
	public Manager getEmployee() {
		return this;
	//this refers to current object so it will return current manager object which has call getEmployee method
	}
}
