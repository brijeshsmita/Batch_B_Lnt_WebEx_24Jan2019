package com.lnt.day11;
// when we use new ---
/*
 * 1> object is created on heap
 * 2> memory is allocated
 * 3> constructor is invoked to initialize newly created object
 */
public class FinalizeDemo {
	public static void main(String[] args) {
		MyClass c1;
		for(int i=1;i<=3000000;i++) {
			System.out.print(i+" : ");
			c1 = new MyClass();
			c1=null;			
		}
		//System.out.println(c1.hashCode());
		//such object which is referring to null is eligible for garbage collection
		//memory will be released-
		//internally java garbage collector utility program takes care of it automatically
		//when we create object using new ---automatically constructor gets invoked
		//when  object refer to null then  ---automatically finalize() method  gets invoked
		//garbage collector utility program which de-allocates the memory which is no more longer in use
	}
}
class MyClass{
	public MyClass(){
		System.out.println("MyClass Object created...");
	}

	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
		System.out.println("***********MyClass Object Destroyed...");
	}
	
}
