/**
 * 
 */
package com.lnt.day3.class_methods;

/**
 * @author brije
 *
 */
public class EmployeeMain {
	public static void main(String[] args) {
		// lets create employee Object
		Employee e1 = new Employee();
		e1.print();
	}
}
/*
empId    - 0
empName  -null
salary   -0.0
email    -null
phoneNo  -null
address  -null
*/