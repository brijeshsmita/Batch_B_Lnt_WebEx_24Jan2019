/**
 * 
 */
package com.lnt.day3.class_methods;
/**
 * @author Smita
 *
 */
//top level class must always be public
//public means -accessible to all
public class Employee {
//all instance variable must be marked as private
	private int empId;
	private String empName;
	private double salary;
	private String email;//reference type/String can be used as primitive in java- without new keyword also
	private String phoneNo;
	private String address;
	private java.util.Date dateOfJoining;
	//java.util is in-build package in java
	//Date is a in-build class in java to deal with date functionality
	//reference/object of another class as an property in my class
	//containment in java / has- a relationship in java
	private static String coName;
	//to declare static variable , in java we use static block
	static {
		//static block is used to initialize static variables only
		coName="Lnt Infotech Ltd";//sharable copy 
		//shared by all the object of employees
		//single copy per class
	}
	public void print() {
		//all object/reference variable data-type default value is null
		System.out.println(
		"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
		+"\n                    Employee Details                             \n"
		+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
		+"\n          Employee Id    : "+empId
		+"\n          Employee Name  : "+empName
		+"\n          Salary         : "+salary
		+"\n          Email          : "+email
		+"\n          Phone Number   : "+phoneNo
		+"\n          Address        : "+address
		+"\n          Date Of Joining: "+dateOfJoining
		+"\n          Company Name   : "+coName
		+"\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	}
}
