package com.lnt.day3.methods;

import java.util.Scanner;

/**
 * @author Smita
 *
 */
public class CalculatorMain {
	public static void main(String[] args) {
		int n1,n2;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter numeric values for n1 and n2  ");
		n1=scan.nextInt();
		n2=scan.nextInt();
		// lets create calculator object
		Calculator c1 = new Calculator();
		Calculator.showDisplayScreen();//we can invoke static method with an object reference
		// but with a warning , as all object share that copy of same method 
		//thats y static method should be invoked using ClassName rather object reference
		//to invoke a normal method we need object of a class 
		//and '.' dot operator
		System.out.println("The sum of two numbers is : "+c1.addNumber(n1, n2));
		//how to invoke a static method
		//static method is invoked using ClassName.methodName()
		Calculator.showDisplayScreen();

	}

}
