package com.lnt.day3.methods;
/**
 * @author Smita
 *
 */
public class Calculator {
// +,-,*,/,%
	//+
	//return type, name,parameter/argument list/ body
	//methodName , verb , camelCase
	int addNumber(int n1, int n2) {
		//return keyword is used to return same type of datatype as the return type
		//from the function
		int sum = n1+n2;
		return sum;
	}
	//static is a keyword in java which state single copy per class
	//static method is declared using static keyword
	static void showDisplayScreen() {
		System.out.println("Showing Calci DisplayScreen");
	}
}
