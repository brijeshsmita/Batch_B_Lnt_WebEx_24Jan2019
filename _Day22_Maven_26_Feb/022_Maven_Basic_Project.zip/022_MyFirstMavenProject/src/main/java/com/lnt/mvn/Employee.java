/**
 * 
 */
package com.lnt.mvn;

/**
 * @author Smita B Kumar
 *
 */
public class Employee {

	/**
	 * 
	 */
	public Employee() {
		System.out.println("Employee....");
	}

}
