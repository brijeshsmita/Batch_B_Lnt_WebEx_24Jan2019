/**
 * 
 */
package com.lnt.maven.test;

import org.junit.Test;

/**
 * @author Smita B Kumar
 *
 */
public class HelloWorldTest {
	public HelloWorldTest() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Test method for {@link com.lnt.maven.HelloWorld#sayHello(java.lang.String)}.
	 */
	@Test
	public void testSayHello() {
		
	}

}
