/**
 * 
 */
package com.lnt.maven;

/**
 * @author Smita B Kumar
 *
 */
public class HelloWorld {
	public HelloWorld() {
		// TODO Auto-generated constructor stub
	}

	public static String sayHello(String name) {
		return "Hello ,"+name;
	}

}
