/**
 * 
 */
package com.lnt.io.file_byte.buffer;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * @author brije
 *
 */
public class FileBufferedWrite {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String pathname="src/demo1.txt";
		File file = new File(pathname);
		//to perform write operation - byte by byte -using buffer
		try(BufferedOutputStream br=new BufferedOutputStream(new FileOutputStream(file));	){
			byte [] bArr = {'h','i','\n','b','y','e'};
			br.write(bArr);
			br.flush();
			System.out.println("Written bytes using buffer  into file : "+file.getAbsolutePath());
			
		}catch (IOException e) {
			System.out.println(e);
		}
	}

}
