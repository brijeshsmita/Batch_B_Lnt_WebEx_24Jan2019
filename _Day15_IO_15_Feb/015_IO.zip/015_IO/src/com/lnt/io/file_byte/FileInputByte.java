/**
 * 
 */
package com.lnt.io.file_byte;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * @author brije
 *
 */
public class FileInputByte {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String pathname="src/demo1.txt";
		File file = new File(pathname);
		//to perform write operation - byte by byte
		InputStream inputStream=null;		
		//lets to perform input and output operation on the file
		try{
			inputStream= new FileInputStream(file);
			int ch=0;
			System.out.println("Reading from the file : "+file.getAbsolutePath());
			while((ch=inputStream.read())!=-1) {//-1 is end of file
				System.out.print((char)ch);//type casting int to char
			}
		}catch (IOException e) {
			System.err.println(e.getMessage());
		}finally {
			//release the resources
			try {
				inputStream.close();
			} catch (IOException e) {
				System.err.println(e.getMessage() +" Sorry Resource already closed");
			}
		}
	}

}
