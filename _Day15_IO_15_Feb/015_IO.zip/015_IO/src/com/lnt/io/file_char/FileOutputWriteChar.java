/**
 * 
 */
package com.lnt.io.file_char;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

/**
 * @author brije
 *
 */
public class FileOutputWriteChar {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String pathname="src/demo2.txt";
		File file = new File(pathname);
		//to perform write operation - char by char
		
		//try with resource block - used to automatically close the resource
		try(Writer writer = new FileWriter(file);){
			if(!file.exists())file.createNewFile();
			else {
				writer.write("Smita \n");
				writer.write("111 \n");
				writer.flush();//while performing write operation we should always flush the buffer
				System.out.println("Written char by char into the file : "+file.getAbsolutePath());
			}
		}catch (IOException e) {
			System.out.println(e);
		}

	}

}
