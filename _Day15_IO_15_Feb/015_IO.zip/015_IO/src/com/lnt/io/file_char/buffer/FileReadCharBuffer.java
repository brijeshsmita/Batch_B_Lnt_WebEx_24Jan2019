/**
 * 
 */
package com.lnt.io.file_char.buffer;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * @author brije
 *
 */
public class FileReadCharBuffer {
	public static void main(String[] args) {
		String pathname="src/Contact.java";
		File file = new File(pathname);
		//to perform read operation - char by char -using buffer
		System.out.println("Reading char from the file using buffer : "+file.getAbsolutePath());
		try(BufferedReader br=new BufferedReader(new FileReader(file));	){
			String str =null;
			while((str=br.readLine())!=null) {
				System.out.println(str);
			}
		}catch (IOException e) {
			System.out.println(e);
		}
	}

}
