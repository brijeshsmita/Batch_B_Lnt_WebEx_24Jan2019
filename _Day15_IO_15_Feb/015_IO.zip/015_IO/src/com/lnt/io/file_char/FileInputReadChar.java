/**
 * 
 */
package com.lnt.io.file_char;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

/**
 * @author brije
 *
 */
public class FileInputReadChar {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String pathname="src/demo2.txt";
		File file = new File(pathname);
		//to perform read operation - char by char
		System.out.println("Reading char by char from the file : "+file.getAbsolutePath());
		try(Reader reader = new FileReader(pathname)){//automatic resource management
			int ch;
			while((ch=reader.read())!=-1) {
				System.out.print((char)ch);
			}
		}catch (IOException e) {
			System.out.println(e);
		}
		//as we have used tey with resource block that why no need to explicitly close the fileReader
	}

}
