/**
 * 
 */
package com.lnt.io.read;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;
public class AccepInputFromUser {
	public static void main(String[] args) {		
		//accepting data using keyboard
		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				Scanner sc = new Scanner(System.in);){
			//any type of primitive data
			System.out.println("\nEnter Employee id :");
			int empId=sc.nextInt();
			System.out.println("Emp Id is :"+(int)empId);
			System.out.println("\nEnter Employee Name :");
			String empName=br.readLine();//accept string
			System.out.println("Emp Name is :"+empName);
			System.out.println("\nEnter Employee Address :");
			String address=br.readLine();//accept string
			System.out.println("Emp address is :"+address);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
