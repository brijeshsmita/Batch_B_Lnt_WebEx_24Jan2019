/**
 * 
 */
package com.lnt.io.read;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * @author brije
 *
 */
public class ReadDemoBuffer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//source is keyboard
		try(BufferedInputStream br = new BufferedInputStream(System.in);){
			//accepting data using buffer
			System.out.println("Enter Employee id :");
			int empId=br.read();
			System.out.println("Emp Id is :"+empId);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
