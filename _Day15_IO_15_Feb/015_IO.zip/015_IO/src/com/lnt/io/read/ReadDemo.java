/**
 * 
 */
package com.lnt.io.read;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * @author brije
 *
 */
public class ReadDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//accepting data using keyboard
		try(DataInputStream dis = new DataInputStream(System.in);){
			//any type of primitive data
			System.out.println("Enter Employee id :");
			int empId=dis.readInt();
			System.out.println("Emp Id is :"+empId);
			System.out.println("Enter Employee Name :");
			String empName=dis.readUTF();//unified text format
			System.out.println("Emp Name is :"+empName);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
