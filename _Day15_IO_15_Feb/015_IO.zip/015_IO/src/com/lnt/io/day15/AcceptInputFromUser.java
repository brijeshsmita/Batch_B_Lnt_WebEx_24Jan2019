/**
 * 
 */
package com.lnt.io.day15;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * @author Smita B Kumar
 *
 */
public class AcceptInputFromUser {
	public static void main(String[] args) {
		int custId;
		String firstName,lastName,phoneNo,email,address;
		Customer customer=null;
		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in));){
			System.out.println("Enter Your Customer Id");
			custId=Integer.parseInt(br.readLine());//it will read int
			System.out.println("Enter Your Customer firstName");
			firstName=br.readLine();
			System.out.println("Enter Your Customer lastName");
			lastName=br.readLine();
			System.out.println("Enter Your Customer phoneNo");
			phoneNo=br.readLine();
			System.out.println("Enter Your Customer email");
			email=br.readLine();
			System.out.println("Enter Your Customer address");
			address=br.readLine();
			customer= new Customer(custId, firstName, lastName, phoneNo, email, address);
			System.out.println("Customer info : "+customer);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
