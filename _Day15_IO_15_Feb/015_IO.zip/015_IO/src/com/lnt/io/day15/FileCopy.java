/**
 * 
 */
package com.lnt.io.day15;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * @author Smita B Kumar
 *
 */
public class FileCopy {
	public static void main(String[] args) {
		String file ="src/lnt_webx.png";
		String copyFile ="src/lnt_webx_COPY.png";
		//read byte by byte from lnt_webx.png file and write byte by byte to lnt_webx_COPY.png
		try(FileInputStream in = new FileInputStream(file);
			FileOutputStream out = new FileOutputStream(copyFile);
			BufferedInputStream bis = new BufferedInputStream(in);
			BufferedOutputStream bos = new BufferedOutputStream(out);
		){
			int b=0;
			while((b=bis.read())!=-1) {//read byte by byte from lnt_webx.png file till end of file (-1)
				// write byte by byte to lnt_webx_COPY.png
				bos.write(b);
				//perform file copy operation
				bos.flush();
			}				
			System.out.println("file Copied from : "+file+ "\t to : "+copyFile);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
