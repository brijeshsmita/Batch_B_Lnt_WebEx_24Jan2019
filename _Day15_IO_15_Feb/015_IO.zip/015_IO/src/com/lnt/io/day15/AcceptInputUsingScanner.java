/**
 * 
 */
package com.lnt.io.day15;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 * @author Smita B Kumar
 *
 */
public class AcceptInputUsingScanner {
	public static void main(String[] args) {
		int custId;
		String firstName,lastName,phoneNo,email,address;
		Customer customer=null;
		try(Scanner scan = new Scanner(System.in);){
			System.out.println("Enter Your Customer Id");
			custId=scan.nextInt();//it will read int
			System.out.println("Enter Your Customer firstName");
			firstName=scan.next();
			System.out.println("Enter Your Customer lastName");
			lastName=scan.next();
			System.out.println("Enter Your Customer phoneNo");
			phoneNo=scan.next();
			System.out.println("Enter Your Customer email");
			email=scan.next();
			System.out.println("Enter Your Customer address");
			address=scan.next();
			customer= new Customer(custId, firstName, lastName, phoneNo, email, address);
			System.out.println("Customer info : "+customer);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
