/**
 * 
 */
package com.lnt.io.day15;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * @author Smita B Kumar
 *
 */
public class FileReadWriteByte {

	public static void main(String[] args) throws IOException {
		String pathname="src/demo1.dat";
		File file = new File(pathname);
		if(file.exists()) {
			writeByte(file);
			readByte(file);
		}else {
			System.out.println("sorry ... File Does not exists!!!");
			System.out.println("Creating the file ...."+file.getAbsolutePath());
			file.createNewFile();
			writeByte(file);
			readByte(file);
		}
	}

	public static void readByte(File file) {
		System.out.println("Reading bytes onto the file "+file.getName());
		try {
			FileInputStream inputStream = new FileInputStream(file);
			int ch=0;
			while((ch=inputStream.read())!=-1){//-1 means end of file
				System.out.print((char)ch);
			}
			//close the inputStream
			inputStream.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}

	public static void writeByte(File file) {
		byte [] bArr= {'h','i'};
		//to write byte onto the file
		System.out.println("Writing bytes onto the file "+file.getName());
		//try with resource implicitly close the resources
		try(FileOutputStream outputStream = new FileOutputStream(file);){
			outputStream.write(65);//ascii code for A
			outputStream.write(' ');
			outputStream.write(bArr);
			outputStream.flush();//clear the buffer					
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
}
