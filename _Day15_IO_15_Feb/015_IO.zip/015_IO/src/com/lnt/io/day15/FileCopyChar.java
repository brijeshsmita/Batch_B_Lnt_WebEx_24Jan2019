/**
 * 
 */
package com.lnt.io.day15;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author Smita B Kumar
 *
 */
public class FileCopyChar {
	public static void main(String[] args) {
		String file ="src/Customer.java";
		String copyFile ="src/Customer_COPY.txt";
		//read char buffer from Customer.java file and write char buffer to Customer_COPY.txt
		try(FileReader in = new FileReader(file);
			FileWriter out = new FileWriter(copyFile);
			BufferedReader br = new BufferedReader(in);
			BufferedWriter bw = new BufferedWriter(out);
		){
			String str="";
			//while loop will break if readLine method return null...means it has reached EOF
			while((str=br.readLine())!=null) {//read char buffer Customer.java file till end of file (-1)
				// write char buffer to Customer_COPY.txt
				bw.write(str+"\n");
				System.out.print(str+"\n");
				//perform file copy operation
				bw.flush();			
			}				
			System.out.println("file Copied from : "+file+ "\t to : "+copyFile);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
