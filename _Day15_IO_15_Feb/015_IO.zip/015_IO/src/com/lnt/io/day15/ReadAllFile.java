/**
 * 
 */
package com.lnt.io.day15;
import java.io.File;
/**
 * @author Smita B Kumar
 *
 */
public class ReadAllFile {
	public static void main(String[] args) {
		File folder = new File("E:\\demo");
		File [] listOfFiles = folder.listFiles();
		for(File file :listOfFiles) {
			if(file.isFile()) {
				FileReadWriteByte.readByte(file);
			}
		}
	}
}
