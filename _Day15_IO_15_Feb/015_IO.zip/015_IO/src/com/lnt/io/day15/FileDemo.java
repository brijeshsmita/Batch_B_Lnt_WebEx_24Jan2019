/**
 * 
 */
package com.lnt.io.day15;

import java.io.File;
import java.io.IOException;

/**
 * @author Smita B Kumar
 *
 */
public class FileDemo {

	public static void main(String[] args) throws IOException {
		// File class which help us to fetch info about the File
		String pathname1="src/com/lnt/io/day15/FileDemo.java";
		String pathname2="src";
		String pathname3="C:\\Users\\Smita B Kumar\\Pictures\\lnt_webx.png";//"src/demo.txt";
		String pathname="src/demo.txt";
		File file = new File(pathname);
		if(file.exists()) {
			System.out.println("Is File : "+file.isFile());
			System.out.println("Is Directory : "+file.isDirectory());
			System.out.println("Do File canRead : "+file.canRead());
			System.out.println("Do File canWrite : "+file.canWrite());
			System.out.println("Absolute Path : "+file.getAbsolutePath());
			System.out.println("Relative Path : "+file.getPath());
		}else {
			System.out.println("sorry ... File Does not exists!!!");
			System.out.println("Creating the file ...."+file.getAbsolutePath());
			file.createNewFile();
		}

	}

}
