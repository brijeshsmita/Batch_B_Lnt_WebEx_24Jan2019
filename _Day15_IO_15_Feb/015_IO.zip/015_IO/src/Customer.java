/**
 * 
 */


/**
 * @author Smita B Kumar
 *
 */
public class Customer extends Person{
	//instance variable
	private int custId;
	private String firstName;
	private String lastName;
	private String phoneNo;
	private String email;
	private String address;
	public static String coName;
	static {
		coName="Lnt Infotect Ltd";
	}
	public Customer() {
	}
	private Customer(int custId) {
		this.custId=custId;
	}
	public Customer(int custId, String firstName, String lastName, String phoneNo, String email, String address) {
		super();
		this.custId = custId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNo = phoneNo;
		this.email = email;
		this.address = address;
	}
	private void sceretInfo() {
		System.out.println("this is a private method");
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", firstName=" + firstName + ", lastName=" + lastName + ", phoneNo="
				+ phoneNo + ", email=" + email + ", address=" + address + "]";
	}

}
class Person {
	public int aadharId;
}
