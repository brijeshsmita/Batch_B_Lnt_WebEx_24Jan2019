/**
 * 
 */
package com.lnt.day12.priority;

/**
 * @author Smita
 *
 */
class PriorityTask implements Runnable{
	@Override
	public void run() {
		String threadName=Thread.currentThread().getName();
		System.out.println(threadName+" , PRIORITY : "+Thread.currentThread().getPriority());
	}	
}
public class ThreadPriority {
	public static void main(String[] args) {
		//lets create three thread and set their priority
		Runnable target = new PriorityTask();
		Thread t1 = new Thread(target,"Java");
		t1.setPriority(10);//number between 1-10
		Thread t2 = new Thread(target,"Hibernate");
		t2.setPriority(Thread.MIN_PRIORITY); // by passing static constant
		Thread t3 = new Thread(target,"Oracle");
		t3.setPriority(7);
		//let decide the priority of the thread
		//setPriority() ; 
		// 1- MIN_PRIORITY  5- NORM_PRIORITY    10-  MAX_PRIORITY
		// 5 IS THE DEFAULT PRIORITY
		t1.start();
		t2.start();
		t3.start();
//JVM runs on top of operating system
		//we can request OS to set the priority of the Thread but can't force OS
	}

}
