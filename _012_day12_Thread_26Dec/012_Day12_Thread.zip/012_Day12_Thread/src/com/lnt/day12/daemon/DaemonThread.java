/**
 * 
 */
package com.lnt.day12.daemon;

/**
 * @author brije
 *
 */
public class DaemonThread extends Thread{

	/**
	 * Lowest priority Thread which runs at the back ground
	 * eg: Garbage collector
	 * it is utility program which runs at the background, the lowest priority thread
	 * is invoked when the object is no more longer in use or referring to null
	 * it de-freez or de-allocated the memory of such object which no more longer inuse or referring to null
	 */
	public static void main(String[] args) {
		//how to set thread as Daemon
		Thread t1 = new DaemonThread();
		t1.setDaemon(true);
		//how to check weather the thread is daemon or not
		System.out.println("Is thread a Daemon Thread : "+t1.isDaemon());
				

	}

}
