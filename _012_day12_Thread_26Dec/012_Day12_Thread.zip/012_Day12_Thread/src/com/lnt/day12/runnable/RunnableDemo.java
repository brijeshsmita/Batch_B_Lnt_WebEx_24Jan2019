/**
 * 
 */
package com.lnt.day12.runnable;

/**
 * @author Smita
 *
 */
//in java 8 an interface which has only one abstract method is known as Functional interface
//in java an interface which DOES NOT HAVE any method is known as TAGGING/MARKER interface
//Runnable is a FuntionalInterface as it contain only 1 abstract method i.e run()
//Thread class implements Runnable , therefore it has a run() method implementation

//step 1: create a class implements Runnable
class RunnableTask implements Runnable{
	//step 2: Override  run() method
	@Override	
	public void run() {
		String threadName=Thread.currentThread().getName();//currentThread is a static method of Thread
		//step 3: provide method logic
		for (int i = 1; i <=5; i++) {
			System.out.println(threadName+ " : "+i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}		
	}	
}
public class RunnableDemo {	
	public static void main(String[] args) throws InterruptedException {
		//error//Thread t1 = new RunnableTask();//not possible ...Y
		//as it is not the sub-class of thread , rather sub-class of Runnable interface
		//Step 4: In main method create Object of Runnable
		Runnable target = new RunnableTask();
		//error//target.start();// as start is the method of Thread class not the method of RUnnable interface
		//if we invoke run() method directly then it will be not treated a Thread, but will be normal java object
		//Step 5: create Object of Thread by passing Runnable target to it.
		//Thread t1 = new Thread(target);//not passed the name of the thread
		Thread t1 = new Thread(target, "T1");// passed the name of the thread along with the target
		//step 6: invoke the start() method
		t1.start();
		Thread t2 = new Thread(target, "T2");// passed the name of the thread along with the target
		//step 6: invoke the start() method
		t1.join();
		t2.start();
	}
}
