/**
 * 
 */
package com.lnt.day12.thread;

/**
 * @author Smita
 *
 */
//step1 : create a class and extends it by Thread
class Task extends Thread{//Task is a sub-class of Thread class
	//step2 : Override run method- and provide the work to be done by the Thread
	@Override
	public void run() {
		//step3 : write the business login to be performed by the Thread
		//to print number from 1 to 5
		System.out.println("*****4> Thread is Running ...in run method");
		Thread threadName=Thread.currentThread();
		for (int i = 1; i <=5; i++) {
			System.out.println(threadName+"...Completing task : "+i);
			//currentThread() is a static method of Thread class - ThreadName ,Priority,methodName
		}
		System.out.println("\n*****5> Thread is about to die...");
	}	
}
public class ThreadDemo {
	//step4 : in main method -create instance of Thread
	public static void main(String[] args) {
		System.out.println("*****1> Thread is new (born)");
		Thread t1 = new Task();//then reference of Thread class and created object of the class we created
		//step 5: start the thread- now thread will b in ready to run state,
		//now OS will invoke the run() method automatically
		System.out.println("*****2> Thread is Alive ? "+t1.isAlive());//false
		//once you start the Thread then it is alive		
		t1.start();
		System.out.println("*****3> Thread is starting ...ready to run...Now is Alive ...."+t1.isAlive());	
		
	}
}
