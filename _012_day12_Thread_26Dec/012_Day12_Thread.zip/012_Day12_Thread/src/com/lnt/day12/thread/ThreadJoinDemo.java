/**
 * 
 */
package com.lnt.day12.thread;

/**
 * @author Smita
 *
 */
//step 1: create a class and extends from thread class
class JoinTask extends Thread{
	public JoinTask(String name){
		super(name);
	}
	//step 2: run method
	@Override
	public void run() {
		/*t1 - > to complete the task from 1 to 50 		
		then t2 -> to complete the task from 51 to 100*/
		/***NOTE :t2 should start only when t1 has completed the task till 50*/
		String  threadName=currentThread().getName();
		//step 3: write the business login to be performed by the thread
		if(threadName.equals("T1")){
			for (int i = 1; i <=50; i++) {
				System.out.println(threadName+ " completeing task : "+i);
			}
			System.out.println(threadName+".......Completed all the task.... from 1 - 50\n");
		}
		
		if(threadName.equals("T2")){
			for (int i = 51; i <=100; i++) {
				System.out.println(threadName+ " completeing task : "+i);
			}
			System.out.println(threadName+".......Completed all the task.... from 51 - 100");
		}
		
	}
}
//step 4: in main method create the instance of thread
public class ThreadJoinDemo {
	public static void main(String[] args) throws InterruptedException {
		Thread t1 = new JoinTask("T1");
		Thread t2 = new JoinTask("T2");
		//step 5: invoke start on thread object
		t1.start();
		t1.join();//allow the current thread to complete the task first and then give the execution to the next waiting thread
		//join throws InterruptedException 
		t2.start();//JVM will invoke the run method and OS will decide which thread to be executed
	}

}

