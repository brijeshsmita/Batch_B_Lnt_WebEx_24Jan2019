/**
 * 
 */
package com.lnt.day12.thread;

/**
 * @author Smita
 *
 */
//step1 : create a class and extends it by Thread
class MyTask extends Thread{//Task is a sub-class of Thread class
	public MyTask() {
		// TODO Auto-generated constructor stub
	}
	public MyTask(String threadName) {
		super(threadName);//calling super class constructor 
	}

	//step2 : Override run method- and provide the work to be done by the Thread
	@Override
	public void run() {
		//step3 : write the business login to be performed by the Thread
		//to print number from 1 to 5
		String threadName=Thread.currentThread().getName();
		System.out.println(threadName+"... Thread is Running ...in run method\n");
		for (int i = 1; i <=5; i++) {
			System.out.println(threadName+"...started performing task : "+i);
			try {
				Thread.sleep(1000);//allows the current Thread to enters into waiting state for the specific amount of mili seconds
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}//long mili seconds as args
			//static method of thread class ...sleep ...throws InterruptedException
			//currentThread() is a static method of Thread class - ThreadName ,Priority,methodName
		}
		System.out.println("\n"+threadName+"... Thread is about to die...\n");
	}	
}
public class ThreadMethodDemo {
	//step4 : in main method -create instance of Thread
	public static void main(String[] args) {
		Thread t1 = new MyTask("T1");//pass the thread name , and create no-arg and overloaded constructor
		Thread t2 = new MyTask("T2");//now no need of setting the name of the thread explicitly
		Thread t3 = new MyTask("T3");
		//t1.setName("T1");//explicitly we are invoking setName method, instead w can use overloaded constructor of Thread class
		t1.start();
		Thread.yield();//static method provide the  execution to the current waiting thread 
		//t2.setName("T2");
		t2.start();
		//t3.setName("T3");
		t3.start();
		/*
		 * you will see difference in output in-case of multi-threading program?
		 * because JVM(java virtual machine runs on top of OS, and OS decide the thread time scheduling
		 */		
	}
}
