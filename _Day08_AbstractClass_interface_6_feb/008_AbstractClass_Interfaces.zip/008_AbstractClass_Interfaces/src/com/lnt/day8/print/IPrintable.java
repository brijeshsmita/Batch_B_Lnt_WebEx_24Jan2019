/**
 * 
 */
package com.lnt.day8.print;

/**
 * @author Smita
 *
 */
public interface IPrintable {
	public void print();
}
/*
1> interfaces are used to add additional role or services to the existing object
2> by default all interface are abstract , no need to have abstract keyword, 
we use interface keyword to declare an interface
3> abstract cannot be instantiated, therefore we cannot create object of an interface
4> by default all method in an interface are abstract
5> by default all variables in an interface are public static and final
final variable must be initialize cannot be re-initialize
6> from java 8 onwards interface can have default and static methods , to allow the developers to add new methods
without affecting the classes that implements these interface
//Golden rule-A class implementing an interface must override all the abstract method
//or declare itself as an abstract class
 7> interface does not have constructors
 8> an interface an extends many interface
 9> Interface does not follow any hierarchy .... in can be implemented by any class
 */