/**
 * 
 */
package com.lnt.day8.print.fax;

import com.lnt.day8.print.call.ICallable;

/**
 * @author Smita
 *
 */
//an interface can extends multiple interface
//a class can implements multiple interface
//a class can extends only one class
public interface IFaxable extends ICallable,IMessagable{
	public void fax();
}
