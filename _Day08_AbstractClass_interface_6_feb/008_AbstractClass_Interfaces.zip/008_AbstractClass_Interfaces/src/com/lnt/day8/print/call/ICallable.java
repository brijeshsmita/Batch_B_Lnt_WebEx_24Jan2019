/**
 * 
 */
package com.lnt.day8.print.call;

/**
 * @author brije
 *
 */
public interface ICallable {
	public void call();
}
