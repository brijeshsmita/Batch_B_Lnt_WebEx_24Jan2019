/**
 * 
 */
package com.lnt.day8.print.fax;

/**
 * @author brije
 *
 */
public interface IMessagable {
	public void message();
}
