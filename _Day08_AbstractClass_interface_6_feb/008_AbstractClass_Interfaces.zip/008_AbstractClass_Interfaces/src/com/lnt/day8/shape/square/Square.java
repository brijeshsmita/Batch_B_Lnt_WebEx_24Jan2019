/**
 * 
 */
package com.lnt.day8.shape.square;

import com.lnt.day8.shape.Shape;
import com.lnt.day8.threed_shape.IThreeDShape;

/**
 * @author Smita
 *
 */
//Golden rule-A class extending an abstract class or implementing an interface  must override all the abstract method
//or declare itself as an abstract class
public class Square extends Shape implements IThreeDShape{
	protected float sides;
	
	public Square() {
		System.out.println("Square class no-arg Constructor.....");
	}
	
	public Square(float sides) {
		super();
		System.out.println("Square class Overloaded Constructor.....");
		this.sides = sides;
	}

	/* (non-Javadoc)
	 * @see com.lnt.day8.shape.Shape#draw()
	 */
	@Override
	public void draw() {
		System.out.println("Drawing a Square....");
	}

	/* (non-Javadoc)
	 * @see com.lnt.day8.shape.Shape#area()
	 */
	@Override
	public double area() {
		// TODO Auto-generated method stub
		return sides*sides;
	}

	public float getSides() {
		return sides;
	}

	public void setSides(float sides) {
		this.sides = sides;
	}

	@Override
	public String toString() {
		return "Square [sides=" + sides + ", area()=" + area() + "]";
	}

	@Override
	public void draw3dShape() {
		System.out.println("Drawing a Three Dimension Square....");
	}

	@Override
	public void print() {
		System.out.println("Printing a Square with an area of ...."+area());
	}
}
