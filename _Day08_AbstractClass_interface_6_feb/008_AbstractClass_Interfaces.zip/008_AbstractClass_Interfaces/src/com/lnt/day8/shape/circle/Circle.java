/**
 * 
 */
package com.lnt.day8.shape.circle;

import com.lnt.day8.shape.Shape;
import com.lnt.day8.threed_shape.IThreeDShape;

/**
 * @author Smita
 *
 */
//Golden rule-A class extending an abstract class or implementing an interface  must override all the abstract method
//or declare itself as an abstract class
public class Circle extends Shape implements IThreeDShape{
	protected static final float PI = 3.14f;
	protected float radius;

	public Circle() {
		System.out.println("Circle class no-arg Constructor.....");
	}

	public Circle(float radius) {
		super();
		System.out.println("Circle class Overloaded Constructor.....");
		this.radius = radius;
	}

	@Override // in overriding the method we cannot reduce the visibility
	// mean if the method is public in super class we cannot mark it as
	// protected,private or default
	public void draw() {
		System.out.println("Drawing a Circle....");
	}

	@Override // we can provide a wider visibility
	public double area() {
		return PI * radius * radius;
	}
	// getters and setters

	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}

	public static float getPi() {
		return PI;
	}

	@Override
	public String toString() {
		return "Circle [radius=" + radius + ", area()=" + area() + "]";
	}

	@Override
	public void draw3dShape() {
		System.out.println("Drawing a Three Dimension Circle....");
	}

	@Override
	public void print() {
		System.out.println("Printing a Circle with an area of ...."+area());
	}

}
//Golden rule-A class extending an abstract class must override all the abstract method
//or declare itself as an abstract class
