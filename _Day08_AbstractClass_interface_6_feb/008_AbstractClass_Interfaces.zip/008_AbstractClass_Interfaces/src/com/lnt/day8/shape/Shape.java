/**
 * 
 */
package com.lnt.day8.shape;

import com.lnt.day8.print.IPrintable;

/**
 * @author Smita
 *
 */
//lets make it abstract class
abstract public class Shape implements IPrintable{
	
	public abstract void draw();//draw method does not have any implementation, therefore 
	//it will marked as abstract method
	public abstract double area();
	public Shape(){
		System.out.println("Shape class Constructor.....");
	}
	void printInfo() {
		System.out.println("Shape Class....");
	}
	
}

//if a class contain an abstract method must be marked as abstract
//abstract class cannot be instantiated, is used for further extensibility of code
//the other class inheriting from abstract class will be providing there own implementation
//an abstract class can have both abstract as well as concrete(method with implementation/body)
//abstract method does not have any implementation/body, terminated with semicolan and marked as abstract
////yes a class can be marked as abstract even though it does'nt contain any abstract method
//eg: HttpServlet
//abstract class can have constructor
//static method cannot be overridden
//abstract method must be overridden else we need to declare the class itself as an abstract

//final-abstract -NO
//static-abstract -NO