/**
 * 
 */
package com.lnt.day8.threed_shape;

/**
 * @author brije
 *
 */
//Naming conventions for an interface 
/*
 * PascalCase
 * prefix with I
 * postfix with able
 */
public interface IThreeDShape {
	/*public static  final*/int noOfShapes=100;//final variable must be initialize cannot be re-initialize
	public void draw3dShape();
	
	default void newMethod1() {
		System.out.println("newly added default newMethod1 which canbe overridden by the implementing class");
	}
	
	static void newMethod2() {
		System.out.println("newly added static newMethod2 which cannot overridden by the implementing class");
	}
	
}
/*
1> interfaces are used to add additional role or services to the existing object
2> by default all interface are abstract , no need to have abstract keyword, 
we use interface keyword to declare an interface
3> abstract cannot be instantiated, therefore we cannot create object of an interface
4> by default all method in an interface are abstract
5> by default all variables in an interface are public static and final
final variable must be initialize cannot be re-initialize
6> from java 8 onwards interface can have default and static methods , to allow the developers to add new methods
without affecting the classes that implements these interface
//Golden rule-A class implementing an interface must override all the abstract method
//or declare itself as an abstract class
 7> interface does not have constructors
 */