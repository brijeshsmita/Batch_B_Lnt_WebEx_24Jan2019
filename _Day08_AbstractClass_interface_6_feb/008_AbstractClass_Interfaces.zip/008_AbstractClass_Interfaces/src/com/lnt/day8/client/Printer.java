/**
 * 
 */
package com.lnt.day8.client;

import com.lnt.day8.emp.Employee;
import com.lnt.day8.emp.mgr.Manager;
import com.lnt.day8.emp.mgr.sales.SalesManager;
import com.lnt.day8.print.IPrintable;
import com.lnt.day8.shape.circle.Circle;
import com.lnt.day8.shape.square.Square;

/**
 * @author Smita
 *
 */
public class Printer {
	public static void main(String[] args) {
		Square s1 = new Square(4.5f);
		Circle c1 = new Circle(4.5f);
		Employee e1 = new Employee("Zara",999.99);
		Manager m1 = new Manager("Zara",999.99,100.50);
		SalesManager sm1 = new SalesManager("Zara",999.99,100.50,70.70);
		
		IPrintable [] pArr= {s1,c1,e1,m1,sm1};
		Printer.printAll(pArr);
	}
	
	static void printAll(IPrintable ... pArr) {
		for(IPrintable p:pArr)
			p.print();//at runtime the compiler will decide which object print method will be invoked
	}

}
