/**
 * 
 */
package com.lnt.day8.client;

import com.lnt.day8.shape.circle.Circle;
import com.lnt.day8.shape.square.Square;
import com.lnt.day8.threed_shape.IThreeDShape;

/**
 * @author Smita
 *
 */
public class ThreeDShapeCient {
	public static void main(String[] args) {
		//Best practice we should always create reference of super class/interface
		IThreeDShape threeDShape ;
		threeDShape= new Circle(7.5f);
		threeDShape.draw3dShape();
		threeDShape = new Square(7.5f);
		threeDShape.draw3dShape();

	}

}
