/**
 * 
 */
package com.lnt.day8.client;

import com.lnt.day8.shape.Shape;
import com.lnt.day8.shape.circle.Circle;
import com.lnt.day8.shape.square.Square;

/**
 * @author Smita
 *
 */
public class ShapeClient {

	public static void main(String[] args) {
		//abstract class cannot be instantiated/object of abstract class cannot be created
		//compilation error //Shape s1 = new Shape();
		Shape s1;
		s1= new Circle(3.5f);//on the reference of shape we are creating the object of circle
		s1.draw();//check draw method in the reference class and then check in the actual class object
		System.out.println(s1.toString());//dynamic polymorphism - at runtime the compiler will decide which class method to be invoked
		s1= new Square(4.5f);
		System.out.println("The area of Sqaure  is  :"+s1.area());
		s1.draw();
		
		Square s2 = new Square(5.5f);
		System.out.println("The area of Sqaure with side "+s2.getSides()+" is  :"+s1.area());
	}

}
